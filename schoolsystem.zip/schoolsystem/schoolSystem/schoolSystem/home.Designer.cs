﻿namespace schoolSystem
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_info = new System.Windows.Forms.Button();
            this.btn_settings = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btn_Personal = new System.Windows.Forms.Button();
            this.btn_new_contact = new System.Windows.Forms.Button();
            this.btn_registration = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btn_info);
            this.panel1.Controls.Add(this.btn_settings);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.btn_Personal);
            this.panel1.Controls.Add(this.btn_new_contact);
            this.panel1.Controls.Add(this.btn_registration);
            this.panel1.Location = new System.Drawing.Point(14, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(824, 56);
            this.panel1.TabIndex = 1;
            // 
            // btn_info
            // 
            this.btn_info.BackColor = System.Drawing.Color.DarkCyan;
            this.btn_info.Font = new System.Drawing.Font("Modern No. 20", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_info.Location = new System.Drawing.Point(705, 3);
            this.btn_info.Name = "btn_info";
            this.btn_info.Size = new System.Drawing.Size(115, 50);
            this.btn_info.TabIndex = 6;
            this.btn_info.Text = "Info";
            this.btn_info.UseVisualStyleBackColor = false;
            // 
            // btn_settings
            // 
            this.btn_settings.BackColor = System.Drawing.Color.DarkCyan;
            this.btn_settings.Font = new System.Drawing.Font("Modern No. 20", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_settings.Location = new System.Drawing.Point(588, 3);
            this.btn_settings.Name = "btn_settings";
            this.btn_settings.Size = new System.Drawing.Size(115, 50);
            this.btn_settings.TabIndex = 5;
            this.btn_settings.Text = "Settings";
            this.btn_settings.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DarkCyan;
            this.button5.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(471, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(115, 50);
            this.button5.TabIndex = 4;
            this.button5.Text = "Fee/Salary";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn_Personal
            // 
            this.btn_Personal.BackColor = System.Drawing.Color.DarkCyan;
            this.btn_Personal.Font = new System.Drawing.Font("Modern No. 20", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_Personal.Location = new System.Drawing.Point(354, 3);
            this.btn_Personal.Name = "btn_Personal";
            this.btn_Personal.Size = new System.Drawing.Size(115, 50);
            this.btn_Personal.TabIndex = 3;
            this.btn_Personal.Text = "Personal";
            this.btn_Personal.UseVisualStyleBackColor = false;
            // 
            // btn_new_contact
            // 
            this.btn_new_contact.BackColor = System.Drawing.Color.DarkCyan;
            this.btn_new_contact.Font = new System.Drawing.Font("Modern No. 20", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_new_contact.Location = new System.Drawing.Point(237, 3);
            this.btn_new_contact.Name = "btn_new_contact";
            this.btn_new_contact.Size = new System.Drawing.Size(115, 50);
            this.btn_new_contact.TabIndex = 2;
            this.btn_new_contact.Text = "New Contacts";
            this.btn_new_contact.UseVisualStyleBackColor = false;
            // 
            // btn_registration
            // 
            this.btn_registration.BackColor = System.Drawing.Color.DarkCyan;
            this.btn_registration.Font = new System.Drawing.Font("Modern No. 20", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_registration.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_registration.Location = new System.Drawing.Point(3, 3);
            this.btn_registration.Name = "btn_registration";
            this.btn_registration.Size = new System.Drawing.Size(115, 50);
            this.btn_registration.TabIndex = 0;
            this.btn_registration.Text = "Registration";
            this.btn_registration.UseVisualStyleBackColor = false;
            this.btn_registration.Click += new System.EventHandler(this.btn_registration_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkCyan;
            this.button1.Font = new System.Drawing.Font("Modern No. 20", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.button1.Location = new System.Drawing.Point(120, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 50);
            this.button1.TabIndex = 7;
            this.button1.Text = "Detail";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::schoolSystem.Properties.Resources._1_1305121UH7;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(846, 523);
            this.Controls.Add(this.panel1);
            this.Name = "home";
            this.Text = "home";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_info;
        private System.Windows.Forms.Button btn_settings;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btn_Personal;
        private System.Windows.Forms.Button btn_new_contact;
        private System.Windows.Forms.Button btn_registration;
        private System.Windows.Forms.Button button1;
    }
}