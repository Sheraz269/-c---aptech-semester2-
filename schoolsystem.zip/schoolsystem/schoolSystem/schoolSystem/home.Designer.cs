﻿namespace schoolSystem
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_info = new System.Windows.Forms.Button();
            this.btn_Personal = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btn_new_contact = new System.Windows.Forms.Button();
            this.btn_registration = new System.Windows.Forms.Button();
            this.btn_settings = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fAQToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseRecoveryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btn_info);
            this.panel1.Controls.Add(this.btn_Personal);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.btn_new_contact);
            this.panel1.Controls.Add(this.btn_registration);
            this.panel1.Location = new System.Drawing.Point(0, 24);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(846, 122);
            this.panel1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Teal;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = global::schoolSystem.Properties.Resources.classmates;
            this.button1.Location = new System.Drawing.Point(142, 3);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 115);
            this.button1.TabIndex = 7;
            this.button1.Text = "Student Profile";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_info
            // 
            this.btn_info.BackColor = System.Drawing.Color.Brown;
            this.btn_info.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_info.Font = new System.Drawing.Font("Modern No. 20", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_info.Image = global::schoolSystem.Properties.Resources.clipboard;
            this.btn_info.Location = new System.Drawing.Point(434, 3);
            this.btn_info.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_info.Name = "btn_info";
            this.btn_info.Size = new System.Drawing.Size(140, 115);
            this.btn_info.TabIndex = 6;
            this.btn_info.Text = "Fees Due List ";
            this.btn_info.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_info.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_info.UseVisualStyleBackColor = false;
            // 
            // btn_Personal
            // 
            this.btn_Personal.BackColor = System.Drawing.Color.YellowGreen;
            this.btn_Personal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Personal.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Personal.Image = global::schoolSystem.Properties.Resources.money;
            this.btn_Personal.Location = new System.Drawing.Point(698, 3);
            this.btn_Personal.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_Personal.Name = "btn_Personal";
            this.btn_Personal.Size = new System.Drawing.Size(145, 115);
            this.btn_Personal.TabIndex = 3;
            this.btn_Personal.Text = "Employee Salary";
            this.btn_Personal.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Personal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_Personal.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.BurlyWood;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Image = global::schoolSystem.Properties.Resources.old_school;
            this.button5.Location = new System.Drawing.Point(574, 3);
            this.button5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(125, 115);
            this.button5.TabIndex = 4;
            this.button5.Text = "Student Fee";
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn_new_contact
            // 
            this.btn_new_contact.BackColor = System.Drawing.Color.Chocolate;
            this.btn_new_contact.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_new_contact.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_new_contact.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_new_contact.Image = global::schoolSystem.Properties.Resources.employees;
            this.btn_new_contact.Location = new System.Drawing.Point(281, 3);
            this.btn_new_contact.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_new_contact.Name = "btn_new_contact";
            this.btn_new_contact.Size = new System.Drawing.Size(155, 115);
            this.btn_new_contact.TabIndex = 2;
            this.btn_new_contact.Text = "Teachers Profile";
            this.btn_new_contact.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_new_contact.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_new_contact.UseVisualStyleBackColor = false;
            this.btn_new_contact.Click += new System.EventHandler(this.btn_new_contact_Click);
            // 
            // btn_registration
            // 
            this.btn_registration.BackColor = System.Drawing.Color.Olive;
            this.btn_registration.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_registration.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_registration.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registration.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_registration.Image = global::schoolSystem.Properties.Resources.registration__3_;
            this.btn_registration.Location = new System.Drawing.Point(2, 3);
            this.btn_registration.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_registration.Name = "btn_registration";
            this.btn_registration.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_registration.Size = new System.Drawing.Size(140, 115);
            this.btn_registration.TabIndex = 0;
            this.btn_registration.Text = "Registration";
            this.btn_registration.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_registration.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_registration.UseVisualStyleBackColor = false;
            this.btn_registration.Click += new System.EventHandler(this.btn_registration_Click);
            // 
            // btn_settings
            // 
            this.btn_settings.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_settings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_settings.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_settings.Image = global::schoolSystem.Properties.Resources.exit;
            this.btn_settings.Location = new System.Drawing.Point(360, 385);
            this.btn_settings.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_settings.Name = "btn_settings";
            this.btn_settings.Size = new System.Drawing.Size(120, 115);
            this.btn_settings.TabIndex = 5;
            this.btn_settings.Text = "Log Out";
            this.btn_settings.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_settings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_settings.UseVisualStyleBackColor = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.menuStrip1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.userToolStripMenuItem,
            this.employeesToolStripMenuItem,
            this.studentToolStripMenuItem,
            this.transactionToolStripMenuItem,
            this.recordsToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.fAQToolStripMenuItem,
            this.databaseRecoveryToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.logOutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(847, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(87, 24);
            this.toolStripMenuItem1.Text = "Master entry";
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.homeToolStripMenuItem.Text = "home";
            // 
            // userToolStripMenuItem
            // 
            this.userToolStripMenuItem.Name = "userToolStripMenuItem";
            this.userToolStripMenuItem.Size = new System.Drawing.Size(48, 24);
            this.userToolStripMenuItem.Text = "Users";
            // 
            // employeesToolStripMenuItem
            // 
            this.employeesToolStripMenuItem.Name = "employeesToolStripMenuItem";
            this.employeesToolStripMenuItem.Size = new System.Drawing.Size(75, 24);
            this.employeesToolStripMenuItem.Text = "Employees";
            // 
            // studentToolStripMenuItem
            // 
            this.studentToolStripMenuItem.Name = "studentToolStripMenuItem";
            this.studentToolStripMenuItem.Size = new System.Drawing.Size(61, 24);
            this.studentToolStripMenuItem.Text = "Student";
            // 
            // transactionToolStripMenuItem
            // 
            this.transactionToolStripMenuItem.Name = "transactionToolStripMenuItem";
            this.transactionToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.transactionToolStripMenuItem.Text = "Transaction";
            // 
            // recordsToolStripMenuItem
            // 
            this.recordsToolStripMenuItem.Name = "recordsToolStripMenuItem";
            this.recordsToolStripMenuItem.Size = new System.Drawing.Size(60, 24);
            this.recordsToolStripMenuItem.Text = "Records";
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(47, 24);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // fAQToolStripMenuItem
            // 
            this.fAQToolStripMenuItem.Name = "fAQToolStripMenuItem";
            this.fAQToolStripMenuItem.Size = new System.Drawing.Size(43, 24);
            this.fAQToolStripMenuItem.Text = "FAQ";
            // 
            // databaseRecoveryToolStripMenuItem
            // 
            this.databaseRecoveryToolStripMenuItem.Name = "databaseRecoveryToolStripMenuItem";
            this.databaseRecoveryToolStripMenuItem.Size = new System.Drawing.Size(117, 24);
            this.databaseRecoveryToolStripMenuItem.Text = "Database Recovery";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(50, 24);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(62, 24);
            this.logOutToolStripMenuItem.Text = "Log Out";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Coral;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = global::schoolSystem.Properties.Resources.info;
            this.button2.Location = new System.Drawing.Point(243, 385);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(120, 115);
            this.button2.TabIndex = 6;
            this.button2.Text = "Helps";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // home
            // 
            this.AccessibleName = "";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::schoolSystem.Properties.Resources.unnamed__1_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(847, 503);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.btn_settings);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.panel1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_info;
        private System.Windows.Forms.Button btn_settings;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btn_Personal;
        private System.Windows.Forms.Button btn_new_contact;
        private System.Windows.Forms.Button btn_registration;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fAQToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem databaseRecoveryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.Button button2;
    }
}