﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace schoolSystem
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_registration_Click(object sender, EventArgs e)
        {
            Registration objreg = new Registration();

            objreg.Show();
            this.Hide();
            
 
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Student_Fee fee = new Student_Fee();
            fee.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student_Profile d = new Student_Profile();
            d.Show();
            this.Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void btn_new_contact_Click(object sender, EventArgs e)
        {
            emp_profile emp = new emp_profile();
            emp.Show();
            this.Hide();
        }
    }
}
