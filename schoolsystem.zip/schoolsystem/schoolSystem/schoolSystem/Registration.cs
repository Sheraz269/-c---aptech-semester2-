﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace schoolSystem
{
    public partial class Registration : Form
    {
        string gender;
        public Registration()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)//student button
        {
            panel_teacher_reg.Visible = false;
            button2.Visible = false;
            label26.Visible = false;

            panel_student_reg.Visible = true;
            teacher_btn.Visible = true;
            label25.Visible = true;
        }

        private void button9_Click(object sender, EventArgs e)//teacher button
        {
            panel_student_reg.Visible = true;
            panel_teacher_reg.Visible = true;
            button2.Visible = true;
            label26.Visible = true;
            teacher_btn.Visible = false;
            label25.Visible = false;

        }

        private void label27_Click(object sender, EventArgs e)
        {
            ///////////////////////////////////////////////////////////////////
        }

        private void panel_teacher_reg_Paint(object sender, PaintEventArgs e)
        {
            /////////////////////////////////////
        }

        private void panel_student_reg_Paint(object sender, PaintEventArgs e)
        {
            ///////////////////////////////////////
        }

        private void Registration_Load(object sender, EventArgs e)
        {

        }

        private void ssubmit_Click(object sender, EventArgs e)
        {

            string conect = "Data Source=DESKTOP-FKROUFO;Initial Catalog=sklsystem;User ID=sa;Password=123";
            string query = "insert into student_Registration(student_Name, FatherName, Home_addres, gender, city,country,father_occ, email, mobileNo, religion, dateOfbirth, branch, shiftt) values('"+ sname.Text +"' , '" +sfname.Text +"', '" + shomeadress.Text +"', '" + gender+"', '" + scity.Text + "', '" +scountry.Text +"', '" +sfatheroc.Text +"', '" +semail.Text +"', '" +smobileno.Text +"', '" +sreligion.Text +"', '" +sdate.Text +"', '" +sadmision.Text + "', '" +sfee.Text +"', '" +sbranch.Text +"', '" +sshift.Text +"')";


            SqlConnection conn =  new SqlConnection(conect);
            SqlCommand cmd = new SqlCommand (query, conn);
            SqlDataReader sdr;

            try
            {
                conn.Open();
                sdr = cmd.ExecuteReader();
                MessageBox.Show("Saved");
                while (sdr.Read()) { }
             }
            catch(Exception es){

                MessageBox.Show(es.Message);
            }
            conn.Close();
        }

        private void smale_CheckedChanged(object sender, EventArgs e)
        {
            gender = "male";
        }

        private void sfemale_CheckedChanged(object sender, EventArgs e)
        {
            gender = "female";
        }

        private void sreset_Click(object sender, EventArgs e)
        {
            sname = null;
            sfname = null;
            shomeadress = null;
            smale.Select();
            scity = null;
            scountry = null;
            sfatheroc = null;
            semail = null;
            smobileno = null;
            sreligion = null;
            sdate = null;
            sadmision = null;
            sfee = null;
            sbranch = null;
            sshift= null;
            spicture = null;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            home obj = new home();
            obj.Show();
            this.Hide();
        }
    }
}
