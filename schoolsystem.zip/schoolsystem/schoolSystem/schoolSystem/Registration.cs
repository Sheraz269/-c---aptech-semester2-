﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace schoolSystem
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)//student button
        {
            panel_teacher_reg.Visible = false;
            button2.Visible = false;
            panel_student_reg.Visible = true;
            label26.Visible = false;
            teacher_btn.Visible = true;
            label25.Visible = true;
        }

        private void button9_Click(object sender, EventArgs e)//teacher button
        {
            panel_student_reg.Visible = false;
            panel_teacher_reg.Visible = true;
            button2.Visible = true;
            label26.Visible = true;
            teacher_btn.Visible = false;
            label25.Visible = false;

        }

        private void label27_Click(object sender, EventArgs e)
        {
            ///////////////////////////////////////////////////////////////////
        }

        private void panel_teacher_reg_Paint(object sender, PaintEventArgs e)
        {
            /////////////////////////////////////
        }

        private void panel_student_reg_Paint(object sender, PaintEventArgs e)
        {
            ///////////////////////////////////////
        }
    }
}
