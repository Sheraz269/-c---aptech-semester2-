﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace schoolSystem
{
    public partial class Student_Profile : Form
    {
        public Student_Profile()
        {
            InitializeComponent();
        }

        private void Student_Profile_Load(object sender, EventArgs e)
        {
            int n = 0;

            n = dataGridView1.Rows.Add();
            dataGridView1.Rows[n].Cells[0].Value = "EE206";
            dataGridView1.Rows[n].Cells[1].Value = "Syed Moiz Ur Rahman";
            dataGridView1.Rows[n].Cells[2].Value = "Information Technology";
            dataGridView1.Rows[n].Cells[3].Value = "Male";
            dataGridView1.Rows[n].Cells[4].Value = "Morning";
            dataGridView1.Rows[n].Cells[5].Value = "250000";

            n = dataGridView1.Rows.Add();
            dataGridView1.Rows[n].Cells[0].Value = "EE207";
            dataGridView1.Rows[n].Cells[1].Value = "Muneeba khan";
            dataGridView1.Rows[n].Cells[2].Value = "QA";
            dataGridView1.Rows[n].Cells[3].Value = "female";
            dataGridView1.Rows[n].Cells[4].Value = "Morning";
            dataGridView1.Rows[n].Cells[5].Value = "55000";

            n = dataGridView1.Rows.Add();
            dataGridView1.Rows[n].Cells[0].Value = "EE208";
            dataGridView1.Rows[n].Cells[1].Value = "Sheraz Ahmed";
            dataGridView1.Rows[n].Cells[2].Value = "Fianance";
            dataGridView1.Rows[n].Cells[3].Value = "Male";
            dataGridView1.Rows[n].Cells[4].Value = "Morning";
            dataGridView1.Rows[n].Cells[5].Value = "2000";

            n = dataGridView1.Rows.Add();
            dataGridView1.Rows[n].Cells[0].Value = "EE209";
            dataGridView1.Rows[n].Cells[1].Value = "Sawera Haq";
            dataGridView1.Rows[n].Cells[2].Value = "Information Technology";
            dataGridView1.Rows[n].Cells[3].Value = "female";
            dataGridView1.Rows[n].Cells[4].Value = "Morning";
            dataGridView1.Rows[n].Cells[5].Value = "150000";

            
        }
    }
}
