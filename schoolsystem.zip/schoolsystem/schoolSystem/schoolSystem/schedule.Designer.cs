﻿namespace schoolSystem
{
    partial class schedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label333 = new System.Windows.Forms.Label();
            this.label334 = new System.Windows.Forms.Label();
            this.label335 = new System.Windows.Forms.Label();
            this.label336 = new System.Windows.Forms.Label();
            this.label337 = new System.Windows.Forms.Label();
            this.label338 = new System.Windows.Forms.Label();
            this.label339 = new System.Windows.Forms.Label();
            this.label340 = new System.Windows.Forms.Label();
            this.label341 = new System.Windows.Forms.Label();
            this.label342 = new System.Windows.Forms.Label();
            this.label343 = new System.Windows.Forms.Label();
            this.label344 = new System.Windows.Forms.Label();
            this.label345 = new System.Windows.Forms.Label();
            this.label346 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label347 = new System.Windows.Forms.Label();
            this.label348 = new System.Windows.Forms.Label();
            this.label349 = new System.Windows.Forms.Label();
            this.label350 = new System.Windows.Forms.Label();
            this.label351 = new System.Windows.Forms.Label();
            this.label352 = new System.Windows.Forms.Label();
            this.label353 = new System.Windows.Forms.Label();
            this.label354 = new System.Windows.Forms.Label();
            this.label355 = new System.Windows.Forms.Label();
            this.label356 = new System.Windows.Forms.Label();
            this.label357 = new System.Windows.Forms.Label();
            this.label358 = new System.Windows.Forms.Label();
            this.label359 = new System.Windows.Forms.Label();
            this.label360 = new System.Windows.Forms.Label();
            this.label361 = new System.Windows.Forms.Label();
            this.label362 = new System.Windows.Forms.Label();
            this.label363 = new System.Windows.Forms.Label();
            this.label364 = new System.Windows.Forms.Label();
            this.label365 = new System.Windows.Forms.Label();
            this.label366 = new System.Windows.Forms.Label();
            this.label367 = new System.Windows.Forms.Label();
            this.label368 = new System.Windows.Forms.Label();
            this.label369 = new System.Windows.Forms.Label();
            this.label370 = new System.Windows.Forms.Label();
            this.label371 = new System.Windows.Forms.Label();
            this.label372 = new System.Windows.Forms.Label();
            this.label373 = new System.Windows.Forms.Label();
            this.label374 = new System.Windows.Forms.Label();
            this.label375 = new System.Windows.Forms.Label();
            this.label376 = new System.Windows.Forms.Label();
            this.label377 = new System.Windows.Forms.Label();
            this.label378 = new System.Windows.Forms.Label();
            this.label379 = new System.Windows.Forms.Label();
            this.label380 = new System.Windows.Forms.Label();
            this.label381 = new System.Windows.Forms.Label();
            this.label382 = new System.Windows.Forms.Label();
            this.label383 = new System.Windows.Forms.Label();
            this.label384 = new System.Windows.Forms.Label();
            this.label385 = new System.Windows.Forms.Label();
            this.label386 = new System.Windows.Forms.Label();
            this.label387 = new System.Windows.Forms.Label();
            this.label388 = new System.Windows.Forms.Label();
            this.label389 = new System.Windows.Forms.Label();
            this.label390 = new System.Windows.Forms.Label();
            this.label391 = new System.Windows.Forms.Label();
            this.label392 = new System.Windows.Forms.Label();
            this.label393 = new System.Windows.Forms.Label();
            this.label394 = new System.Windows.Forms.Label();
            this.label395 = new System.Windows.Forms.Label();
            this.label396 = new System.Windows.Forms.Label();
            this.label397 = new System.Windows.Forms.Label();
            this.label398 = new System.Windows.Forms.Label();
            this.label399 = new System.Windows.Forms.Label();
            this.label400 = new System.Windows.Forms.Label();
            this.label401 = new System.Windows.Forms.Label();
            this.label402 = new System.Windows.Forms.Label();
            this.label403 = new System.Windows.Forms.Label();
            this.label404 = new System.Windows.Forms.Label();
            this.label405 = new System.Windows.Forms.Label();
            this.label406 = new System.Windows.Forms.Label();
            this.label407 = new System.Windows.Forms.Label();
            this.label408 = new System.Windows.Forms.Label();
            this.label409 = new System.Windows.Forms.Label();
            this.label410 = new System.Windows.Forms.Label();
            this.label411 = new System.Windows.Forms.Label();
            this.label412 = new System.Windows.Forms.Label();
            this.label413 = new System.Windows.Forms.Label();
            this.label414 = new System.Windows.Forms.Label();
            this.label415 = new System.Windows.Forms.Label();
            this.label416 = new System.Windows.Forms.Label();
            this.label417 = new System.Windows.Forms.Label();
            this.label418 = new System.Windows.Forms.Label();
            this.label419 = new System.Windows.Forms.Label();
            this.label420 = new System.Windows.Forms.Label();
            this.label421 = new System.Windows.Forms.Label();
            this.label422 = new System.Windows.Forms.Label();
            this.label423 = new System.Windows.Forms.Label();
            this.label424 = new System.Windows.Forms.Label();
            this.label425 = new System.Windows.Forms.Label();
            this.label426 = new System.Windows.Forms.Label();
            this.label427 = new System.Windows.Forms.Label();
            this.label428 = new System.Windows.Forms.Label();
            this.label429 = new System.Windows.Forms.Label();
            this.label430 = new System.Windows.Forms.Label();
            this.label431 = new System.Windows.Forms.Label();
            this.label432 = new System.Windows.Forms.Label();
            this.label433 = new System.Windows.Forms.Label();
            this.label434 = new System.Windows.Forms.Label();
            this.label435 = new System.Windows.Forms.Label();
            this.label436 = new System.Windows.Forms.Label();
            this.label437 = new System.Windows.Forms.Label();
            this.label438 = new System.Windows.Forms.Label();
            this.label439 = new System.Windows.Forms.Label();
            this.label226 = new System.Windows.Forms.Label();
            this.label227 = new System.Windows.Forms.Label();
            this.label228 = new System.Windows.Forms.Label();
            this.label229 = new System.Windows.Forms.Label();
            this.label230 = new System.Windows.Forms.Label();
            this.label231 = new System.Windows.Forms.Label();
            this.label232 = new System.Windows.Forms.Label();
            this.label233 = new System.Windows.Forms.Label();
            this.label234 = new System.Windows.Forms.Label();
            this.label235 = new System.Windows.Forms.Label();
            this.label236 = new System.Windows.Forms.Label();
            this.label237 = new System.Windows.Forms.Label();
            this.label238 = new System.Windows.Forms.Label();
            this.label239 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label240 = new System.Windows.Forms.Label();
            this.label241 = new System.Windows.Forms.Label();
            this.label242 = new System.Windows.Forms.Label();
            this.label243 = new System.Windows.Forms.Label();
            this.label244 = new System.Windows.Forms.Label();
            this.label245 = new System.Windows.Forms.Label();
            this.label246 = new System.Windows.Forms.Label();
            this.label247 = new System.Windows.Forms.Label();
            this.label248 = new System.Windows.Forms.Label();
            this.label249 = new System.Windows.Forms.Label();
            this.label250 = new System.Windows.Forms.Label();
            this.label251 = new System.Windows.Forms.Label();
            this.label252 = new System.Windows.Forms.Label();
            this.label253 = new System.Windows.Forms.Label();
            this.label254 = new System.Windows.Forms.Label();
            this.label255 = new System.Windows.Forms.Label();
            this.label256 = new System.Windows.Forms.Label();
            this.label257 = new System.Windows.Forms.Label();
            this.label258 = new System.Windows.Forms.Label();
            this.label259 = new System.Windows.Forms.Label();
            this.label260 = new System.Windows.Forms.Label();
            this.label261 = new System.Windows.Forms.Label();
            this.label262 = new System.Windows.Forms.Label();
            this.label263 = new System.Windows.Forms.Label();
            this.label264 = new System.Windows.Forms.Label();
            this.label265 = new System.Windows.Forms.Label();
            this.label266 = new System.Windows.Forms.Label();
            this.label267 = new System.Windows.Forms.Label();
            this.label268 = new System.Windows.Forms.Label();
            this.label269 = new System.Windows.Forms.Label();
            this.label270 = new System.Windows.Forms.Label();
            this.label271 = new System.Windows.Forms.Label();
            this.label272 = new System.Windows.Forms.Label();
            this.label273 = new System.Windows.Forms.Label();
            this.label274 = new System.Windows.Forms.Label();
            this.label275 = new System.Windows.Forms.Label();
            this.label276 = new System.Windows.Forms.Label();
            this.label277 = new System.Windows.Forms.Label();
            this.label278 = new System.Windows.Forms.Label();
            this.label279 = new System.Windows.Forms.Label();
            this.label280 = new System.Windows.Forms.Label();
            this.label281 = new System.Windows.Forms.Label();
            this.label282 = new System.Windows.Forms.Label();
            this.label283 = new System.Windows.Forms.Label();
            this.label284 = new System.Windows.Forms.Label();
            this.label285 = new System.Windows.Forms.Label();
            this.label286 = new System.Windows.Forms.Label();
            this.label287 = new System.Windows.Forms.Label();
            this.label288 = new System.Windows.Forms.Label();
            this.label289 = new System.Windows.Forms.Label();
            this.label290 = new System.Windows.Forms.Label();
            this.label291 = new System.Windows.Forms.Label();
            this.label292 = new System.Windows.Forms.Label();
            this.label293 = new System.Windows.Forms.Label();
            this.label294 = new System.Windows.Forms.Label();
            this.label295 = new System.Windows.Forms.Label();
            this.label296 = new System.Windows.Forms.Label();
            this.label297 = new System.Windows.Forms.Label();
            this.label298 = new System.Windows.Forms.Label();
            this.label299 = new System.Windows.Forms.Label();
            this.label300 = new System.Windows.Forms.Label();
            this.label301 = new System.Windows.Forms.Label();
            this.label302 = new System.Windows.Forms.Label();
            this.label303 = new System.Windows.Forms.Label();
            this.label304 = new System.Windows.Forms.Label();
            this.label305 = new System.Windows.Forms.Label();
            this.label306 = new System.Windows.Forms.Label();
            this.label307 = new System.Windows.Forms.Label();
            this.label308 = new System.Windows.Forms.Label();
            this.label309 = new System.Windows.Forms.Label();
            this.label310 = new System.Windows.Forms.Label();
            this.label311 = new System.Windows.Forms.Label();
            this.label312 = new System.Windows.Forms.Label();
            this.label313 = new System.Windows.Forms.Label();
            this.label314 = new System.Windows.Forms.Label();
            this.label315 = new System.Windows.Forms.Label();
            this.label316 = new System.Windows.Forms.Label();
            this.label317 = new System.Windows.Forms.Label();
            this.label318 = new System.Windows.Forms.Label();
            this.label319 = new System.Windows.Forms.Label();
            this.label320 = new System.Windows.Forms.Label();
            this.label321 = new System.Windows.Forms.Label();
            this.label322 = new System.Windows.Forms.Label();
            this.label323 = new System.Windows.Forms.Label();
            this.label324 = new System.Windows.Forms.Label();
            this.label325 = new System.Windows.Forms.Label();
            this.label326 = new System.Windows.Forms.Label();
            this.label327 = new System.Windows.Forms.Label();
            this.label328 = new System.Windows.Forms.Label();
            this.label329 = new System.Windows.Forms.Label();
            this.label330 = new System.Windows.Forms.Label();
            this.label331 = new System.Windows.Forms.Label();
            this.label332 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.period_schedule = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label18 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.label160 = new System.Windows.Forms.Label();
            this.label161 = new System.Windows.Forms.Label();
            this.label162 = new System.Windows.Forms.Label();
            this.label163 = new System.Windows.Forms.Label();
            this.label164 = new System.Windows.Forms.Label();
            this.label165 = new System.Windows.Forms.Label();
            this.label166 = new System.Windows.Forms.Label();
            this.label167 = new System.Windows.Forms.Label();
            this.label168 = new System.Windows.Forms.Label();
            this.label169 = new System.Windows.Forms.Label();
            this.label170 = new System.Windows.Forms.Label();
            this.label171 = new System.Windows.Forms.Label();
            this.label172 = new System.Windows.Forms.Label();
            this.label173 = new System.Windows.Forms.Label();
            this.label174 = new System.Windows.Forms.Label();
            this.label175 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.label177 = new System.Windows.Forms.Label();
            this.label178 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.label181 = new System.Windows.Forms.Label();
            this.label182 = new System.Windows.Forms.Label();
            this.label183 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.label185 = new System.Windows.Forms.Label();
            this.label186 = new System.Windows.Forms.Label();
            this.label187 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.label189 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.label191 = new System.Windows.Forms.Label();
            this.label192 = new System.Windows.Forms.Label();
            this.label193 = new System.Windows.Forms.Label();
            this.label194 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.label196 = new System.Windows.Forms.Label();
            this.label197 = new System.Windows.Forms.Label();
            this.label198 = new System.Windows.Forms.Label();
            this.label199 = new System.Windows.Forms.Label();
            this.label200 = new System.Windows.Forms.Label();
            this.label201 = new System.Windows.Forms.Label();
            this.label202 = new System.Windows.Forms.Label();
            this.label203 = new System.Windows.Forms.Label();
            this.label204 = new System.Windows.Forms.Label();
            this.label205 = new System.Windows.Forms.Label();
            this.label206 = new System.Windows.Forms.Label();
            this.label207 = new System.Windows.Forms.Label();
            this.label208 = new System.Windows.Forms.Label();
            this.label209 = new System.Windows.Forms.Label();
            this.label210 = new System.Windows.Forms.Label();
            this.label211 = new System.Windows.Forms.Label();
            this.label212 = new System.Windows.Forms.Label();
            this.label213 = new System.Windows.Forms.Label();
            this.label214 = new System.Windows.Forms.Label();
            this.label215 = new System.Windows.Forms.Label();
            this.label216 = new System.Windows.Forms.Label();
            this.label217 = new System.Windows.Forms.Label();
            this.label218 = new System.Windows.Forms.Label();
            this.label219 = new System.Windows.Forms.Label();
            this.label220 = new System.Windows.Forms.Label();
            this.label221 = new System.Windows.Forms.Label();
            this.label222 = new System.Windows.Forms.Label();
            this.label223 = new System.Windows.Forms.Label();
            this.label224 = new System.Windows.Forms.Label();
            this.label225 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.period_schedule.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button4.Font = new System.Drawing.Font("Lucida Fax", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button4.Location = new System.Drawing.Point(856, 1);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(255, 55);
            this.button4.TabIndex = 3;
            this.button4.Text = "Final Term\'s";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkCyan;
            this.button1.Font = new System.Drawing.Font("Lucida Fax", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(11, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(255, 55);
            this.button1.TabIndex = 4;
            this.button1.Text = "Period\'s";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button2.Font = new System.Drawing.Font("Lucida Fax", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Location = new System.Drawing.Point(294, 1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(255, 55);
            this.button2.TabIndex = 5;
            this.button2.Text = "First Term\'s";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button3.Font = new System.Drawing.Font("Lucida Fax", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button3.Location = new System.Drawing.Point(575, 1);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(255, 55);
            this.button3.TabIndex = 6;
            this.button3.Text = "Second Term\'s";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Lavender;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.panel1.Location = new System.Drawing.Point(22, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1056, 644);
            this.panel1.TabIndex = 63;
            this.panel1.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Lavender;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.label226);
            this.panel2.Controls.Add(this.label227);
            this.panel2.Controls.Add(this.label228);
            this.panel2.Controls.Add(this.label229);
            this.panel2.Controls.Add(this.label230);
            this.panel2.Controls.Add(this.label231);
            this.panel2.Controls.Add(this.label232);
            this.panel2.Controls.Add(this.label233);
            this.panel2.Controls.Add(this.label234);
            this.panel2.Controls.Add(this.label235);
            this.panel2.Controls.Add(this.label236);
            this.panel2.Controls.Add(this.label237);
            this.panel2.Controls.Add(this.label238);
            this.panel2.Controls.Add(this.label239);
            this.panel2.Controls.Add(this.button7);
            this.panel2.Controls.Add(this.tableLayoutPanel3);
            this.panel2.Controls.Add(this.label320);
            this.panel2.Controls.Add(this.label321);
            this.panel2.Controls.Add(this.label322);
            this.panel2.Controls.Add(this.label323);
            this.panel2.Controls.Add(this.label324);
            this.panel2.Controls.Add(this.label325);
            this.panel2.Controls.Add(this.label326);
            this.panel2.Controls.Add(this.label327);
            this.panel2.Controls.Add(this.label328);
            this.panel2.Controls.Add(this.label329);
            this.panel2.Controls.Add(this.label330);
            this.panel2.Controls.Add(this.label331);
            this.panel2.Controls.Add(this.label332);
            this.panel2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1056, 644);
            this.panel2.TabIndex = 62;
            this.panel2.Visible = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Lavender;
            this.panel3.Controls.Add(this.label333);
            this.panel3.Controls.Add(this.label334);
            this.panel3.Controls.Add(this.label335);
            this.panel3.Controls.Add(this.label336);
            this.panel3.Controls.Add(this.label337);
            this.panel3.Controls.Add(this.label338);
            this.panel3.Controls.Add(this.label339);
            this.panel3.Controls.Add(this.label340);
            this.panel3.Controls.Add(this.label341);
            this.panel3.Controls.Add(this.label342);
            this.panel3.Controls.Add(this.label343);
            this.panel3.Controls.Add(this.label344);
            this.panel3.Controls.Add(this.label345);
            this.panel3.Controls.Add(this.label346);
            this.panel3.Controls.Add(this.button8);
            this.panel3.Controls.Add(this.tableLayoutPanel4);
            this.panel3.Controls.Add(this.label427);
            this.panel3.Controls.Add(this.label428);
            this.panel3.Controls.Add(this.label429);
            this.panel3.Controls.Add(this.label430);
            this.panel3.Controls.Add(this.label431);
            this.panel3.Controls.Add(this.label432);
            this.panel3.Controls.Add(this.label433);
            this.panel3.Controls.Add(this.label434);
            this.panel3.Controls.Add(this.label435);
            this.panel3.Controls.Add(this.label436);
            this.panel3.Controls.Add(this.label437);
            this.panel3.Controls.Add(this.label438);
            this.panel3.Controls.Add(this.label439);
            this.panel3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1056, 644);
            this.panel3.TabIndex = 62;
            this.panel3.Visible = false;
            // 
            // label333
            // 
            this.label333.BackColor = System.Drawing.Color.AliceBlue;
            this.label333.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label333.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label333.Location = new System.Drawing.Point(881, 32);
            this.label333.Name = "label333";
            this.label333.Size = new System.Drawing.Size(100, 26);
            this.label333.TabIndex = 43;
            this.label333.Text = "day";
            this.label333.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label334
            // 
            this.label334.BackColor = System.Drawing.Color.AliceBlue;
            this.label334.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label334.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label334.Location = new System.Drawing.Point(881, 4);
            this.label334.Name = "label334";
            this.label334.Size = new System.Drawing.Size(100, 26);
            this.label334.TabIndex = 42;
            this.label334.Text = "Date";
            this.label334.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label335
            // 
            this.label335.BackColor = System.Drawing.Color.AliceBlue;
            this.label335.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label335.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label335.Location = new System.Drawing.Point(777, 32);
            this.label335.Name = "label335";
            this.label335.Size = new System.Drawing.Size(100, 26);
            this.label335.TabIndex = 41;
            this.label335.Text = "day";
            this.label335.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label336
            // 
            this.label336.BackColor = System.Drawing.Color.AliceBlue;
            this.label336.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label336.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label336.Location = new System.Drawing.Point(777, 4);
            this.label336.Name = "label336";
            this.label336.Size = new System.Drawing.Size(100, 26);
            this.label336.TabIndex = 40;
            this.label336.Text = "Date";
            this.label336.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label337
            // 
            this.label337.BackColor = System.Drawing.Color.AliceBlue;
            this.label337.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label337.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label337.Location = new System.Drawing.Point(673, 32);
            this.label337.Name = "label337";
            this.label337.Size = new System.Drawing.Size(100, 26);
            this.label337.TabIndex = 39;
            this.label337.Text = "day";
            this.label337.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label338
            // 
            this.label338.BackColor = System.Drawing.Color.AliceBlue;
            this.label338.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label338.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label338.Location = new System.Drawing.Point(673, 4);
            this.label338.Name = "label338";
            this.label338.Size = new System.Drawing.Size(100, 26);
            this.label338.TabIndex = 38;
            this.label338.Text = "Date";
            this.label338.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label339
            // 
            this.label339.BackColor = System.Drawing.Color.AliceBlue;
            this.label339.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label339.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label339.Location = new System.Drawing.Point(569, 32);
            this.label339.Name = "label339";
            this.label339.Size = new System.Drawing.Size(100, 26);
            this.label339.TabIndex = 37;
            this.label339.Text = "day";
            this.label339.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label340
            // 
            this.label340.BackColor = System.Drawing.Color.AliceBlue;
            this.label340.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label340.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label340.Location = new System.Drawing.Point(569, 4);
            this.label340.Name = "label340";
            this.label340.Size = new System.Drawing.Size(100, 26);
            this.label340.TabIndex = 36;
            this.label340.Text = "Date";
            this.label340.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label341
            // 
            this.label341.BackColor = System.Drawing.Color.AliceBlue;
            this.label341.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label341.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label341.Location = new System.Drawing.Point(465, 32);
            this.label341.Name = "label341";
            this.label341.Size = new System.Drawing.Size(100, 26);
            this.label341.TabIndex = 35;
            this.label341.Text = "day";
            this.label341.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label342
            // 
            this.label342.BackColor = System.Drawing.Color.AliceBlue;
            this.label342.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label342.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label342.Location = new System.Drawing.Point(465, 4);
            this.label342.Name = "label342";
            this.label342.Size = new System.Drawing.Size(100, 26);
            this.label342.TabIndex = 34;
            this.label342.Text = "Date";
            this.label342.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label343
            // 
            this.label343.BackColor = System.Drawing.Color.AliceBlue;
            this.label343.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label343.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label343.Location = new System.Drawing.Point(361, 32);
            this.label343.Name = "label343";
            this.label343.Size = new System.Drawing.Size(100, 26);
            this.label343.TabIndex = 33;
            this.label343.Text = "day";
            this.label343.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label344
            // 
            this.label344.BackColor = System.Drawing.Color.AliceBlue;
            this.label344.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label344.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label344.Location = new System.Drawing.Point(361, 4);
            this.label344.Name = "label344";
            this.label344.Size = new System.Drawing.Size(100, 26);
            this.label344.TabIndex = 32;
            this.label344.Text = "Date";
            this.label344.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label345
            // 
            this.label345.BackColor = System.Drawing.Color.AliceBlue;
            this.label345.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label345.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label345.Location = new System.Drawing.Point(257, 32);
            this.label345.Name = "label345";
            this.label345.Size = new System.Drawing.Size(100, 26);
            this.label345.TabIndex = 31;
            this.label345.Text = "day";
            this.label345.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label346
            // 
            this.label346.BackColor = System.Drawing.Color.AliceBlue;
            this.label346.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label346.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label346.Location = new System.Drawing.Point(257, 4);
            this.label346.Name = "label346";
            this.label346.Size = new System.Drawing.Size(100, 26);
            this.label346.TabIndex = 30;
            this.label346.Text = "Date";
            this.label346.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button8.Font = new System.Drawing.Font("Lucida Fax", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(983, 4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(70, 636);
            this.button8.TabIndex = 29;
            this.button8.Text = "\r\nE\r\nD\r\nI\r\nT";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel4.ColumnCount = 8;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Controls.Add(this.label347, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label348, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label349, 7, 9);
            this.tableLayoutPanel4.Controls.Add(this.label350, 6, 9);
            this.tableLayoutPanel4.Controls.Add(this.label351, 5, 9);
            this.tableLayoutPanel4.Controls.Add(this.label352, 4, 9);
            this.tableLayoutPanel4.Controls.Add(this.label353, 3, 9);
            this.tableLayoutPanel4.Controls.Add(this.label354, 2, 9);
            this.tableLayoutPanel4.Controls.Add(this.label355, 1, 9);
            this.tableLayoutPanel4.Controls.Add(this.label356, 0, 9);
            this.tableLayoutPanel4.Controls.Add(this.label357, 7, 8);
            this.tableLayoutPanel4.Controls.Add(this.label358, 6, 8);
            this.tableLayoutPanel4.Controls.Add(this.label359, 5, 8);
            this.tableLayoutPanel4.Controls.Add(this.label360, 4, 8);
            this.tableLayoutPanel4.Controls.Add(this.label361, 3, 8);
            this.tableLayoutPanel4.Controls.Add(this.label362, 2, 8);
            this.tableLayoutPanel4.Controls.Add(this.label363, 1, 8);
            this.tableLayoutPanel4.Controls.Add(this.label364, 0, 8);
            this.tableLayoutPanel4.Controls.Add(this.label365, 7, 7);
            this.tableLayoutPanel4.Controls.Add(this.label366, 6, 7);
            this.tableLayoutPanel4.Controls.Add(this.label367, 5, 7);
            this.tableLayoutPanel4.Controls.Add(this.label368, 4, 7);
            this.tableLayoutPanel4.Controls.Add(this.label369, 3, 7);
            this.tableLayoutPanel4.Controls.Add(this.label370, 2, 7);
            this.tableLayoutPanel4.Controls.Add(this.label371, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.label372, 0, 7);
            this.tableLayoutPanel4.Controls.Add(this.label373, 7, 6);
            this.tableLayoutPanel4.Controls.Add(this.label374, 6, 6);
            this.tableLayoutPanel4.Controls.Add(this.label375, 5, 6);
            this.tableLayoutPanel4.Controls.Add(this.label376, 4, 6);
            this.tableLayoutPanel4.Controls.Add(this.label377, 3, 6);
            this.tableLayoutPanel4.Controls.Add(this.label378, 2, 6);
            this.tableLayoutPanel4.Controls.Add(this.label379, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.label380, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.label381, 7, 5);
            this.tableLayoutPanel4.Controls.Add(this.label382, 6, 5);
            this.tableLayoutPanel4.Controls.Add(this.label383, 5, 5);
            this.tableLayoutPanel4.Controls.Add(this.label384, 4, 5);
            this.tableLayoutPanel4.Controls.Add(this.label385, 3, 5);
            this.tableLayoutPanel4.Controls.Add(this.label386, 2, 5);
            this.tableLayoutPanel4.Controls.Add(this.label387, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.label388, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.label389, 7, 4);
            this.tableLayoutPanel4.Controls.Add(this.label390, 6, 4);
            this.tableLayoutPanel4.Controls.Add(this.label391, 5, 4);
            this.tableLayoutPanel4.Controls.Add(this.label392, 4, 4);
            this.tableLayoutPanel4.Controls.Add(this.label393, 3, 4);
            this.tableLayoutPanel4.Controls.Add(this.label394, 2, 4);
            this.tableLayoutPanel4.Controls.Add(this.label395, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.label396, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label397, 7, 3);
            this.tableLayoutPanel4.Controls.Add(this.label398, 6, 3);
            this.tableLayoutPanel4.Controls.Add(this.label399, 5, 3);
            this.tableLayoutPanel4.Controls.Add(this.label400, 4, 3);
            this.tableLayoutPanel4.Controls.Add(this.label401, 3, 3);
            this.tableLayoutPanel4.Controls.Add(this.label402, 2, 3);
            this.tableLayoutPanel4.Controls.Add(this.label403, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.label404, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label405, 7, 2);
            this.tableLayoutPanel4.Controls.Add(this.label406, 6, 2);
            this.tableLayoutPanel4.Controls.Add(this.label407, 5, 2);
            this.tableLayoutPanel4.Controls.Add(this.label408, 4, 2);
            this.tableLayoutPanel4.Controls.Add(this.label409, 3, 2);
            this.tableLayoutPanel4.Controls.Add(this.label410, 2, 2);
            this.tableLayoutPanel4.Controls.Add(this.label411, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.label412, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label413, 7, 1);
            this.tableLayoutPanel4.Controls.Add(this.label414, 6, 1);
            this.tableLayoutPanel4.Controls.Add(this.label415, 5, 1);
            this.tableLayoutPanel4.Controls.Add(this.label416, 4, 1);
            this.tableLayoutPanel4.Controls.Add(this.label417, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.label418, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.label419, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.label420, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label421, 7, 0);
            this.tableLayoutPanel4.Controls.Add(this.label422, 6, 0);
            this.tableLayoutPanel4.Controls.Add(this.label423, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.label424, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.label425, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label426, 4, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(151, 61);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 10;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(830, 581);
            this.tableLayoutPanel4.TabIndex = 28;
            // 
            // label347
            // 
            this.label347.BackColor = System.Drawing.Color.AliceBlue;
            this.label347.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label347.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label347.Location = new System.Drawing.Point(214, 3);
            this.label347.Name = "label347";
            this.label347.Size = new System.Drawing.Size(95, 53);
            this.label347.TabIndex = 118;
            this.label347.Text = "Subject\r\nTeacher";
            this.label347.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label348
            // 
            this.label348.BackColor = System.Drawing.Color.AliceBlue;
            this.label348.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label348.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label348.Location = new System.Drawing.Point(110, 3);
            this.label348.Name = "label348";
            this.label348.Size = new System.Drawing.Size(95, 53);
            this.label348.TabIndex = 117;
            this.label348.Text = "Subject\r\nTeacher";
            this.label348.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label349
            // 
            this.label349.BackColor = System.Drawing.Color.AliceBlue;
            this.label349.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label349.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label349.Location = new System.Drawing.Point(731, 526);
            this.label349.Name = "label349";
            this.label349.Size = new System.Drawing.Size(92, 52);
            this.label349.TabIndex = 116;
            this.label349.Text = "Subject\r\nTeacher";
            this.label349.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label350
            // 
            this.label350.BackColor = System.Drawing.Color.AliceBlue;
            this.label350.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label350.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label350.Location = new System.Drawing.Point(627, 526);
            this.label350.Name = "label350";
            this.label350.Size = new System.Drawing.Size(95, 52);
            this.label350.TabIndex = 115;
            this.label350.Text = "Subject\r\nTeacher";
            this.label350.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label351
            // 
            this.label351.BackColor = System.Drawing.Color.AliceBlue;
            this.label351.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label351.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label351.Location = new System.Drawing.Point(524, 526);
            this.label351.Name = "label351";
            this.label351.Size = new System.Drawing.Size(94, 52);
            this.label351.TabIndex = 114;
            this.label351.Text = "Subject\r\nTeacher";
            this.label351.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label352
            // 
            this.label352.BackColor = System.Drawing.Color.AliceBlue;
            this.label352.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label352.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label352.Location = new System.Drawing.Point(420, 526);
            this.label352.Name = "label352";
            this.label352.Size = new System.Drawing.Size(95, 52);
            this.label352.TabIndex = 113;
            this.label352.Text = "Subject\r\nTeacher";
            this.label352.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label353
            // 
            this.label353.BackColor = System.Drawing.Color.AliceBlue;
            this.label353.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label353.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label353.Location = new System.Drawing.Point(318, 526);
            this.label353.Name = "label353";
            this.label353.Size = new System.Drawing.Size(93, 52);
            this.label353.TabIndex = 111;
            this.label353.Text = "Subject\r\nTeacher";
            this.label353.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label354
            // 
            this.label354.BackColor = System.Drawing.Color.AliceBlue;
            this.label354.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label354.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label354.Location = new System.Drawing.Point(214, 526);
            this.label354.Name = "label354";
            this.label354.Size = new System.Drawing.Size(95, 52);
            this.label354.TabIndex = 110;
            this.label354.Text = "Subject\r\nTeacher";
            this.label354.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label355
            // 
            this.label355.BackColor = System.Drawing.Color.AliceBlue;
            this.label355.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label355.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label355.Location = new System.Drawing.Point(110, 526);
            this.label355.Name = "label355";
            this.label355.Size = new System.Drawing.Size(95, 52);
            this.label355.TabIndex = 109;
            this.label355.Text = "Subject\r\nTeacher";
            this.label355.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label356
            // 
            this.label356.BackColor = System.Drawing.Color.AliceBlue;
            this.label356.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label356.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label356.Location = new System.Drawing.Point(6, 526);
            this.label356.Name = "label356";
            this.label356.Size = new System.Drawing.Size(95, 52);
            this.label356.TabIndex = 108;
            this.label356.Text = "Subject\r\nTeacher";
            this.label356.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label357
            // 
            this.label357.BackColor = System.Drawing.Color.AliceBlue;
            this.label357.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label357.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label357.Location = new System.Drawing.Point(731, 468);
            this.label357.Name = "label357";
            this.label357.Size = new System.Drawing.Size(92, 53);
            this.label357.TabIndex = 107;
            this.label357.Text = "Subject\r\nTeacher";
            this.label357.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label358
            // 
            this.label358.BackColor = System.Drawing.Color.AliceBlue;
            this.label358.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label358.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label358.Location = new System.Drawing.Point(627, 468);
            this.label358.Name = "label358";
            this.label358.Size = new System.Drawing.Size(95, 53);
            this.label358.TabIndex = 106;
            this.label358.Text = "Subject\r\nTeacher";
            this.label358.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label359
            // 
            this.label359.BackColor = System.Drawing.Color.AliceBlue;
            this.label359.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label359.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label359.Location = new System.Drawing.Point(524, 468);
            this.label359.Name = "label359";
            this.label359.Size = new System.Drawing.Size(94, 53);
            this.label359.TabIndex = 105;
            this.label359.Text = "Subject\r\nTeacher";
            this.label359.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label360
            // 
            this.label360.BackColor = System.Drawing.Color.AliceBlue;
            this.label360.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label360.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label360.Location = new System.Drawing.Point(420, 468);
            this.label360.Name = "label360";
            this.label360.Size = new System.Drawing.Size(95, 53);
            this.label360.TabIndex = 104;
            this.label360.Text = "Subject\r\nTeacher";
            this.label360.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label361
            // 
            this.label361.BackColor = System.Drawing.Color.AliceBlue;
            this.label361.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label361.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label361.Location = new System.Drawing.Point(318, 468);
            this.label361.Name = "label361";
            this.label361.Size = new System.Drawing.Size(93, 53);
            this.label361.TabIndex = 102;
            this.label361.Text = "Subject\r\nTeacher";
            this.label361.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label362
            // 
            this.label362.BackColor = System.Drawing.Color.AliceBlue;
            this.label362.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label362.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label362.Location = new System.Drawing.Point(214, 468);
            this.label362.Name = "label362";
            this.label362.Size = new System.Drawing.Size(95, 53);
            this.label362.TabIndex = 101;
            this.label362.Text = "Subject\r\nTeacher";
            this.label362.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label363
            // 
            this.label363.BackColor = System.Drawing.Color.AliceBlue;
            this.label363.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label363.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label363.Location = new System.Drawing.Point(110, 468);
            this.label363.Name = "label363";
            this.label363.Size = new System.Drawing.Size(95, 53);
            this.label363.TabIndex = 100;
            this.label363.Text = "Subject\r\nTeacher";
            this.label363.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label364
            // 
            this.label364.BackColor = System.Drawing.Color.AliceBlue;
            this.label364.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label364.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label364.Location = new System.Drawing.Point(6, 468);
            this.label364.Name = "label364";
            this.label364.Size = new System.Drawing.Size(95, 53);
            this.label364.TabIndex = 99;
            this.label364.Text = "Subject\r\nTeacher";
            this.label364.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label365
            // 
            this.label365.BackColor = System.Drawing.Color.AliceBlue;
            this.label365.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label365.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label365.Location = new System.Drawing.Point(731, 411);
            this.label365.Name = "label365";
            this.label365.Size = new System.Drawing.Size(92, 53);
            this.label365.TabIndex = 98;
            this.label365.Text = "Subject\r\nTeacher";
            this.label365.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label366
            // 
            this.label366.BackColor = System.Drawing.Color.AliceBlue;
            this.label366.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label366.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label366.Location = new System.Drawing.Point(627, 411);
            this.label366.Name = "label366";
            this.label366.Size = new System.Drawing.Size(95, 53);
            this.label366.TabIndex = 97;
            this.label366.Text = "Subject\r\nTeacher";
            this.label366.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label367
            // 
            this.label367.BackColor = System.Drawing.Color.AliceBlue;
            this.label367.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label367.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label367.Location = new System.Drawing.Point(524, 411);
            this.label367.Name = "label367";
            this.label367.Size = new System.Drawing.Size(94, 53);
            this.label367.TabIndex = 96;
            this.label367.Text = "Subject\r\nTeacher";
            this.label367.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label368
            // 
            this.label368.BackColor = System.Drawing.Color.AliceBlue;
            this.label368.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label368.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label368.Location = new System.Drawing.Point(420, 411);
            this.label368.Name = "label368";
            this.label368.Size = new System.Drawing.Size(95, 53);
            this.label368.TabIndex = 95;
            this.label368.Text = "Subject\r\nTeacher";
            this.label368.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label369
            // 
            this.label369.BackColor = System.Drawing.Color.AliceBlue;
            this.label369.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label369.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label369.Location = new System.Drawing.Point(318, 411);
            this.label369.Name = "label369";
            this.label369.Size = new System.Drawing.Size(93, 53);
            this.label369.TabIndex = 93;
            this.label369.Text = "Subject\r\nTeacher";
            this.label369.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label370
            // 
            this.label370.BackColor = System.Drawing.Color.AliceBlue;
            this.label370.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label370.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label370.Location = new System.Drawing.Point(214, 411);
            this.label370.Name = "label370";
            this.label370.Size = new System.Drawing.Size(95, 53);
            this.label370.TabIndex = 92;
            this.label370.Text = "Subject\r\nTeacher";
            this.label370.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label371
            // 
            this.label371.BackColor = System.Drawing.Color.AliceBlue;
            this.label371.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label371.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label371.Location = new System.Drawing.Point(110, 411);
            this.label371.Name = "label371";
            this.label371.Size = new System.Drawing.Size(95, 53);
            this.label371.TabIndex = 91;
            this.label371.Text = "Subject\r\nTeacher";
            this.label371.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label372
            // 
            this.label372.BackColor = System.Drawing.Color.AliceBlue;
            this.label372.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label372.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label372.Location = new System.Drawing.Point(6, 411);
            this.label372.Name = "label372";
            this.label372.Size = new System.Drawing.Size(95, 53);
            this.label372.TabIndex = 90;
            this.label372.Text = "Subject\r\nTeacher";
            this.label372.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label373
            // 
            this.label373.BackColor = System.Drawing.Color.AliceBlue;
            this.label373.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label373.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label373.Location = new System.Drawing.Point(731, 352);
            this.label373.Name = "label373";
            this.label373.Size = new System.Drawing.Size(92, 53);
            this.label373.TabIndex = 89;
            this.label373.Text = "Subject\r\nTeacher";
            this.label373.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label374
            // 
            this.label374.BackColor = System.Drawing.Color.AliceBlue;
            this.label374.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label374.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label374.Location = new System.Drawing.Point(627, 352);
            this.label374.Name = "label374";
            this.label374.Size = new System.Drawing.Size(95, 53);
            this.label374.TabIndex = 88;
            this.label374.Text = "Subject\r\nTeacher";
            this.label374.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label375
            // 
            this.label375.BackColor = System.Drawing.Color.AliceBlue;
            this.label375.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label375.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label375.Location = new System.Drawing.Point(524, 352);
            this.label375.Name = "label375";
            this.label375.Size = new System.Drawing.Size(94, 53);
            this.label375.TabIndex = 87;
            this.label375.Text = "Subject\r\nTeacher";
            this.label375.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label376
            // 
            this.label376.BackColor = System.Drawing.Color.AliceBlue;
            this.label376.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label376.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label376.Location = new System.Drawing.Point(420, 352);
            this.label376.Name = "label376";
            this.label376.Size = new System.Drawing.Size(95, 53);
            this.label376.TabIndex = 86;
            this.label376.Text = "Subject\r\nTeacher";
            this.label376.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label377
            // 
            this.label377.BackColor = System.Drawing.Color.AliceBlue;
            this.label377.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label377.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label377.Location = new System.Drawing.Point(318, 352);
            this.label377.Name = "label377";
            this.label377.Size = new System.Drawing.Size(93, 53);
            this.label377.TabIndex = 84;
            this.label377.Text = "Subject\r\nTeacher";
            this.label377.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label378
            // 
            this.label378.BackColor = System.Drawing.Color.AliceBlue;
            this.label378.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label378.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label378.Location = new System.Drawing.Point(214, 352);
            this.label378.Name = "label378";
            this.label378.Size = new System.Drawing.Size(95, 53);
            this.label378.TabIndex = 83;
            this.label378.Text = "Subject\r\nTeacher";
            this.label378.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label379
            // 
            this.label379.BackColor = System.Drawing.Color.AliceBlue;
            this.label379.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label379.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label379.Location = new System.Drawing.Point(110, 352);
            this.label379.Name = "label379";
            this.label379.Size = new System.Drawing.Size(95, 53);
            this.label379.TabIndex = 82;
            this.label379.Text = "Subject\r\nTeacher";
            this.label379.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label380
            // 
            this.label380.BackColor = System.Drawing.Color.AliceBlue;
            this.label380.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label380.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label380.Location = new System.Drawing.Point(6, 352);
            this.label380.Name = "label380";
            this.label380.Size = new System.Drawing.Size(95, 53);
            this.label380.TabIndex = 81;
            this.label380.Text = "Subject\r\nTeacher";
            this.label380.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label381
            // 
            this.label381.BackColor = System.Drawing.Color.AliceBlue;
            this.label381.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label381.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label381.Location = new System.Drawing.Point(731, 296);
            this.label381.Name = "label381";
            this.label381.Size = new System.Drawing.Size(92, 53);
            this.label381.TabIndex = 80;
            this.label381.Text = "Subject\r\nTeacher";
            this.label381.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label382
            // 
            this.label382.BackColor = System.Drawing.Color.AliceBlue;
            this.label382.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label382.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label382.Location = new System.Drawing.Point(627, 296);
            this.label382.Name = "label382";
            this.label382.Size = new System.Drawing.Size(95, 53);
            this.label382.TabIndex = 79;
            this.label382.Text = "Subject\r\nTeacher";
            this.label382.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label383
            // 
            this.label383.BackColor = System.Drawing.Color.AliceBlue;
            this.label383.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label383.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label383.Location = new System.Drawing.Point(524, 296);
            this.label383.Name = "label383";
            this.label383.Size = new System.Drawing.Size(94, 53);
            this.label383.TabIndex = 78;
            this.label383.Text = "Subject\r\nTeacher";
            this.label383.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label384
            // 
            this.label384.BackColor = System.Drawing.Color.AliceBlue;
            this.label384.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label384.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label384.Location = new System.Drawing.Point(420, 296);
            this.label384.Name = "label384";
            this.label384.Size = new System.Drawing.Size(95, 53);
            this.label384.TabIndex = 77;
            this.label384.Text = "Subject\r\nTeacher";
            this.label384.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label385
            // 
            this.label385.BackColor = System.Drawing.Color.AliceBlue;
            this.label385.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label385.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label385.Location = new System.Drawing.Point(318, 296);
            this.label385.Name = "label385";
            this.label385.Size = new System.Drawing.Size(93, 53);
            this.label385.TabIndex = 75;
            this.label385.Text = "Subject\r\nTeacher";
            this.label385.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label386
            // 
            this.label386.BackColor = System.Drawing.Color.AliceBlue;
            this.label386.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label386.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label386.Location = new System.Drawing.Point(214, 296);
            this.label386.Name = "label386";
            this.label386.Size = new System.Drawing.Size(95, 53);
            this.label386.TabIndex = 74;
            this.label386.Text = "Subject\r\nTeacher";
            this.label386.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label387
            // 
            this.label387.BackColor = System.Drawing.Color.AliceBlue;
            this.label387.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label387.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label387.Location = new System.Drawing.Point(110, 296);
            this.label387.Name = "label387";
            this.label387.Size = new System.Drawing.Size(95, 53);
            this.label387.TabIndex = 73;
            this.label387.Text = "Subject\r\nTeacher";
            this.label387.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label388
            // 
            this.label388.BackColor = System.Drawing.Color.AliceBlue;
            this.label388.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label388.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label388.Location = new System.Drawing.Point(6, 296);
            this.label388.Name = "label388";
            this.label388.Size = new System.Drawing.Size(95, 53);
            this.label388.TabIndex = 72;
            this.label388.Text = "Subject\r\nTeacher";
            this.label388.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label389
            // 
            this.label389.BackColor = System.Drawing.Color.AliceBlue;
            this.label389.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label389.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label389.Location = new System.Drawing.Point(731, 237);
            this.label389.Name = "label389";
            this.label389.Size = new System.Drawing.Size(92, 53);
            this.label389.TabIndex = 71;
            this.label389.Text = "Subject\r\nTeacher";
            this.label389.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label390
            // 
            this.label390.BackColor = System.Drawing.Color.AliceBlue;
            this.label390.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label390.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label390.Location = new System.Drawing.Point(627, 237);
            this.label390.Name = "label390";
            this.label390.Size = new System.Drawing.Size(95, 53);
            this.label390.TabIndex = 70;
            this.label390.Text = "Subject\r\nTeacher";
            this.label390.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label391
            // 
            this.label391.BackColor = System.Drawing.Color.AliceBlue;
            this.label391.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label391.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label391.Location = new System.Drawing.Point(524, 237);
            this.label391.Name = "label391";
            this.label391.Size = new System.Drawing.Size(94, 53);
            this.label391.TabIndex = 69;
            this.label391.Text = "Subject\r\nTeacher";
            this.label391.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label392
            // 
            this.label392.BackColor = System.Drawing.Color.AliceBlue;
            this.label392.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label392.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label392.Location = new System.Drawing.Point(420, 237);
            this.label392.Name = "label392";
            this.label392.Size = new System.Drawing.Size(95, 53);
            this.label392.TabIndex = 68;
            this.label392.Text = "Subject\r\nTeacher";
            this.label392.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label393
            // 
            this.label393.BackColor = System.Drawing.Color.AliceBlue;
            this.label393.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label393.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label393.Location = new System.Drawing.Point(318, 237);
            this.label393.Name = "label393";
            this.label393.Size = new System.Drawing.Size(93, 53);
            this.label393.TabIndex = 66;
            this.label393.Text = "Subject\r\nTeacher";
            this.label393.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label394
            // 
            this.label394.BackColor = System.Drawing.Color.AliceBlue;
            this.label394.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label394.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label394.Location = new System.Drawing.Point(214, 237);
            this.label394.Name = "label394";
            this.label394.Size = new System.Drawing.Size(95, 53);
            this.label394.TabIndex = 65;
            this.label394.Text = "Subject\r\nTeacher";
            this.label394.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label395
            // 
            this.label395.BackColor = System.Drawing.Color.AliceBlue;
            this.label395.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label395.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label395.Location = new System.Drawing.Point(110, 237);
            this.label395.Name = "label395";
            this.label395.Size = new System.Drawing.Size(95, 53);
            this.label395.TabIndex = 64;
            this.label395.Text = "Subject\r\nTeacher";
            this.label395.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label396
            // 
            this.label396.BackColor = System.Drawing.Color.AliceBlue;
            this.label396.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label396.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label396.Location = new System.Drawing.Point(6, 237);
            this.label396.Name = "label396";
            this.label396.Size = new System.Drawing.Size(95, 53);
            this.label396.TabIndex = 63;
            this.label396.Text = "Subject\r\nTeacher";
            this.label396.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label397
            // 
            this.label397.BackColor = System.Drawing.Color.AliceBlue;
            this.label397.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label397.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label397.Location = new System.Drawing.Point(731, 178);
            this.label397.Name = "label397";
            this.label397.Size = new System.Drawing.Size(92, 53);
            this.label397.TabIndex = 62;
            this.label397.Text = "Subject\r\nTeacher";
            this.label397.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label398
            // 
            this.label398.BackColor = System.Drawing.Color.AliceBlue;
            this.label398.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label398.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label398.Location = new System.Drawing.Point(627, 178);
            this.label398.Name = "label398";
            this.label398.Size = new System.Drawing.Size(95, 53);
            this.label398.TabIndex = 61;
            this.label398.Text = "Subject\r\nTeacher";
            this.label398.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label399
            // 
            this.label399.BackColor = System.Drawing.Color.AliceBlue;
            this.label399.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label399.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label399.Location = new System.Drawing.Point(524, 178);
            this.label399.Name = "label399";
            this.label399.Size = new System.Drawing.Size(94, 53);
            this.label399.TabIndex = 60;
            this.label399.Text = "Subject\r\nTeacher";
            this.label399.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label400
            // 
            this.label400.BackColor = System.Drawing.Color.AliceBlue;
            this.label400.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label400.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label400.Location = new System.Drawing.Point(420, 178);
            this.label400.Name = "label400";
            this.label400.Size = new System.Drawing.Size(95, 53);
            this.label400.TabIndex = 59;
            this.label400.Text = "Subject\r\nTeacher";
            this.label400.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label401
            // 
            this.label401.BackColor = System.Drawing.Color.AliceBlue;
            this.label401.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label401.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label401.Location = new System.Drawing.Point(318, 178);
            this.label401.Name = "label401";
            this.label401.Size = new System.Drawing.Size(93, 53);
            this.label401.TabIndex = 57;
            this.label401.Text = "Subject\r\nTeacher";
            this.label401.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label402
            // 
            this.label402.BackColor = System.Drawing.Color.AliceBlue;
            this.label402.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label402.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label402.Location = new System.Drawing.Point(214, 178);
            this.label402.Name = "label402";
            this.label402.Size = new System.Drawing.Size(95, 53);
            this.label402.TabIndex = 56;
            this.label402.Text = "Subject\r\nTeacher";
            this.label402.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label403
            // 
            this.label403.BackColor = System.Drawing.Color.AliceBlue;
            this.label403.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label403.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label403.Location = new System.Drawing.Point(110, 178);
            this.label403.Name = "label403";
            this.label403.Size = new System.Drawing.Size(95, 53);
            this.label403.TabIndex = 55;
            this.label403.Text = "Subject\r\nTeacher";
            this.label403.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label404
            // 
            this.label404.BackColor = System.Drawing.Color.AliceBlue;
            this.label404.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label404.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label404.Location = new System.Drawing.Point(6, 178);
            this.label404.Name = "label404";
            this.label404.Size = new System.Drawing.Size(95, 53);
            this.label404.TabIndex = 54;
            this.label404.Text = "Subject\r\nTeacher";
            this.label404.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label405
            // 
            this.label405.BackColor = System.Drawing.Color.AliceBlue;
            this.label405.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label405.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label405.Location = new System.Drawing.Point(731, 121);
            this.label405.Name = "label405";
            this.label405.Size = new System.Drawing.Size(92, 53);
            this.label405.TabIndex = 53;
            this.label405.Text = "Subject\r\nTeacher";
            this.label405.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label406
            // 
            this.label406.BackColor = System.Drawing.Color.AliceBlue;
            this.label406.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label406.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label406.Location = new System.Drawing.Point(627, 121);
            this.label406.Name = "label406";
            this.label406.Size = new System.Drawing.Size(95, 53);
            this.label406.TabIndex = 52;
            this.label406.Text = "Subject\r\nTeacher";
            this.label406.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label407
            // 
            this.label407.BackColor = System.Drawing.Color.AliceBlue;
            this.label407.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label407.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label407.Location = new System.Drawing.Point(524, 121);
            this.label407.Name = "label407";
            this.label407.Size = new System.Drawing.Size(94, 53);
            this.label407.TabIndex = 51;
            this.label407.Text = "Subject\r\nTeacher";
            this.label407.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label408
            // 
            this.label408.BackColor = System.Drawing.Color.AliceBlue;
            this.label408.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label408.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label408.Location = new System.Drawing.Point(420, 121);
            this.label408.Name = "label408";
            this.label408.Size = new System.Drawing.Size(95, 53);
            this.label408.TabIndex = 50;
            this.label408.Text = "Subject\r\nTeacher";
            this.label408.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label409
            // 
            this.label409.BackColor = System.Drawing.Color.AliceBlue;
            this.label409.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label409.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label409.Location = new System.Drawing.Point(318, 121);
            this.label409.Name = "label409";
            this.label409.Size = new System.Drawing.Size(93, 53);
            this.label409.TabIndex = 48;
            this.label409.Text = "Subject\r\nTeacher";
            this.label409.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label410
            // 
            this.label410.BackColor = System.Drawing.Color.AliceBlue;
            this.label410.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label410.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label410.Location = new System.Drawing.Point(214, 121);
            this.label410.Name = "label410";
            this.label410.Size = new System.Drawing.Size(95, 53);
            this.label410.TabIndex = 47;
            this.label410.Text = "Subject\r\nTeacher";
            this.label410.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label411
            // 
            this.label411.BackColor = System.Drawing.Color.AliceBlue;
            this.label411.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label411.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label411.Location = new System.Drawing.Point(110, 121);
            this.label411.Name = "label411";
            this.label411.Size = new System.Drawing.Size(95, 53);
            this.label411.TabIndex = 46;
            this.label411.Text = "Subject\r\nTeacher";
            this.label411.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label412
            // 
            this.label412.BackColor = System.Drawing.Color.AliceBlue;
            this.label412.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label412.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label412.Location = new System.Drawing.Point(6, 121);
            this.label412.Name = "label412";
            this.label412.Size = new System.Drawing.Size(95, 53);
            this.label412.TabIndex = 45;
            this.label412.Text = "Subject\r\nTeacher";
            this.label412.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label413
            // 
            this.label413.BackColor = System.Drawing.Color.AliceBlue;
            this.label413.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label413.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label413.Location = new System.Drawing.Point(731, 61);
            this.label413.Name = "label413";
            this.label413.Size = new System.Drawing.Size(92, 53);
            this.label413.TabIndex = 44;
            this.label413.Text = "Subject\r\nTeacher";
            this.label413.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label414
            // 
            this.label414.BackColor = System.Drawing.Color.AliceBlue;
            this.label414.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label414.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label414.Location = new System.Drawing.Point(627, 61);
            this.label414.Name = "label414";
            this.label414.Size = new System.Drawing.Size(95, 53);
            this.label414.TabIndex = 43;
            this.label414.Text = "Subject\r\nTeacher";
            this.label414.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label415
            // 
            this.label415.BackColor = System.Drawing.Color.AliceBlue;
            this.label415.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label415.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label415.Location = new System.Drawing.Point(524, 61);
            this.label415.Name = "label415";
            this.label415.Size = new System.Drawing.Size(94, 53);
            this.label415.TabIndex = 42;
            this.label415.Text = "Subject\r\nTeacher";
            this.label415.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label416
            // 
            this.label416.BackColor = System.Drawing.Color.AliceBlue;
            this.label416.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label416.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label416.Location = new System.Drawing.Point(420, 61);
            this.label416.Name = "label416";
            this.label416.Size = new System.Drawing.Size(95, 53);
            this.label416.TabIndex = 41;
            this.label416.Text = "Subject\r\nTeacher";
            this.label416.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label417
            // 
            this.label417.BackColor = System.Drawing.Color.AliceBlue;
            this.label417.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label417.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label417.Location = new System.Drawing.Point(318, 61);
            this.label417.Name = "label417";
            this.label417.Size = new System.Drawing.Size(93, 53);
            this.label417.TabIndex = 39;
            this.label417.Text = "Subject\r\nTeacher";
            this.label417.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label418
            // 
            this.label418.BackColor = System.Drawing.Color.AliceBlue;
            this.label418.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label418.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label418.Location = new System.Drawing.Point(214, 61);
            this.label418.Name = "label418";
            this.label418.Size = new System.Drawing.Size(95, 53);
            this.label418.TabIndex = 38;
            this.label418.Text = "Subject\r\nTeacher";
            this.label418.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label419
            // 
            this.label419.BackColor = System.Drawing.Color.AliceBlue;
            this.label419.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label419.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label419.Location = new System.Drawing.Point(110, 61);
            this.label419.Name = "label419";
            this.label419.Size = new System.Drawing.Size(95, 53);
            this.label419.TabIndex = 37;
            this.label419.Text = "Subject\r\nTeacher";
            this.label419.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label420
            // 
            this.label420.BackColor = System.Drawing.Color.AliceBlue;
            this.label420.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label420.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label420.Location = new System.Drawing.Point(6, 61);
            this.label420.Name = "label420";
            this.label420.Size = new System.Drawing.Size(95, 53);
            this.label420.TabIndex = 36;
            this.label420.Text = "Subject\r\nTeacher";
            this.label420.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label421
            // 
            this.label421.BackColor = System.Drawing.Color.AliceBlue;
            this.label421.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label421.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label421.Location = new System.Drawing.Point(731, 3);
            this.label421.Name = "label421";
            this.label421.Size = new System.Drawing.Size(92, 53);
            this.label421.TabIndex = 35;
            this.label421.Text = "Subject\r\nTeacher";
            this.label421.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label422
            // 
            this.label422.BackColor = System.Drawing.Color.AliceBlue;
            this.label422.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label422.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label422.Location = new System.Drawing.Point(627, 3);
            this.label422.Name = "label422";
            this.label422.Size = new System.Drawing.Size(95, 53);
            this.label422.TabIndex = 34;
            this.label422.Text = "Subject\r\nTeacher";
            this.label422.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label423
            // 
            this.label423.BackColor = System.Drawing.Color.AliceBlue;
            this.label423.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label423.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label423.Location = new System.Drawing.Point(524, 3);
            this.label423.Name = "label423";
            this.label423.Size = new System.Drawing.Size(94, 53);
            this.label423.TabIndex = 33;
            this.label423.Text = "Subject\r\nTeacher";
            this.label423.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label424
            // 
            this.label424.BackColor = System.Drawing.Color.AliceBlue;
            this.label424.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label424.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label424.Location = new System.Drawing.Point(318, 3);
            this.label424.Name = "label424";
            this.label424.Size = new System.Drawing.Size(93, 53);
            this.label424.TabIndex = 30;
            this.label424.Text = "Subject\r\nTeacher";
            this.label424.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label425
            // 
            this.label425.BackColor = System.Drawing.Color.AliceBlue;
            this.label425.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label425.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label425.Location = new System.Drawing.Point(6, 3);
            this.label425.Name = "label425";
            this.label425.Size = new System.Drawing.Size(95, 53);
            this.label425.TabIndex = 29;
            this.label425.Text = "Subject\r\nTiming";
            this.label425.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label426
            // 
            this.label426.BackColor = System.Drawing.Color.AliceBlue;
            this.label426.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label426.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label426.Location = new System.Drawing.Point(420, 3);
            this.label426.Name = "label426";
            this.label426.Size = new System.Drawing.Size(95, 53);
            this.label426.TabIndex = 31;
            this.label426.Text = "Subject\r\nTeacher";
            this.label426.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label427
            // 
            this.label427.BackColor = System.Drawing.Color.AliceBlue;
            this.label427.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label427.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label427.Location = new System.Drawing.Point(4, 584);
            this.label427.Name = "label427";
            this.label427.Size = new System.Drawing.Size(145, 55);
            this.label427.TabIndex = 27;
            this.label427.Text = "Class 10";
            this.label427.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label428
            // 
            this.label428.BackColor = System.Drawing.Color.AliceBlue;
            this.label428.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label428.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label428.Location = new System.Drawing.Point(4, 526);
            this.label428.Name = "label428";
            this.label428.Size = new System.Drawing.Size(145, 55);
            this.label428.TabIndex = 26;
            this.label428.Text = "Class 9";
            this.label428.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label429
            // 
            this.label429.BackColor = System.Drawing.Color.AliceBlue;
            this.label429.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label429.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label429.Location = new System.Drawing.Point(4, 468);
            this.label429.Name = "label429";
            this.label429.Size = new System.Drawing.Size(145, 55);
            this.label429.TabIndex = 25;
            this.label429.Text = "Class 8";
            this.label429.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label430
            // 
            this.label430.BackColor = System.Drawing.Color.AliceBlue;
            this.label430.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label430.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label430.Location = new System.Drawing.Point(4, 410);
            this.label430.Name = "label430";
            this.label430.Size = new System.Drawing.Size(145, 55);
            this.label430.TabIndex = 24;
            this.label430.Text = "Class 7";
            this.label430.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label431
            // 
            this.label431.BackColor = System.Drawing.Color.AliceBlue;
            this.label431.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label431.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label431.Location = new System.Drawing.Point(4, 352);
            this.label431.Name = "label431";
            this.label431.Size = new System.Drawing.Size(145, 55);
            this.label431.TabIndex = 23;
            this.label431.Text = "Class 6";
            this.label431.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label432
            // 
            this.label432.BackColor = System.Drawing.Color.AliceBlue;
            this.label432.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label432.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label432.Location = new System.Drawing.Point(4, 294);
            this.label432.Name = "label432";
            this.label432.Size = new System.Drawing.Size(145, 55);
            this.label432.TabIndex = 22;
            this.label432.Text = "Class 5";
            this.label432.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label433
            // 
            this.label433.BackColor = System.Drawing.Color.AliceBlue;
            this.label433.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label433.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label433.Location = new System.Drawing.Point(4, 236);
            this.label433.Name = "label433";
            this.label433.Size = new System.Drawing.Size(145, 55);
            this.label433.TabIndex = 21;
            this.label433.Text = "Class 4";
            this.label433.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label434
            // 
            this.label434.BackColor = System.Drawing.Color.AliceBlue;
            this.label434.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label434.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label434.Location = new System.Drawing.Point(4, 178);
            this.label434.Name = "label434";
            this.label434.Size = new System.Drawing.Size(145, 55);
            this.label434.TabIndex = 20;
            this.label434.Text = "Class 3";
            this.label434.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label435
            // 
            this.label435.BackColor = System.Drawing.Color.AliceBlue;
            this.label435.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label435.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label435.Location = new System.Drawing.Point(4, 120);
            this.label435.Name = "label435";
            this.label435.Size = new System.Drawing.Size(145, 55);
            this.label435.TabIndex = 19;
            this.label435.Text = "Class 2";
            this.label435.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label436
            // 
            this.label436.BackColor = System.Drawing.Color.AliceBlue;
            this.label436.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label436.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label436.Location = new System.Drawing.Point(4, 62);
            this.label436.Name = "label436";
            this.label436.Size = new System.Drawing.Size(145, 55);
            this.label436.TabIndex = 18;
            this.label436.Text = "Class 1";
            this.label436.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label437
            // 
            this.label437.BackColor = System.Drawing.Color.AliceBlue;
            this.label437.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label437.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label437.Location = new System.Drawing.Point(153, 32);
            this.label437.Name = "label437";
            this.label437.Size = new System.Drawing.Size(100, 26);
            this.label437.TabIndex = 2;
            this.label437.Text = "day";
            this.label437.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label438
            // 
            this.label438.BackColor = System.Drawing.Color.AliceBlue;
            this.label438.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label438.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label438.Location = new System.Drawing.Point(153, 4);
            this.label438.Name = "label438";
            this.label438.Size = new System.Drawing.Size(100, 26);
            this.label438.TabIndex = 1;
            this.label438.Text = "Date";
            this.label438.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label439
            // 
            this.label439.BackColor = System.Drawing.Color.AliceBlue;
            this.label439.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label439.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label439.Location = new System.Drawing.Point(4, 4);
            this.label439.Name = "label439";
            this.label439.Size = new System.Drawing.Size(145, 55);
            this.label439.TabIndex = 0;
            this.label439.Text = "first";
            this.label439.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label226
            // 
            this.label226.BackColor = System.Drawing.Color.AliceBlue;
            this.label226.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label226.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label226.Location = new System.Drawing.Point(881, 32);
            this.label226.Name = "label226";
            this.label226.Size = new System.Drawing.Size(100, 26);
            this.label226.TabIndex = 43;
            this.label226.Text = "day";
            this.label226.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label227
            // 
            this.label227.BackColor = System.Drawing.Color.AliceBlue;
            this.label227.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label227.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label227.Location = new System.Drawing.Point(881, 4);
            this.label227.Name = "label227";
            this.label227.Size = new System.Drawing.Size(100, 26);
            this.label227.TabIndex = 42;
            this.label227.Text = "Date";
            this.label227.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label228
            // 
            this.label228.BackColor = System.Drawing.Color.AliceBlue;
            this.label228.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label228.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label228.Location = new System.Drawing.Point(777, 32);
            this.label228.Name = "label228";
            this.label228.Size = new System.Drawing.Size(100, 26);
            this.label228.TabIndex = 41;
            this.label228.Text = "day";
            this.label228.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label229
            // 
            this.label229.BackColor = System.Drawing.Color.AliceBlue;
            this.label229.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label229.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label229.Location = new System.Drawing.Point(777, 4);
            this.label229.Name = "label229";
            this.label229.Size = new System.Drawing.Size(100, 26);
            this.label229.TabIndex = 40;
            this.label229.Text = "Date";
            this.label229.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label230
            // 
            this.label230.BackColor = System.Drawing.Color.AliceBlue;
            this.label230.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label230.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label230.Location = new System.Drawing.Point(673, 32);
            this.label230.Name = "label230";
            this.label230.Size = new System.Drawing.Size(100, 26);
            this.label230.TabIndex = 39;
            this.label230.Text = "day";
            this.label230.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label231
            // 
            this.label231.BackColor = System.Drawing.Color.AliceBlue;
            this.label231.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label231.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label231.Location = new System.Drawing.Point(673, 4);
            this.label231.Name = "label231";
            this.label231.Size = new System.Drawing.Size(100, 26);
            this.label231.TabIndex = 38;
            this.label231.Text = "Date";
            this.label231.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label232
            // 
            this.label232.BackColor = System.Drawing.Color.AliceBlue;
            this.label232.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label232.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label232.Location = new System.Drawing.Point(569, 32);
            this.label232.Name = "label232";
            this.label232.Size = new System.Drawing.Size(100, 26);
            this.label232.TabIndex = 37;
            this.label232.Text = "day";
            this.label232.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label233
            // 
            this.label233.BackColor = System.Drawing.Color.AliceBlue;
            this.label233.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label233.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label233.Location = new System.Drawing.Point(569, 4);
            this.label233.Name = "label233";
            this.label233.Size = new System.Drawing.Size(100, 26);
            this.label233.TabIndex = 36;
            this.label233.Text = "Date";
            this.label233.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label234
            // 
            this.label234.BackColor = System.Drawing.Color.AliceBlue;
            this.label234.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label234.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label234.Location = new System.Drawing.Point(465, 32);
            this.label234.Name = "label234";
            this.label234.Size = new System.Drawing.Size(100, 26);
            this.label234.TabIndex = 35;
            this.label234.Text = "day";
            this.label234.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label235
            // 
            this.label235.BackColor = System.Drawing.Color.AliceBlue;
            this.label235.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label235.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label235.Location = new System.Drawing.Point(465, 4);
            this.label235.Name = "label235";
            this.label235.Size = new System.Drawing.Size(100, 26);
            this.label235.TabIndex = 34;
            this.label235.Text = "Date";
            this.label235.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label236
            // 
            this.label236.BackColor = System.Drawing.Color.AliceBlue;
            this.label236.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label236.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label236.Location = new System.Drawing.Point(361, 32);
            this.label236.Name = "label236";
            this.label236.Size = new System.Drawing.Size(100, 26);
            this.label236.TabIndex = 33;
            this.label236.Text = "day";
            this.label236.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label237
            // 
            this.label237.BackColor = System.Drawing.Color.AliceBlue;
            this.label237.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label237.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label237.Location = new System.Drawing.Point(361, 4);
            this.label237.Name = "label237";
            this.label237.Size = new System.Drawing.Size(100, 26);
            this.label237.TabIndex = 32;
            this.label237.Text = "Date";
            this.label237.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label238
            // 
            this.label238.BackColor = System.Drawing.Color.AliceBlue;
            this.label238.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label238.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label238.Location = new System.Drawing.Point(257, 32);
            this.label238.Name = "label238";
            this.label238.Size = new System.Drawing.Size(100, 26);
            this.label238.TabIndex = 31;
            this.label238.Text = "day";
            this.label238.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label239
            // 
            this.label239.BackColor = System.Drawing.Color.AliceBlue;
            this.label239.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label239.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label239.Location = new System.Drawing.Point(257, 4);
            this.label239.Name = "label239";
            this.label239.Size = new System.Drawing.Size(100, 26);
            this.label239.TabIndex = 30;
            this.label239.Text = "Date";
            this.label239.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button7.Font = new System.Drawing.Font("Lucida Fax", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(983, 4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(70, 636);
            this.button7.TabIndex = 29;
            this.button7.Text = "\r\nE\r\nD\r\nI\r\nT";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel3.ColumnCount = 8;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Controls.Add(this.label240, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label241, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label242, 7, 9);
            this.tableLayoutPanel3.Controls.Add(this.label243, 6, 9);
            this.tableLayoutPanel3.Controls.Add(this.label244, 5, 9);
            this.tableLayoutPanel3.Controls.Add(this.label245, 4, 9);
            this.tableLayoutPanel3.Controls.Add(this.label246, 3, 9);
            this.tableLayoutPanel3.Controls.Add(this.label247, 2, 9);
            this.tableLayoutPanel3.Controls.Add(this.label248, 1, 9);
            this.tableLayoutPanel3.Controls.Add(this.label249, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.label250, 7, 8);
            this.tableLayoutPanel3.Controls.Add(this.label251, 6, 8);
            this.tableLayoutPanel3.Controls.Add(this.label252, 5, 8);
            this.tableLayoutPanel3.Controls.Add(this.label253, 4, 8);
            this.tableLayoutPanel3.Controls.Add(this.label254, 3, 8);
            this.tableLayoutPanel3.Controls.Add(this.label255, 2, 8);
            this.tableLayoutPanel3.Controls.Add(this.label256, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.label257, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.label258, 7, 7);
            this.tableLayoutPanel3.Controls.Add(this.label259, 6, 7);
            this.tableLayoutPanel3.Controls.Add(this.label260, 5, 7);
            this.tableLayoutPanel3.Controls.Add(this.label261, 4, 7);
            this.tableLayoutPanel3.Controls.Add(this.label262, 3, 7);
            this.tableLayoutPanel3.Controls.Add(this.label263, 2, 7);
            this.tableLayoutPanel3.Controls.Add(this.label264, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.label265, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.label266, 7, 6);
            this.tableLayoutPanel3.Controls.Add(this.label267, 6, 6);
            this.tableLayoutPanel3.Controls.Add(this.label268, 5, 6);
            this.tableLayoutPanel3.Controls.Add(this.label269, 4, 6);
            this.tableLayoutPanel3.Controls.Add(this.label270, 3, 6);
            this.tableLayoutPanel3.Controls.Add(this.label271, 2, 6);
            this.tableLayoutPanel3.Controls.Add(this.label272, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.label273, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label274, 7, 5);
            this.tableLayoutPanel3.Controls.Add(this.label275, 6, 5);
            this.tableLayoutPanel3.Controls.Add(this.label276, 5, 5);
            this.tableLayoutPanel3.Controls.Add(this.label277, 4, 5);
            this.tableLayoutPanel3.Controls.Add(this.label278, 3, 5);
            this.tableLayoutPanel3.Controls.Add(this.label279, 2, 5);
            this.tableLayoutPanel3.Controls.Add(this.label280, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.label281, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label282, 7, 4);
            this.tableLayoutPanel3.Controls.Add(this.label283, 6, 4);
            this.tableLayoutPanel3.Controls.Add(this.label284, 5, 4);
            this.tableLayoutPanel3.Controls.Add(this.label285, 4, 4);
            this.tableLayoutPanel3.Controls.Add(this.label286, 3, 4);
            this.tableLayoutPanel3.Controls.Add(this.label287, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.label288, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.label289, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label290, 7, 3);
            this.tableLayoutPanel3.Controls.Add(this.label291, 6, 3);
            this.tableLayoutPanel3.Controls.Add(this.label292, 5, 3);
            this.tableLayoutPanel3.Controls.Add(this.label293, 4, 3);
            this.tableLayoutPanel3.Controls.Add(this.label294, 3, 3);
            this.tableLayoutPanel3.Controls.Add(this.label295, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.label296, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.label297, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label298, 7, 2);
            this.tableLayoutPanel3.Controls.Add(this.label299, 6, 2);
            this.tableLayoutPanel3.Controls.Add(this.label300, 5, 2);
            this.tableLayoutPanel3.Controls.Add(this.label301, 4, 2);
            this.tableLayoutPanel3.Controls.Add(this.label302, 3, 2);
            this.tableLayoutPanel3.Controls.Add(this.label303, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.label304, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.label305, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label306, 7, 1);
            this.tableLayoutPanel3.Controls.Add(this.label307, 6, 1);
            this.tableLayoutPanel3.Controls.Add(this.label308, 5, 1);
            this.tableLayoutPanel3.Controls.Add(this.label309, 4, 1);
            this.tableLayoutPanel3.Controls.Add(this.label310, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.label311, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.label312, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label313, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label314, 7, 0);
            this.tableLayoutPanel3.Controls.Add(this.label315, 6, 0);
            this.tableLayoutPanel3.Controls.Add(this.label316, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.label317, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.label318, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label319, 4, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(151, 61);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 10;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(830, 581);
            this.tableLayoutPanel3.TabIndex = 28;
            // 
            // label240
            // 
            this.label240.BackColor = System.Drawing.Color.AliceBlue;
            this.label240.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label240.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label240.Location = new System.Drawing.Point(214, 3);
            this.label240.Name = "label240";
            this.label240.Size = new System.Drawing.Size(95, 53);
            this.label240.TabIndex = 118;
            this.label240.Text = "Subject\r\nTeacher";
            this.label240.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label241
            // 
            this.label241.BackColor = System.Drawing.Color.AliceBlue;
            this.label241.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label241.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label241.Location = new System.Drawing.Point(110, 3);
            this.label241.Name = "label241";
            this.label241.Size = new System.Drawing.Size(95, 53);
            this.label241.TabIndex = 117;
            this.label241.Text = "Subject\r\nTeacher";
            this.label241.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label242
            // 
            this.label242.BackColor = System.Drawing.Color.AliceBlue;
            this.label242.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label242.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label242.Location = new System.Drawing.Point(731, 526);
            this.label242.Name = "label242";
            this.label242.Size = new System.Drawing.Size(92, 52);
            this.label242.TabIndex = 116;
            this.label242.Text = "Subject\r\nTeacher";
            this.label242.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label243
            // 
            this.label243.BackColor = System.Drawing.Color.AliceBlue;
            this.label243.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label243.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label243.Location = new System.Drawing.Point(627, 526);
            this.label243.Name = "label243";
            this.label243.Size = new System.Drawing.Size(95, 52);
            this.label243.TabIndex = 115;
            this.label243.Text = "Subject\r\nTeacher";
            this.label243.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label244
            // 
            this.label244.BackColor = System.Drawing.Color.AliceBlue;
            this.label244.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label244.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label244.Location = new System.Drawing.Point(524, 526);
            this.label244.Name = "label244";
            this.label244.Size = new System.Drawing.Size(94, 52);
            this.label244.TabIndex = 114;
            this.label244.Text = "Subject\r\nTeacher";
            this.label244.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label245
            // 
            this.label245.BackColor = System.Drawing.Color.AliceBlue;
            this.label245.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label245.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label245.Location = new System.Drawing.Point(420, 526);
            this.label245.Name = "label245";
            this.label245.Size = new System.Drawing.Size(95, 52);
            this.label245.TabIndex = 113;
            this.label245.Text = "Subject\r\nTeacher";
            this.label245.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label246
            // 
            this.label246.BackColor = System.Drawing.Color.AliceBlue;
            this.label246.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label246.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label246.Location = new System.Drawing.Point(318, 526);
            this.label246.Name = "label246";
            this.label246.Size = new System.Drawing.Size(93, 52);
            this.label246.TabIndex = 111;
            this.label246.Text = "Subject\r\nTeacher";
            this.label246.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label247
            // 
            this.label247.BackColor = System.Drawing.Color.AliceBlue;
            this.label247.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label247.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label247.Location = new System.Drawing.Point(214, 526);
            this.label247.Name = "label247";
            this.label247.Size = new System.Drawing.Size(95, 52);
            this.label247.TabIndex = 110;
            this.label247.Text = "Subject\r\nTeacher";
            this.label247.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label248
            // 
            this.label248.BackColor = System.Drawing.Color.AliceBlue;
            this.label248.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label248.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label248.Location = new System.Drawing.Point(110, 526);
            this.label248.Name = "label248";
            this.label248.Size = new System.Drawing.Size(95, 52);
            this.label248.TabIndex = 109;
            this.label248.Text = "Subject\r\nTeacher";
            this.label248.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label249
            // 
            this.label249.BackColor = System.Drawing.Color.AliceBlue;
            this.label249.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label249.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label249.Location = new System.Drawing.Point(6, 526);
            this.label249.Name = "label249";
            this.label249.Size = new System.Drawing.Size(95, 52);
            this.label249.TabIndex = 108;
            this.label249.Text = "Subject\r\nTeacher";
            this.label249.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label250
            // 
            this.label250.BackColor = System.Drawing.Color.AliceBlue;
            this.label250.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label250.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label250.Location = new System.Drawing.Point(731, 468);
            this.label250.Name = "label250";
            this.label250.Size = new System.Drawing.Size(92, 53);
            this.label250.TabIndex = 107;
            this.label250.Text = "Subject\r\nTeacher";
            this.label250.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label251
            // 
            this.label251.BackColor = System.Drawing.Color.AliceBlue;
            this.label251.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label251.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label251.Location = new System.Drawing.Point(627, 468);
            this.label251.Name = "label251";
            this.label251.Size = new System.Drawing.Size(95, 53);
            this.label251.TabIndex = 106;
            this.label251.Text = "Subject\r\nTeacher";
            this.label251.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label252
            // 
            this.label252.BackColor = System.Drawing.Color.AliceBlue;
            this.label252.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label252.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label252.Location = new System.Drawing.Point(524, 468);
            this.label252.Name = "label252";
            this.label252.Size = new System.Drawing.Size(94, 53);
            this.label252.TabIndex = 105;
            this.label252.Text = "Subject\r\nTeacher";
            this.label252.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label253
            // 
            this.label253.BackColor = System.Drawing.Color.AliceBlue;
            this.label253.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label253.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label253.Location = new System.Drawing.Point(420, 468);
            this.label253.Name = "label253";
            this.label253.Size = new System.Drawing.Size(95, 53);
            this.label253.TabIndex = 104;
            this.label253.Text = "Subject\r\nTeacher";
            this.label253.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label254
            // 
            this.label254.BackColor = System.Drawing.Color.AliceBlue;
            this.label254.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label254.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label254.Location = new System.Drawing.Point(318, 468);
            this.label254.Name = "label254";
            this.label254.Size = new System.Drawing.Size(93, 53);
            this.label254.TabIndex = 102;
            this.label254.Text = "Subject\r\nTeacher";
            this.label254.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label255
            // 
            this.label255.BackColor = System.Drawing.Color.AliceBlue;
            this.label255.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label255.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label255.Location = new System.Drawing.Point(214, 468);
            this.label255.Name = "label255";
            this.label255.Size = new System.Drawing.Size(95, 53);
            this.label255.TabIndex = 101;
            this.label255.Text = "Subject\r\nTeacher";
            this.label255.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label256
            // 
            this.label256.BackColor = System.Drawing.Color.AliceBlue;
            this.label256.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label256.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label256.Location = new System.Drawing.Point(110, 468);
            this.label256.Name = "label256";
            this.label256.Size = new System.Drawing.Size(95, 53);
            this.label256.TabIndex = 100;
            this.label256.Text = "Subject\r\nTeacher";
            this.label256.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label257
            // 
            this.label257.BackColor = System.Drawing.Color.AliceBlue;
            this.label257.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label257.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label257.Location = new System.Drawing.Point(6, 468);
            this.label257.Name = "label257";
            this.label257.Size = new System.Drawing.Size(95, 53);
            this.label257.TabIndex = 99;
            this.label257.Text = "Subject\r\nTeacher";
            this.label257.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label258
            // 
            this.label258.BackColor = System.Drawing.Color.AliceBlue;
            this.label258.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label258.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label258.Location = new System.Drawing.Point(731, 411);
            this.label258.Name = "label258";
            this.label258.Size = new System.Drawing.Size(92, 53);
            this.label258.TabIndex = 98;
            this.label258.Text = "Subject\r\nTeacher";
            this.label258.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label259
            // 
            this.label259.BackColor = System.Drawing.Color.AliceBlue;
            this.label259.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label259.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label259.Location = new System.Drawing.Point(627, 411);
            this.label259.Name = "label259";
            this.label259.Size = new System.Drawing.Size(95, 53);
            this.label259.TabIndex = 97;
            this.label259.Text = "Subject\r\nTeacher";
            this.label259.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label260
            // 
            this.label260.BackColor = System.Drawing.Color.AliceBlue;
            this.label260.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label260.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label260.Location = new System.Drawing.Point(524, 411);
            this.label260.Name = "label260";
            this.label260.Size = new System.Drawing.Size(94, 53);
            this.label260.TabIndex = 96;
            this.label260.Text = "Subject\r\nTeacher";
            this.label260.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label261
            // 
            this.label261.BackColor = System.Drawing.Color.AliceBlue;
            this.label261.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label261.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label261.Location = new System.Drawing.Point(420, 411);
            this.label261.Name = "label261";
            this.label261.Size = new System.Drawing.Size(95, 53);
            this.label261.TabIndex = 95;
            this.label261.Text = "Subject\r\nTeacher";
            this.label261.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label262
            // 
            this.label262.BackColor = System.Drawing.Color.AliceBlue;
            this.label262.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label262.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label262.Location = new System.Drawing.Point(318, 411);
            this.label262.Name = "label262";
            this.label262.Size = new System.Drawing.Size(93, 53);
            this.label262.TabIndex = 93;
            this.label262.Text = "Subject\r\nTeacher";
            this.label262.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label263
            // 
            this.label263.BackColor = System.Drawing.Color.AliceBlue;
            this.label263.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label263.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label263.Location = new System.Drawing.Point(214, 411);
            this.label263.Name = "label263";
            this.label263.Size = new System.Drawing.Size(95, 53);
            this.label263.TabIndex = 92;
            this.label263.Text = "Subject\r\nTeacher";
            this.label263.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label264
            // 
            this.label264.BackColor = System.Drawing.Color.AliceBlue;
            this.label264.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label264.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label264.Location = new System.Drawing.Point(110, 411);
            this.label264.Name = "label264";
            this.label264.Size = new System.Drawing.Size(95, 53);
            this.label264.TabIndex = 91;
            this.label264.Text = "Subject\r\nTeacher";
            this.label264.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label265
            // 
            this.label265.BackColor = System.Drawing.Color.AliceBlue;
            this.label265.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label265.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label265.Location = new System.Drawing.Point(6, 411);
            this.label265.Name = "label265";
            this.label265.Size = new System.Drawing.Size(95, 53);
            this.label265.TabIndex = 90;
            this.label265.Text = "Subject\r\nTeacher";
            this.label265.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label266
            // 
            this.label266.BackColor = System.Drawing.Color.AliceBlue;
            this.label266.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label266.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label266.Location = new System.Drawing.Point(731, 352);
            this.label266.Name = "label266";
            this.label266.Size = new System.Drawing.Size(92, 53);
            this.label266.TabIndex = 89;
            this.label266.Text = "Subject\r\nTeacher";
            this.label266.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label267
            // 
            this.label267.BackColor = System.Drawing.Color.AliceBlue;
            this.label267.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label267.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label267.Location = new System.Drawing.Point(627, 352);
            this.label267.Name = "label267";
            this.label267.Size = new System.Drawing.Size(95, 53);
            this.label267.TabIndex = 88;
            this.label267.Text = "Subject\r\nTeacher";
            this.label267.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label268
            // 
            this.label268.BackColor = System.Drawing.Color.AliceBlue;
            this.label268.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label268.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label268.Location = new System.Drawing.Point(524, 352);
            this.label268.Name = "label268";
            this.label268.Size = new System.Drawing.Size(94, 53);
            this.label268.TabIndex = 87;
            this.label268.Text = "Subject\r\nTeacher";
            this.label268.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label269
            // 
            this.label269.BackColor = System.Drawing.Color.AliceBlue;
            this.label269.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label269.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label269.Location = new System.Drawing.Point(420, 352);
            this.label269.Name = "label269";
            this.label269.Size = new System.Drawing.Size(95, 53);
            this.label269.TabIndex = 86;
            this.label269.Text = "Subject\r\nTeacher";
            this.label269.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label270
            // 
            this.label270.BackColor = System.Drawing.Color.AliceBlue;
            this.label270.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label270.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label270.Location = new System.Drawing.Point(318, 352);
            this.label270.Name = "label270";
            this.label270.Size = new System.Drawing.Size(93, 53);
            this.label270.TabIndex = 84;
            this.label270.Text = "Subject\r\nTeacher";
            this.label270.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label271
            // 
            this.label271.BackColor = System.Drawing.Color.AliceBlue;
            this.label271.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label271.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label271.Location = new System.Drawing.Point(214, 352);
            this.label271.Name = "label271";
            this.label271.Size = new System.Drawing.Size(95, 53);
            this.label271.TabIndex = 83;
            this.label271.Text = "Subject\r\nTeacher";
            this.label271.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label272
            // 
            this.label272.BackColor = System.Drawing.Color.AliceBlue;
            this.label272.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label272.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label272.Location = new System.Drawing.Point(110, 352);
            this.label272.Name = "label272";
            this.label272.Size = new System.Drawing.Size(95, 53);
            this.label272.TabIndex = 82;
            this.label272.Text = "Subject\r\nTeacher";
            this.label272.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label273
            // 
            this.label273.BackColor = System.Drawing.Color.AliceBlue;
            this.label273.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label273.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label273.Location = new System.Drawing.Point(6, 352);
            this.label273.Name = "label273";
            this.label273.Size = new System.Drawing.Size(95, 53);
            this.label273.TabIndex = 81;
            this.label273.Text = "Subject\r\nTeacher";
            this.label273.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label274
            // 
            this.label274.BackColor = System.Drawing.Color.AliceBlue;
            this.label274.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label274.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label274.Location = new System.Drawing.Point(731, 296);
            this.label274.Name = "label274";
            this.label274.Size = new System.Drawing.Size(92, 53);
            this.label274.TabIndex = 80;
            this.label274.Text = "Subject\r\nTeacher";
            this.label274.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label275
            // 
            this.label275.BackColor = System.Drawing.Color.AliceBlue;
            this.label275.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label275.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label275.Location = new System.Drawing.Point(627, 296);
            this.label275.Name = "label275";
            this.label275.Size = new System.Drawing.Size(95, 53);
            this.label275.TabIndex = 79;
            this.label275.Text = "Subject\r\nTeacher";
            this.label275.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label276
            // 
            this.label276.BackColor = System.Drawing.Color.AliceBlue;
            this.label276.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label276.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label276.Location = new System.Drawing.Point(524, 296);
            this.label276.Name = "label276";
            this.label276.Size = new System.Drawing.Size(94, 53);
            this.label276.TabIndex = 78;
            this.label276.Text = "Subject\r\nTeacher";
            this.label276.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label277
            // 
            this.label277.BackColor = System.Drawing.Color.AliceBlue;
            this.label277.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label277.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label277.Location = new System.Drawing.Point(420, 296);
            this.label277.Name = "label277";
            this.label277.Size = new System.Drawing.Size(95, 53);
            this.label277.TabIndex = 77;
            this.label277.Text = "Subject\r\nTeacher";
            this.label277.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label278
            // 
            this.label278.BackColor = System.Drawing.Color.AliceBlue;
            this.label278.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label278.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label278.Location = new System.Drawing.Point(318, 296);
            this.label278.Name = "label278";
            this.label278.Size = new System.Drawing.Size(93, 53);
            this.label278.TabIndex = 75;
            this.label278.Text = "Subject\r\nTeacher";
            this.label278.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label279
            // 
            this.label279.BackColor = System.Drawing.Color.AliceBlue;
            this.label279.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label279.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label279.Location = new System.Drawing.Point(214, 296);
            this.label279.Name = "label279";
            this.label279.Size = new System.Drawing.Size(95, 53);
            this.label279.TabIndex = 74;
            this.label279.Text = "Subject\r\nTeacher";
            this.label279.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label280
            // 
            this.label280.BackColor = System.Drawing.Color.AliceBlue;
            this.label280.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label280.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label280.Location = new System.Drawing.Point(110, 296);
            this.label280.Name = "label280";
            this.label280.Size = new System.Drawing.Size(95, 53);
            this.label280.TabIndex = 73;
            this.label280.Text = "Subject\r\nTeacher";
            this.label280.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label281
            // 
            this.label281.BackColor = System.Drawing.Color.AliceBlue;
            this.label281.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label281.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label281.Location = new System.Drawing.Point(6, 296);
            this.label281.Name = "label281";
            this.label281.Size = new System.Drawing.Size(95, 53);
            this.label281.TabIndex = 72;
            this.label281.Text = "Subject\r\nTeacher";
            this.label281.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label282
            // 
            this.label282.BackColor = System.Drawing.Color.AliceBlue;
            this.label282.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label282.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label282.Location = new System.Drawing.Point(731, 237);
            this.label282.Name = "label282";
            this.label282.Size = new System.Drawing.Size(92, 53);
            this.label282.TabIndex = 71;
            this.label282.Text = "Subject\r\nTeacher";
            this.label282.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label283
            // 
            this.label283.BackColor = System.Drawing.Color.AliceBlue;
            this.label283.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label283.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label283.Location = new System.Drawing.Point(627, 237);
            this.label283.Name = "label283";
            this.label283.Size = new System.Drawing.Size(95, 53);
            this.label283.TabIndex = 70;
            this.label283.Text = "Subject\r\nTeacher";
            this.label283.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label284
            // 
            this.label284.BackColor = System.Drawing.Color.AliceBlue;
            this.label284.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label284.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label284.Location = new System.Drawing.Point(524, 237);
            this.label284.Name = "label284";
            this.label284.Size = new System.Drawing.Size(94, 53);
            this.label284.TabIndex = 69;
            this.label284.Text = "Subject\r\nTeacher";
            this.label284.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label285
            // 
            this.label285.BackColor = System.Drawing.Color.AliceBlue;
            this.label285.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label285.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label285.Location = new System.Drawing.Point(420, 237);
            this.label285.Name = "label285";
            this.label285.Size = new System.Drawing.Size(95, 53);
            this.label285.TabIndex = 68;
            this.label285.Text = "Subject\r\nTeacher";
            this.label285.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label286
            // 
            this.label286.BackColor = System.Drawing.Color.AliceBlue;
            this.label286.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label286.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label286.Location = new System.Drawing.Point(318, 237);
            this.label286.Name = "label286";
            this.label286.Size = new System.Drawing.Size(93, 53);
            this.label286.TabIndex = 66;
            this.label286.Text = "Subject\r\nTeacher";
            this.label286.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label287
            // 
            this.label287.BackColor = System.Drawing.Color.AliceBlue;
            this.label287.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label287.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label287.Location = new System.Drawing.Point(214, 237);
            this.label287.Name = "label287";
            this.label287.Size = new System.Drawing.Size(95, 53);
            this.label287.TabIndex = 65;
            this.label287.Text = "Subject\r\nTeacher";
            this.label287.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label288
            // 
            this.label288.BackColor = System.Drawing.Color.AliceBlue;
            this.label288.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label288.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label288.Location = new System.Drawing.Point(110, 237);
            this.label288.Name = "label288";
            this.label288.Size = new System.Drawing.Size(95, 53);
            this.label288.TabIndex = 64;
            this.label288.Text = "Subject\r\nTeacher";
            this.label288.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label289
            // 
            this.label289.BackColor = System.Drawing.Color.AliceBlue;
            this.label289.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label289.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label289.Location = new System.Drawing.Point(6, 237);
            this.label289.Name = "label289";
            this.label289.Size = new System.Drawing.Size(95, 53);
            this.label289.TabIndex = 63;
            this.label289.Text = "Subject\r\nTeacher";
            this.label289.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label290
            // 
            this.label290.BackColor = System.Drawing.Color.AliceBlue;
            this.label290.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label290.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label290.Location = new System.Drawing.Point(731, 178);
            this.label290.Name = "label290";
            this.label290.Size = new System.Drawing.Size(92, 53);
            this.label290.TabIndex = 62;
            this.label290.Text = "Subject\r\nTeacher";
            this.label290.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label291
            // 
            this.label291.BackColor = System.Drawing.Color.AliceBlue;
            this.label291.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label291.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label291.Location = new System.Drawing.Point(627, 178);
            this.label291.Name = "label291";
            this.label291.Size = new System.Drawing.Size(95, 53);
            this.label291.TabIndex = 61;
            this.label291.Text = "Subject\r\nTeacher";
            this.label291.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label292
            // 
            this.label292.BackColor = System.Drawing.Color.AliceBlue;
            this.label292.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label292.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label292.Location = new System.Drawing.Point(524, 178);
            this.label292.Name = "label292";
            this.label292.Size = new System.Drawing.Size(94, 53);
            this.label292.TabIndex = 60;
            this.label292.Text = "Subject\r\nTeacher";
            this.label292.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label293
            // 
            this.label293.BackColor = System.Drawing.Color.AliceBlue;
            this.label293.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label293.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label293.Location = new System.Drawing.Point(420, 178);
            this.label293.Name = "label293";
            this.label293.Size = new System.Drawing.Size(95, 53);
            this.label293.TabIndex = 59;
            this.label293.Text = "Subject\r\nTeacher";
            this.label293.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label294
            // 
            this.label294.BackColor = System.Drawing.Color.AliceBlue;
            this.label294.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label294.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label294.Location = new System.Drawing.Point(318, 178);
            this.label294.Name = "label294";
            this.label294.Size = new System.Drawing.Size(93, 53);
            this.label294.TabIndex = 57;
            this.label294.Text = "Subject\r\nTeacher";
            this.label294.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label295
            // 
            this.label295.BackColor = System.Drawing.Color.AliceBlue;
            this.label295.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label295.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label295.Location = new System.Drawing.Point(214, 178);
            this.label295.Name = "label295";
            this.label295.Size = new System.Drawing.Size(95, 53);
            this.label295.TabIndex = 56;
            this.label295.Text = "Subject\r\nTeacher";
            this.label295.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label296
            // 
            this.label296.BackColor = System.Drawing.Color.AliceBlue;
            this.label296.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label296.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label296.Location = new System.Drawing.Point(110, 178);
            this.label296.Name = "label296";
            this.label296.Size = new System.Drawing.Size(95, 53);
            this.label296.TabIndex = 55;
            this.label296.Text = "Subject\r\nTeacher";
            this.label296.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label297
            // 
            this.label297.BackColor = System.Drawing.Color.AliceBlue;
            this.label297.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label297.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label297.Location = new System.Drawing.Point(6, 178);
            this.label297.Name = "label297";
            this.label297.Size = new System.Drawing.Size(95, 53);
            this.label297.TabIndex = 54;
            this.label297.Text = "Subject\r\nTeacher";
            this.label297.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label298
            // 
            this.label298.BackColor = System.Drawing.Color.AliceBlue;
            this.label298.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label298.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label298.Location = new System.Drawing.Point(731, 121);
            this.label298.Name = "label298";
            this.label298.Size = new System.Drawing.Size(92, 53);
            this.label298.TabIndex = 53;
            this.label298.Text = "Subject\r\nTeacher";
            this.label298.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label299
            // 
            this.label299.BackColor = System.Drawing.Color.AliceBlue;
            this.label299.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label299.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label299.Location = new System.Drawing.Point(627, 121);
            this.label299.Name = "label299";
            this.label299.Size = new System.Drawing.Size(95, 53);
            this.label299.TabIndex = 52;
            this.label299.Text = "Subject\r\nTeacher";
            this.label299.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label300
            // 
            this.label300.BackColor = System.Drawing.Color.AliceBlue;
            this.label300.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label300.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label300.Location = new System.Drawing.Point(524, 121);
            this.label300.Name = "label300";
            this.label300.Size = new System.Drawing.Size(94, 53);
            this.label300.TabIndex = 51;
            this.label300.Text = "Subject\r\nTeacher";
            this.label300.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label301
            // 
            this.label301.BackColor = System.Drawing.Color.AliceBlue;
            this.label301.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label301.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label301.Location = new System.Drawing.Point(420, 121);
            this.label301.Name = "label301";
            this.label301.Size = new System.Drawing.Size(95, 53);
            this.label301.TabIndex = 50;
            this.label301.Text = "Subject\r\nTeacher";
            this.label301.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label302
            // 
            this.label302.BackColor = System.Drawing.Color.AliceBlue;
            this.label302.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label302.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label302.Location = new System.Drawing.Point(318, 121);
            this.label302.Name = "label302";
            this.label302.Size = new System.Drawing.Size(93, 53);
            this.label302.TabIndex = 48;
            this.label302.Text = "Subject\r\nTeacher";
            this.label302.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label303
            // 
            this.label303.BackColor = System.Drawing.Color.AliceBlue;
            this.label303.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label303.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label303.Location = new System.Drawing.Point(214, 121);
            this.label303.Name = "label303";
            this.label303.Size = new System.Drawing.Size(95, 53);
            this.label303.TabIndex = 47;
            this.label303.Text = "Subject\r\nTeacher";
            this.label303.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label304
            // 
            this.label304.BackColor = System.Drawing.Color.AliceBlue;
            this.label304.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label304.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label304.Location = new System.Drawing.Point(110, 121);
            this.label304.Name = "label304";
            this.label304.Size = new System.Drawing.Size(95, 53);
            this.label304.TabIndex = 46;
            this.label304.Text = "Subject\r\nTeacher";
            this.label304.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label305
            // 
            this.label305.BackColor = System.Drawing.Color.AliceBlue;
            this.label305.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label305.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label305.Location = new System.Drawing.Point(6, 121);
            this.label305.Name = "label305";
            this.label305.Size = new System.Drawing.Size(95, 53);
            this.label305.TabIndex = 45;
            this.label305.Text = "Subject\r\nTeacher";
            this.label305.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label306
            // 
            this.label306.BackColor = System.Drawing.Color.AliceBlue;
            this.label306.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label306.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label306.Location = new System.Drawing.Point(731, 61);
            this.label306.Name = "label306";
            this.label306.Size = new System.Drawing.Size(92, 53);
            this.label306.TabIndex = 44;
            this.label306.Text = "Subject\r\nTeacher";
            this.label306.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label307
            // 
            this.label307.BackColor = System.Drawing.Color.AliceBlue;
            this.label307.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label307.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label307.Location = new System.Drawing.Point(627, 61);
            this.label307.Name = "label307";
            this.label307.Size = new System.Drawing.Size(95, 53);
            this.label307.TabIndex = 43;
            this.label307.Text = "Subject\r\nTeacher";
            this.label307.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label308
            // 
            this.label308.BackColor = System.Drawing.Color.AliceBlue;
            this.label308.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label308.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label308.Location = new System.Drawing.Point(524, 61);
            this.label308.Name = "label308";
            this.label308.Size = new System.Drawing.Size(94, 53);
            this.label308.TabIndex = 42;
            this.label308.Text = "Subject\r\nTeacher";
            this.label308.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label309
            // 
            this.label309.BackColor = System.Drawing.Color.AliceBlue;
            this.label309.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label309.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label309.Location = new System.Drawing.Point(420, 61);
            this.label309.Name = "label309";
            this.label309.Size = new System.Drawing.Size(95, 53);
            this.label309.TabIndex = 41;
            this.label309.Text = "Subject\r\nTeacher";
            this.label309.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label310
            // 
            this.label310.BackColor = System.Drawing.Color.AliceBlue;
            this.label310.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label310.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label310.Location = new System.Drawing.Point(318, 61);
            this.label310.Name = "label310";
            this.label310.Size = new System.Drawing.Size(93, 53);
            this.label310.TabIndex = 39;
            this.label310.Text = "Subject\r\nTeacher";
            this.label310.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label311
            // 
            this.label311.BackColor = System.Drawing.Color.AliceBlue;
            this.label311.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label311.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label311.Location = new System.Drawing.Point(214, 61);
            this.label311.Name = "label311";
            this.label311.Size = new System.Drawing.Size(95, 53);
            this.label311.TabIndex = 38;
            this.label311.Text = "Subject\r\nTeacher";
            this.label311.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label312
            // 
            this.label312.BackColor = System.Drawing.Color.AliceBlue;
            this.label312.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label312.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label312.Location = new System.Drawing.Point(110, 61);
            this.label312.Name = "label312";
            this.label312.Size = new System.Drawing.Size(95, 53);
            this.label312.TabIndex = 37;
            this.label312.Text = "Subject\r\nTeacher";
            this.label312.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label313
            // 
            this.label313.BackColor = System.Drawing.Color.AliceBlue;
            this.label313.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label313.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label313.Location = new System.Drawing.Point(6, 61);
            this.label313.Name = "label313";
            this.label313.Size = new System.Drawing.Size(95, 53);
            this.label313.TabIndex = 36;
            this.label313.Text = "Subject\r\nTeacher";
            this.label313.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label314
            // 
            this.label314.BackColor = System.Drawing.Color.AliceBlue;
            this.label314.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label314.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label314.Location = new System.Drawing.Point(731, 3);
            this.label314.Name = "label314";
            this.label314.Size = new System.Drawing.Size(92, 53);
            this.label314.TabIndex = 35;
            this.label314.Text = "Subject\r\nTeacher";
            this.label314.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label315
            // 
            this.label315.BackColor = System.Drawing.Color.AliceBlue;
            this.label315.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label315.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label315.Location = new System.Drawing.Point(627, 3);
            this.label315.Name = "label315";
            this.label315.Size = new System.Drawing.Size(95, 53);
            this.label315.TabIndex = 34;
            this.label315.Text = "Subject\r\nTeacher";
            this.label315.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label316
            // 
            this.label316.BackColor = System.Drawing.Color.AliceBlue;
            this.label316.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label316.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label316.Location = new System.Drawing.Point(524, 3);
            this.label316.Name = "label316";
            this.label316.Size = new System.Drawing.Size(94, 53);
            this.label316.TabIndex = 33;
            this.label316.Text = "Subject\r\nTeacher";
            this.label316.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label317
            // 
            this.label317.BackColor = System.Drawing.Color.AliceBlue;
            this.label317.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label317.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label317.Location = new System.Drawing.Point(318, 3);
            this.label317.Name = "label317";
            this.label317.Size = new System.Drawing.Size(93, 53);
            this.label317.TabIndex = 30;
            this.label317.Text = "Subject\r\nTeacher";
            this.label317.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label318
            // 
            this.label318.BackColor = System.Drawing.Color.AliceBlue;
            this.label318.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label318.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label318.Location = new System.Drawing.Point(6, 3);
            this.label318.Name = "label318";
            this.label318.Size = new System.Drawing.Size(95, 53);
            this.label318.TabIndex = 29;
            this.label318.Text = "Subject\r\nTiming";
            this.label318.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label319
            // 
            this.label319.BackColor = System.Drawing.Color.AliceBlue;
            this.label319.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label319.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label319.Location = new System.Drawing.Point(420, 3);
            this.label319.Name = "label319";
            this.label319.Size = new System.Drawing.Size(95, 53);
            this.label319.TabIndex = 31;
            this.label319.Text = "Subject\r\nTeacher";
            this.label319.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label320
            // 
            this.label320.BackColor = System.Drawing.Color.AliceBlue;
            this.label320.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label320.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label320.Location = new System.Drawing.Point(4, 584);
            this.label320.Name = "label320";
            this.label320.Size = new System.Drawing.Size(145, 55);
            this.label320.TabIndex = 27;
            this.label320.Text = "Class 10";
            this.label320.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label321
            // 
            this.label321.BackColor = System.Drawing.Color.AliceBlue;
            this.label321.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label321.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label321.Location = new System.Drawing.Point(4, 526);
            this.label321.Name = "label321";
            this.label321.Size = new System.Drawing.Size(145, 55);
            this.label321.TabIndex = 26;
            this.label321.Text = "Class 9";
            this.label321.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label322
            // 
            this.label322.BackColor = System.Drawing.Color.AliceBlue;
            this.label322.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label322.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label322.Location = new System.Drawing.Point(4, 468);
            this.label322.Name = "label322";
            this.label322.Size = new System.Drawing.Size(145, 55);
            this.label322.TabIndex = 25;
            this.label322.Text = "Class 8";
            this.label322.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label323
            // 
            this.label323.BackColor = System.Drawing.Color.AliceBlue;
            this.label323.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label323.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label323.Location = new System.Drawing.Point(4, 410);
            this.label323.Name = "label323";
            this.label323.Size = new System.Drawing.Size(145, 55);
            this.label323.TabIndex = 24;
            this.label323.Text = "Class 7";
            this.label323.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label324
            // 
            this.label324.BackColor = System.Drawing.Color.AliceBlue;
            this.label324.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label324.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label324.Location = new System.Drawing.Point(4, 352);
            this.label324.Name = "label324";
            this.label324.Size = new System.Drawing.Size(145, 55);
            this.label324.TabIndex = 23;
            this.label324.Text = "Class 6";
            this.label324.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label325
            // 
            this.label325.BackColor = System.Drawing.Color.AliceBlue;
            this.label325.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label325.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label325.Location = new System.Drawing.Point(4, 294);
            this.label325.Name = "label325";
            this.label325.Size = new System.Drawing.Size(145, 55);
            this.label325.TabIndex = 22;
            this.label325.Text = "Class 5";
            this.label325.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label326
            // 
            this.label326.BackColor = System.Drawing.Color.AliceBlue;
            this.label326.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label326.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label326.Location = new System.Drawing.Point(4, 236);
            this.label326.Name = "label326";
            this.label326.Size = new System.Drawing.Size(145, 55);
            this.label326.TabIndex = 21;
            this.label326.Text = "Class 4";
            this.label326.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label327
            // 
            this.label327.BackColor = System.Drawing.Color.AliceBlue;
            this.label327.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label327.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label327.Location = new System.Drawing.Point(4, 178);
            this.label327.Name = "label327";
            this.label327.Size = new System.Drawing.Size(145, 55);
            this.label327.TabIndex = 20;
            this.label327.Text = "Class 3";
            this.label327.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label328
            // 
            this.label328.BackColor = System.Drawing.Color.AliceBlue;
            this.label328.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label328.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label328.Location = new System.Drawing.Point(4, 120);
            this.label328.Name = "label328";
            this.label328.Size = new System.Drawing.Size(145, 55);
            this.label328.TabIndex = 19;
            this.label328.Text = "Class 2";
            this.label328.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label329
            // 
            this.label329.BackColor = System.Drawing.Color.AliceBlue;
            this.label329.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label329.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label329.Location = new System.Drawing.Point(4, 62);
            this.label329.Name = "label329";
            this.label329.Size = new System.Drawing.Size(145, 55);
            this.label329.TabIndex = 18;
            this.label329.Text = "Class 1";
            this.label329.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label330
            // 
            this.label330.BackColor = System.Drawing.Color.AliceBlue;
            this.label330.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label330.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label330.Location = new System.Drawing.Point(153, 32);
            this.label330.Name = "label330";
            this.label330.Size = new System.Drawing.Size(100, 26);
            this.label330.TabIndex = 2;
            this.label330.Text = "day";
            this.label330.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label331
            // 
            this.label331.BackColor = System.Drawing.Color.AliceBlue;
            this.label331.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label331.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label331.Location = new System.Drawing.Point(153, 4);
            this.label331.Name = "label331";
            this.label331.Size = new System.Drawing.Size(100, 26);
            this.label331.TabIndex = 1;
            this.label331.Text = "Date";
            this.label331.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label332
            // 
            this.label332.BackColor = System.Drawing.Color.AliceBlue;
            this.label332.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label332.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label332.Location = new System.Drawing.Point(4, 4);
            this.label332.Name = "label332";
            this.label332.Size = new System.Drawing.Size(145, 55);
            this.label332.TabIndex = 0;
            this.label332.Text = "second";
            this.label332.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.AliceBlue;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(881, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 26);
            this.label10.TabIndex = 43;
            this.label10.Text = "day";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.AliceBlue;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(881, 4);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 26);
            this.label11.TabIndex = 42;
            this.label11.Text = "Date";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.AliceBlue;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label12.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(777, 32);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 26);
            this.label12.TabIndex = 41;
            this.label12.Text = "day";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.AliceBlue;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label13.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(777, 4);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 26);
            this.label13.TabIndex = 40;
            this.label13.Text = "Date";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.AliceBlue;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label14.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(673, 32);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 26);
            this.label14.TabIndex = 39;
            this.label14.Text = "day";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.AliceBlue;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label15.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(673, 4);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 26);
            this.label15.TabIndex = 38;
            this.label15.Text = "Date";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.AliceBlue;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label16.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(569, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 26);
            this.label16.TabIndex = 37;
            this.label16.Text = "day";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.AliceBlue;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label17.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(569, 4);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 26);
            this.label17.TabIndex = 36;
            this.label17.Text = "Date";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.AliceBlue;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(465, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 26);
            this.label6.TabIndex = 35;
            this.label6.Text = "day";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.AliceBlue;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(465, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 26);
            this.label7.TabIndex = 34;
            this.label7.Text = "Date";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.AliceBlue;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(361, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 26);
            this.label8.TabIndex = 33;
            this.label8.Text = "day";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.AliceBlue;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label9.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(361, 4);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 26);
            this.label9.TabIndex = 32;
            this.label9.Text = "Date";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.AliceBlue;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(257, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 26);
            this.label1.TabIndex = 31;
            this.label1.Text = "day";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.AliceBlue;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(257, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 26);
            this.label2.TabIndex = 30;
            this.label2.Text = "Date";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button5.Font = new System.Drawing.Font("Lucida Fax", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(983, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(70, 636);
            this.button5.TabIndex = 29;
            this.button5.Text = "\r\nE\r\nD\r\nI\r\nT";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel1.ColumnCount = 8;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.label31, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label30, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label118, 7, 9);
            this.tableLayoutPanel1.Controls.Add(this.label117, 6, 9);
            this.tableLayoutPanel1.Controls.Add(this.label116, 5, 9);
            this.tableLayoutPanel1.Controls.Add(this.label115, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.label113, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.label112, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.label111, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.label110, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label109, 7, 8);
            this.tableLayoutPanel1.Controls.Add(this.label108, 6, 8);
            this.tableLayoutPanel1.Controls.Add(this.label107, 5, 8);
            this.tableLayoutPanel1.Controls.Add(this.label106, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.label104, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.label103, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.label102, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.label101, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label100, 7, 7);
            this.tableLayoutPanel1.Controls.Add(this.label99, 6, 7);
            this.tableLayoutPanel1.Controls.Add(this.label98, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.label97, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.label95, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.label94, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.label93, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label92, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label91, 7, 6);
            this.tableLayoutPanel1.Controls.Add(this.label90, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.label89, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.label88, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.label86, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.label85, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.label84, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label83, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label82, 7, 5);
            this.tableLayoutPanel1.Controls.Add(this.label81, 6, 5);
            this.tableLayoutPanel1.Controls.Add(this.label80, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.label79, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.label77, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.label76, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.label75, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label74, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label73, 7, 4);
            this.tableLayoutPanel1.Controls.Add(this.label72, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.label71, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.label70, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.label68, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.label67, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.label66, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label65, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label64, 7, 3);
            this.tableLayoutPanel1.Controls.Add(this.label63, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.label62, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.label61, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.label59, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.label58, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label57, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label56, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label55, 7, 2);
            this.tableLayoutPanel1.Controls.Add(this.label54, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.label53, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.label52, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.label50, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.label49, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label48, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label47, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label46, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.label45, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.label44, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.label43, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.label41, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label40, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label39, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label38, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label37, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.label36, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.label35, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.label32, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label29, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label33, 4, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(151, 61);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(830, 581);
            this.tableLayoutPanel1.TabIndex = 28;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.AliceBlue;
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label31.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(214, 3);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(95, 53);
            this.label31.TabIndex = 118;
            this.label31.Text = "Subject\r\nTeacher";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.AliceBlue;
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label30.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(110, 3);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(95, 53);
            this.label30.TabIndex = 117;
            this.label30.Text = "Subject\r\nTeacher";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label118
            // 
            this.label118.BackColor = System.Drawing.Color.AliceBlue;
            this.label118.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label118.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label118.Location = new System.Drawing.Point(731, 526);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(92, 52);
            this.label118.TabIndex = 116;
            this.label118.Text = "Subject\r\nTeacher";
            this.label118.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label117
            // 
            this.label117.BackColor = System.Drawing.Color.AliceBlue;
            this.label117.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label117.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label117.Location = new System.Drawing.Point(627, 526);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(95, 52);
            this.label117.TabIndex = 115;
            this.label117.Text = "Subject\r\nTeacher";
            this.label117.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label116
            // 
            this.label116.BackColor = System.Drawing.Color.AliceBlue;
            this.label116.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label116.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label116.Location = new System.Drawing.Point(524, 526);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(94, 52);
            this.label116.TabIndex = 114;
            this.label116.Text = "Subject\r\nTeacher";
            this.label116.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label115
            // 
            this.label115.BackColor = System.Drawing.Color.AliceBlue;
            this.label115.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label115.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label115.Location = new System.Drawing.Point(420, 526);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(95, 52);
            this.label115.TabIndex = 113;
            this.label115.Text = "Subject\r\nTeacher";
            this.label115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label113
            // 
            this.label113.BackColor = System.Drawing.Color.AliceBlue;
            this.label113.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label113.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.Location = new System.Drawing.Point(318, 526);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(93, 52);
            this.label113.TabIndex = 111;
            this.label113.Text = "Subject\r\nTeacher";
            this.label113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label112
            // 
            this.label112.BackColor = System.Drawing.Color.AliceBlue;
            this.label112.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label112.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.Location = new System.Drawing.Point(214, 526);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(95, 52);
            this.label112.TabIndex = 110;
            this.label112.Text = "Subject\r\nTeacher";
            this.label112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label111
            // 
            this.label111.BackColor = System.Drawing.Color.AliceBlue;
            this.label111.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label111.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.Location = new System.Drawing.Point(110, 526);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(95, 52);
            this.label111.TabIndex = 109;
            this.label111.Text = "Subject\r\nTeacher";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label110
            // 
            this.label110.BackColor = System.Drawing.Color.AliceBlue;
            this.label110.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label110.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.Location = new System.Drawing.Point(6, 526);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(95, 52);
            this.label110.TabIndex = 108;
            this.label110.Text = "Subject\r\nTeacher";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label109
            // 
            this.label109.BackColor = System.Drawing.Color.AliceBlue;
            this.label109.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label109.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.Location = new System.Drawing.Point(731, 468);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(92, 53);
            this.label109.TabIndex = 107;
            this.label109.Text = "Subject\r\nTeacher";
            this.label109.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label108
            // 
            this.label108.BackColor = System.Drawing.Color.AliceBlue;
            this.label108.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label108.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(627, 468);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(95, 53);
            this.label108.TabIndex = 106;
            this.label108.Text = "Subject\r\nTeacher";
            this.label108.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label107
            // 
            this.label107.BackColor = System.Drawing.Color.AliceBlue;
            this.label107.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label107.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(524, 468);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(94, 53);
            this.label107.TabIndex = 105;
            this.label107.Text = "Subject\r\nTeacher";
            this.label107.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label106
            // 
            this.label106.BackColor = System.Drawing.Color.AliceBlue;
            this.label106.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label106.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(420, 468);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(95, 53);
            this.label106.TabIndex = 104;
            this.label106.Text = "Subject\r\nTeacher";
            this.label106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label104
            // 
            this.label104.BackColor = System.Drawing.Color.AliceBlue;
            this.label104.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label104.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(318, 468);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(93, 53);
            this.label104.TabIndex = 102;
            this.label104.Text = "Subject\r\nTeacher";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label103
            // 
            this.label103.BackColor = System.Drawing.Color.AliceBlue;
            this.label103.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label103.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(214, 468);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(95, 53);
            this.label103.TabIndex = 101;
            this.label103.Text = "Subject\r\nTeacher";
            this.label103.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label102
            // 
            this.label102.BackColor = System.Drawing.Color.AliceBlue;
            this.label102.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label102.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(110, 468);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(95, 53);
            this.label102.TabIndex = 100;
            this.label102.Text = "Subject\r\nTeacher";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label101
            // 
            this.label101.BackColor = System.Drawing.Color.AliceBlue;
            this.label101.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label101.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label101.Location = new System.Drawing.Point(6, 468);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(95, 53);
            this.label101.TabIndex = 99;
            this.label101.Text = "Subject\r\nTeacher";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label100
            // 
            this.label100.BackColor = System.Drawing.Color.AliceBlue;
            this.label100.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label100.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(731, 411);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(92, 53);
            this.label100.TabIndex = 98;
            this.label100.Text = "Subject\r\nTeacher";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label99
            // 
            this.label99.BackColor = System.Drawing.Color.AliceBlue;
            this.label99.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label99.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(627, 411);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(95, 53);
            this.label99.TabIndex = 97;
            this.label99.Text = "Subject\r\nTeacher";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label98
            // 
            this.label98.BackColor = System.Drawing.Color.AliceBlue;
            this.label98.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label98.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(524, 411);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(94, 53);
            this.label98.TabIndex = 96;
            this.label98.Text = "Subject\r\nTeacher";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label97
            // 
            this.label97.BackColor = System.Drawing.Color.AliceBlue;
            this.label97.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label97.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(420, 411);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(95, 53);
            this.label97.TabIndex = 95;
            this.label97.Text = "Subject\r\nTeacher";
            this.label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label95
            // 
            this.label95.BackColor = System.Drawing.Color.AliceBlue;
            this.label95.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label95.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(318, 411);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(93, 53);
            this.label95.TabIndex = 93;
            this.label95.Text = "Subject\r\nTeacher";
            this.label95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.BackColor = System.Drawing.Color.AliceBlue;
            this.label94.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label94.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(214, 411);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(95, 53);
            this.label94.TabIndex = 92;
            this.label94.Text = "Subject\r\nTeacher";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label93
            // 
            this.label93.BackColor = System.Drawing.Color.AliceBlue;
            this.label93.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label93.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(110, 411);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(95, 53);
            this.label93.TabIndex = 91;
            this.label93.Text = "Subject\r\nTeacher";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label92
            // 
            this.label92.BackColor = System.Drawing.Color.AliceBlue;
            this.label92.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label92.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(6, 411);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(95, 53);
            this.label92.TabIndex = 90;
            this.label92.Text = "Subject\r\nTeacher";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label91
            // 
            this.label91.BackColor = System.Drawing.Color.AliceBlue;
            this.label91.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label91.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(731, 352);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(92, 53);
            this.label91.TabIndex = 89;
            this.label91.Text = "Subject\r\nTeacher";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label90
            // 
            this.label90.BackColor = System.Drawing.Color.AliceBlue;
            this.label90.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label90.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(627, 352);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(95, 53);
            this.label90.TabIndex = 88;
            this.label90.Text = "Subject\r\nTeacher";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label89
            // 
            this.label89.BackColor = System.Drawing.Color.AliceBlue;
            this.label89.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label89.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(524, 352);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(94, 53);
            this.label89.TabIndex = 87;
            this.label89.Text = "Subject\r\nTeacher";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label88
            // 
            this.label88.BackColor = System.Drawing.Color.AliceBlue;
            this.label88.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label88.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(420, 352);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(95, 53);
            this.label88.TabIndex = 86;
            this.label88.Text = "Subject\r\nTeacher";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label86
            // 
            this.label86.BackColor = System.Drawing.Color.AliceBlue;
            this.label86.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label86.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(318, 352);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(93, 53);
            this.label86.TabIndex = 84;
            this.label86.Text = "Subject\r\nTeacher";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label85
            // 
            this.label85.BackColor = System.Drawing.Color.AliceBlue;
            this.label85.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label85.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(214, 352);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(95, 53);
            this.label85.TabIndex = 83;
            this.label85.Text = "Subject\r\nTeacher";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label84
            // 
            this.label84.BackColor = System.Drawing.Color.AliceBlue;
            this.label84.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label84.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(110, 352);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(95, 53);
            this.label84.TabIndex = 82;
            this.label84.Text = "Subject\r\nTeacher";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label83
            // 
            this.label83.BackColor = System.Drawing.Color.AliceBlue;
            this.label83.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label83.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(6, 352);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(95, 53);
            this.label83.TabIndex = 81;
            this.label83.Text = "Subject\r\nTeacher";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label82
            // 
            this.label82.BackColor = System.Drawing.Color.AliceBlue;
            this.label82.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label82.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(731, 296);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(92, 53);
            this.label82.TabIndex = 80;
            this.label82.Text = "Subject\r\nTeacher";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label81
            // 
            this.label81.BackColor = System.Drawing.Color.AliceBlue;
            this.label81.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label81.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(627, 296);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(95, 53);
            this.label81.TabIndex = 79;
            this.label81.Text = "Subject\r\nTeacher";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label80
            // 
            this.label80.BackColor = System.Drawing.Color.AliceBlue;
            this.label80.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label80.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(524, 296);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(94, 53);
            this.label80.TabIndex = 78;
            this.label80.Text = "Subject\r\nTeacher";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label79
            // 
            this.label79.BackColor = System.Drawing.Color.AliceBlue;
            this.label79.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label79.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(420, 296);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(95, 53);
            this.label79.TabIndex = 77;
            this.label79.Text = "Subject\r\nTeacher";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label77
            // 
            this.label77.BackColor = System.Drawing.Color.AliceBlue;
            this.label77.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label77.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(318, 296);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(93, 53);
            this.label77.TabIndex = 75;
            this.label77.Text = "Subject\r\nTeacher";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.BackColor = System.Drawing.Color.AliceBlue;
            this.label76.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label76.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(214, 296);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(95, 53);
            this.label76.TabIndex = 74;
            this.label76.Text = "Subject\r\nTeacher";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label75
            // 
            this.label75.BackColor = System.Drawing.Color.AliceBlue;
            this.label75.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label75.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(110, 296);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(95, 53);
            this.label75.TabIndex = 73;
            this.label75.Text = "Subject\r\nTeacher";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.BackColor = System.Drawing.Color.AliceBlue;
            this.label74.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label74.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(6, 296);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(95, 53);
            this.label74.TabIndex = 72;
            this.label74.Text = "Subject\r\nTeacher";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label73
            // 
            this.label73.BackColor = System.Drawing.Color.AliceBlue;
            this.label73.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label73.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(731, 237);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(92, 53);
            this.label73.TabIndex = 71;
            this.label73.Text = "Subject\r\nTeacher";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.BackColor = System.Drawing.Color.AliceBlue;
            this.label72.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label72.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(627, 237);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(95, 53);
            this.label72.TabIndex = 70;
            this.label72.Text = "Subject\r\nTeacher";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label71
            // 
            this.label71.BackColor = System.Drawing.Color.AliceBlue;
            this.label71.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label71.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(524, 237);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(94, 53);
            this.label71.TabIndex = 69;
            this.label71.Text = "Subject\r\nTeacher";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label70
            // 
            this.label70.BackColor = System.Drawing.Color.AliceBlue;
            this.label70.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label70.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(420, 237);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(95, 53);
            this.label70.TabIndex = 68;
            this.label70.Text = "Subject\r\nTeacher";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.BackColor = System.Drawing.Color.AliceBlue;
            this.label68.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label68.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(318, 237);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(93, 53);
            this.label68.TabIndex = 66;
            this.label68.Text = "Subject\r\nTeacher";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.BackColor = System.Drawing.Color.AliceBlue;
            this.label67.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label67.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(214, 237);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(95, 53);
            this.label67.TabIndex = 65;
            this.label67.Text = "Subject\r\nTeacher";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.Color.AliceBlue;
            this.label66.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label66.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(110, 237);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(95, 53);
            this.label66.TabIndex = 64;
            this.label66.Text = "Subject\r\nTeacher";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.Color.AliceBlue;
            this.label65.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label65.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(6, 237);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(95, 53);
            this.label65.TabIndex = 63;
            this.label65.Text = "Subject\r\nTeacher";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.BackColor = System.Drawing.Color.AliceBlue;
            this.label64.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label64.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(731, 178);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(92, 53);
            this.label64.TabIndex = 62;
            this.label64.Text = "Subject\r\nTeacher";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.BackColor = System.Drawing.Color.AliceBlue;
            this.label63.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label63.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(627, 178);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(95, 53);
            this.label63.TabIndex = 61;
            this.label63.Text = "Subject\r\nTeacher";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.Color.AliceBlue;
            this.label62.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label62.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(524, 178);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(94, 53);
            this.label62.TabIndex = 60;
            this.label62.Text = "Subject\r\nTeacher";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.Color.AliceBlue;
            this.label61.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label61.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(420, 178);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(95, 53);
            this.label61.TabIndex = 59;
            this.label61.Text = "Subject\r\nTeacher";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.Color.AliceBlue;
            this.label59.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label59.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(318, 178);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(93, 53);
            this.label59.TabIndex = 57;
            this.label59.Text = "Subject\r\nTeacher";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.Color.AliceBlue;
            this.label58.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label58.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(214, 178);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(95, 53);
            this.label58.TabIndex = 56;
            this.label58.Text = "Subject\r\nTeacher";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.Color.AliceBlue;
            this.label57.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label57.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(110, 178);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(95, 53);
            this.label57.TabIndex = 55;
            this.label57.Text = "Subject\r\nTeacher";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.BackColor = System.Drawing.Color.AliceBlue;
            this.label56.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label56.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(6, 178);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(95, 53);
            this.label56.TabIndex = 54;
            this.label56.Text = "Subject\r\nTeacher";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.Color.AliceBlue;
            this.label55.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label55.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(731, 121);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(92, 53);
            this.label55.TabIndex = 53;
            this.label55.Text = "Subject\r\nTeacher";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.Color.AliceBlue;
            this.label54.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label54.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(627, 121);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(95, 53);
            this.label54.TabIndex = 52;
            this.label54.Text = "Subject\r\nTeacher";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.BackColor = System.Drawing.Color.AliceBlue;
            this.label53.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label53.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(524, 121);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(94, 53);
            this.label53.TabIndex = 51;
            this.label53.Text = "Subject\r\nTeacher";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.Color.AliceBlue;
            this.label52.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label52.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(420, 121);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(95, 53);
            this.label52.TabIndex = 50;
            this.label52.Text = "Subject\r\nTeacher";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.BackColor = System.Drawing.Color.AliceBlue;
            this.label50.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label50.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(318, 121);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(93, 53);
            this.label50.TabIndex = 48;
            this.label50.Text = "Subject\r\nTeacher";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.Color.AliceBlue;
            this.label49.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label49.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(214, 121);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(95, 53);
            this.label49.TabIndex = 47;
            this.label49.Text = "Subject\r\nTeacher";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.Color.AliceBlue;
            this.label48.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label48.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(110, 121);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(95, 53);
            this.label48.TabIndex = 46;
            this.label48.Text = "Subject\r\nTeacher";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.AliceBlue;
            this.label47.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label47.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(6, 121);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(95, 53);
            this.label47.TabIndex = 45;
            this.label47.Text = "Subject\r\nTeacher";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.Color.AliceBlue;
            this.label46.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label46.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(731, 61);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(92, 53);
            this.label46.TabIndex = 44;
            this.label46.Text = "Subject\r\nTeacher";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.BackColor = System.Drawing.Color.AliceBlue;
            this.label45.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label45.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(627, 61);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(95, 53);
            this.label45.TabIndex = 43;
            this.label45.Text = "Subject\r\nTeacher";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.Color.AliceBlue;
            this.label44.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label44.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(524, 61);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(94, 53);
            this.label44.TabIndex = 42;
            this.label44.Text = "Subject\r\nTeacher";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.AliceBlue;
            this.label43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label43.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(420, 61);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(95, 53);
            this.label43.TabIndex = 41;
            this.label43.Text = "Subject\r\nTeacher";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.AliceBlue;
            this.label41.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label41.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(318, 61);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(93, 53);
            this.label41.TabIndex = 39;
            this.label41.Text = "Subject\r\nTeacher";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.AliceBlue;
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label40.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(214, 61);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(95, 53);
            this.label40.TabIndex = 38;
            this.label40.Text = "Subject\r\nTeacher";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.AliceBlue;
            this.label39.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label39.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(110, 61);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(95, 53);
            this.label39.TabIndex = 37;
            this.label39.Text = "Subject\r\nTeacher";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.AliceBlue;
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label38.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(6, 61);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(95, 53);
            this.label38.TabIndex = 36;
            this.label38.Text = "Subject\r\nTeacher";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.AliceBlue;
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label37.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(731, 3);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(92, 53);
            this.label37.TabIndex = 35;
            this.label37.Text = "Subject\r\nTeacher";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.AliceBlue;
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label36.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(627, 3);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(95, 53);
            this.label36.TabIndex = 34;
            this.label36.Text = "Subject\r\nTeacher";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.AliceBlue;
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label35.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(524, 3);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(94, 53);
            this.label35.TabIndex = 33;
            this.label35.Text = "Subject\r\nTeacher";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.AliceBlue;
            this.label32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label32.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(318, 3);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(93, 53);
            this.label32.TabIndex = 30;
            this.label32.Text = "Subject\r\nTeacher";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.AliceBlue;
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label29.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(6, 3);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(95, 53);
            this.label29.TabIndex = 29;
            this.label29.Text = "Subject\r\nTiming";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.AliceBlue;
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label33.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(420, 3);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(95, 53);
            this.label33.TabIndex = 31;
            this.label33.Text = "Subject\r\nTeacher";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.AliceBlue;
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label28.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(4, 584);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(145, 55);
            this.label28.TabIndex = 27;
            this.label28.Text = "Class 10";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.AliceBlue;
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label27.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(4, 526);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(145, 55);
            this.label27.TabIndex = 26;
            this.label27.Text = "Class 9";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.AliceBlue;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label26.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(4, 468);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(145, 55);
            this.label26.TabIndex = 25;
            this.label26.Text = "Class 8";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.AliceBlue;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label25.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(4, 410);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(145, 55);
            this.label25.TabIndex = 24;
            this.label25.Text = "Class 7";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.AliceBlue;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label24.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(4, 352);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(145, 55);
            this.label24.TabIndex = 23;
            this.label24.Text = "Class 6";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.AliceBlue;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label23.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(4, 294);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(145, 55);
            this.label23.TabIndex = 22;
            this.label23.Text = "Class 5";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.AliceBlue;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label22.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(4, 236);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(145, 55);
            this.label22.TabIndex = 21;
            this.label22.Text = "Class 4";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.AliceBlue;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label21.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(4, 178);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(145, 55);
            this.label21.TabIndex = 20;
            this.label21.Text = "Class 3";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.AliceBlue;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label20.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(4, 120);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(145, 55);
            this.label20.TabIndex = 19;
            this.label20.Text = "Class 2";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.AliceBlue;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label19.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(4, 62);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(145, 55);
            this.label19.TabIndex = 18;
            this.label19.Text = "Class 1";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.AliceBlue;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(153, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 26);
            this.label3.TabIndex = 2;
            this.label3.Text = "day";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.AliceBlue;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(153, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 26);
            this.label4.TabIndex = 1;
            this.label4.Text = "Date";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.AliceBlue;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(4, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 55);
            this.label5.TabIndex = 0;
            this.label5.Text = "Class / Date";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // period_schedule
            // 
            this.period_schedule.BackColor = System.Drawing.Color.Lavender;
            this.period_schedule.Controls.Add(this.button6);
            this.period_schedule.Controls.Add(this.panel1);
            this.period_schedule.Controls.Add(this.tableLayoutPanel2);
            this.period_schedule.Controls.Add(this.label198);
            this.period_schedule.Controls.Add(this.label199);
            this.period_schedule.Controls.Add(this.label200);
            this.period_schedule.Controls.Add(this.label201);
            this.period_schedule.Controls.Add(this.label202);
            this.period_schedule.Controls.Add(this.label203);
            this.period_schedule.Controls.Add(this.label204);
            this.period_schedule.Controls.Add(this.label205);
            this.period_schedule.Controls.Add(this.label206);
            this.period_schedule.Controls.Add(this.label207);
            this.period_schedule.Controls.Add(this.label208);
            this.period_schedule.Controls.Add(this.label209);
            this.period_schedule.Controls.Add(this.label210);
            this.period_schedule.Controls.Add(this.label211);
            this.period_schedule.Controls.Add(this.label212);
            this.period_schedule.Controls.Add(this.label213);
            this.period_schedule.Controls.Add(this.label214);
            this.period_schedule.Controls.Add(this.label215);
            this.period_schedule.Controls.Add(this.label216);
            this.period_schedule.Controls.Add(this.label217);
            this.period_schedule.Controls.Add(this.label218);
            this.period_schedule.Controls.Add(this.label219);
            this.period_schedule.Controls.Add(this.label220);
            this.period_schedule.Controls.Add(this.label221);
            this.period_schedule.Controls.Add(this.label222);
            this.period_schedule.Controls.Add(this.label223);
            this.period_schedule.Controls.Add(this.label224);
            this.period_schedule.Controls.Add(this.label225);
            this.period_schedule.Location = new System.Drawing.Point(11, 62);
            this.period_schedule.Name = "period_schedule";
            this.period_schedule.Size = new System.Drawing.Size(1100, 644);
            this.period_schedule.TabIndex = 64;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button6.Font = new System.Drawing.Font("Lucida Fax", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(1027, 4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(70, 636);
            this.button6.TabIndex = 29;
            this.button6.Text = "\r\nE\r\nD\r\nI\r\nT";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel2.ColumnCount = 9;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel2.Controls.Add(this.label18, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label34, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label42, 8, 9);
            this.tableLayoutPanel2.Controls.Add(this.label51, 7, 9);
            this.tableLayoutPanel2.Controls.Add(this.label60, 6, 9);
            this.tableLayoutPanel2.Controls.Add(this.label69, 5, 9);
            this.tableLayoutPanel2.Controls.Add(this.label114, 4, 9);
            this.tableLayoutPanel2.Controls.Add(this.label78, 3, 9);
            this.tableLayoutPanel2.Controls.Add(this.label87, 2, 9);
            this.tableLayoutPanel2.Controls.Add(this.label96, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.label105, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.label119, 8, 8);
            this.tableLayoutPanel2.Controls.Add(this.label120, 7, 8);
            this.tableLayoutPanel2.Controls.Add(this.label121, 6, 8);
            this.tableLayoutPanel2.Controls.Add(this.label122, 5, 8);
            this.tableLayoutPanel2.Controls.Add(this.label123, 4, 8);
            this.tableLayoutPanel2.Controls.Add(this.label124, 3, 8);
            this.tableLayoutPanel2.Controls.Add(this.label125, 2, 8);
            this.tableLayoutPanel2.Controls.Add(this.label126, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.label127, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.label128, 8, 7);
            this.tableLayoutPanel2.Controls.Add(this.label129, 7, 7);
            this.tableLayoutPanel2.Controls.Add(this.label130, 6, 7);
            this.tableLayoutPanel2.Controls.Add(this.label131, 5, 7);
            this.tableLayoutPanel2.Controls.Add(this.label132, 4, 7);
            this.tableLayoutPanel2.Controls.Add(this.label133, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.label134, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.label135, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.label136, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.label137, 8, 6);
            this.tableLayoutPanel2.Controls.Add(this.label138, 7, 6);
            this.tableLayoutPanel2.Controls.Add(this.label139, 6, 6);
            this.tableLayoutPanel2.Controls.Add(this.label140, 5, 6);
            this.tableLayoutPanel2.Controls.Add(this.label141, 4, 6);
            this.tableLayoutPanel2.Controls.Add(this.label142, 3, 6);
            this.tableLayoutPanel2.Controls.Add(this.label143, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.label144, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.label145, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label146, 8, 5);
            this.tableLayoutPanel2.Controls.Add(this.label147, 7, 5);
            this.tableLayoutPanel2.Controls.Add(this.label148, 6, 5);
            this.tableLayoutPanel2.Controls.Add(this.label149, 5, 5);
            this.tableLayoutPanel2.Controls.Add(this.label150, 4, 5);
            this.tableLayoutPanel2.Controls.Add(this.label151, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.label152, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.label153, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label154, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label155, 8, 4);
            this.tableLayoutPanel2.Controls.Add(this.label156, 7, 4);
            this.tableLayoutPanel2.Controls.Add(this.label157, 6, 4);
            this.tableLayoutPanel2.Controls.Add(this.label158, 5, 4);
            this.tableLayoutPanel2.Controls.Add(this.label159, 4, 4);
            this.tableLayoutPanel2.Controls.Add(this.label160, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.label161, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.label162, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label163, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label164, 8, 3);
            this.tableLayoutPanel2.Controls.Add(this.label165, 7, 3);
            this.tableLayoutPanel2.Controls.Add(this.label166, 6, 3);
            this.tableLayoutPanel2.Controls.Add(this.label167, 5, 3);
            this.tableLayoutPanel2.Controls.Add(this.label168, 4, 3);
            this.tableLayoutPanel2.Controls.Add(this.label169, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.label170, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.label171, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label172, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label173, 8, 2);
            this.tableLayoutPanel2.Controls.Add(this.label174, 7, 2);
            this.tableLayoutPanel2.Controls.Add(this.label175, 6, 2);
            this.tableLayoutPanel2.Controls.Add(this.label176, 5, 2);
            this.tableLayoutPanel2.Controls.Add(this.label177, 4, 2);
            this.tableLayoutPanel2.Controls.Add(this.label178, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.label179, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.label180, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label181, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label182, 8, 1);
            this.tableLayoutPanel2.Controls.Add(this.label183, 7, 1);
            this.tableLayoutPanel2.Controls.Add(this.label184, 6, 1);
            this.tableLayoutPanel2.Controls.Add(this.label185, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.label186, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.label187, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.label188, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.label189, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label190, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label191, 8, 0);
            this.tableLayoutPanel2.Controls.Add(this.label192, 7, 0);
            this.tableLayoutPanel2.Controls.Add(this.label193, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.label194, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.label195, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label196, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label197, 5, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(151, 61);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 10;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(875, 581);
            this.tableLayoutPanel2.TabIndex = 28;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.AliceBlue;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label18.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(214, 3);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(95, 53);
            this.label18.TabIndex = 118;
            this.label18.Text = "Subject\r\nTeacher";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.AliceBlue;
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label34.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(110, 3);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(95, 53);
            this.label34.TabIndex = 117;
            this.label34.Text = "Subject\r\nTeacher";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.AliceBlue;
            this.label42.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label42.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(777, 526);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(92, 52);
            this.label42.TabIndex = 116;
            this.label42.Text = "Subject\r\nTeacher";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.BackColor = System.Drawing.Color.AliceBlue;
            this.label51.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label51.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(673, 526);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(95, 52);
            this.label51.TabIndex = 115;
            this.label51.Text = "Subject\r\nTeacher";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.AliceBlue;
            this.label60.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label60.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(570, 526);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(94, 52);
            this.label60.TabIndex = 114;
            this.label60.Text = "Subject\r\nTeacher";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.Color.AliceBlue;
            this.label69.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label69.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(466, 526);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(95, 52);
            this.label69.TabIndex = 113;
            this.label69.Text = "Subject\r\nTeacher";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label114
            // 
            this.label114.BackColor = System.Drawing.Color.AliceBlue;
            this.label114.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label114.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.Location = new System.Drawing.Point(420, 526);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(37, 52);
            this.label114.TabIndex = 112;
            this.label114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label78
            // 
            this.label78.BackColor = System.Drawing.Color.AliceBlue;
            this.label78.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label78.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(318, 526);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(93, 52);
            this.label78.TabIndex = 111;
            this.label78.Text = "Subject\r\nTeacher";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label87
            // 
            this.label87.BackColor = System.Drawing.Color.AliceBlue;
            this.label87.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label87.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(214, 526);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(95, 52);
            this.label87.TabIndex = 110;
            this.label87.Text = "Subject\r\nTeacher";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label96
            // 
            this.label96.BackColor = System.Drawing.Color.AliceBlue;
            this.label96.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label96.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(110, 526);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(95, 52);
            this.label96.TabIndex = 109;
            this.label96.Text = "Subject\r\nTeacher";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label105
            // 
            this.label105.BackColor = System.Drawing.Color.AliceBlue;
            this.label105.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label105.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(6, 526);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(95, 52);
            this.label105.TabIndex = 108;
            this.label105.Text = "Subject\r\nTeacher";
            this.label105.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label119
            // 
            this.label119.BackColor = System.Drawing.Color.AliceBlue;
            this.label119.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label119.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label119.Location = new System.Drawing.Point(777, 468);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(92, 53);
            this.label119.TabIndex = 107;
            this.label119.Text = "Subject\r\nTeacher";
            this.label119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label120
            // 
            this.label120.BackColor = System.Drawing.Color.AliceBlue;
            this.label120.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label120.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label120.Location = new System.Drawing.Point(673, 468);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(95, 53);
            this.label120.TabIndex = 106;
            this.label120.Text = "Subject\r\nTeacher";
            this.label120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label121
            // 
            this.label121.BackColor = System.Drawing.Color.AliceBlue;
            this.label121.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label121.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label121.Location = new System.Drawing.Point(570, 468);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(94, 53);
            this.label121.TabIndex = 105;
            this.label121.Text = "Subject\r\nTeacher";
            this.label121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label122
            // 
            this.label122.BackColor = System.Drawing.Color.AliceBlue;
            this.label122.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label122.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label122.Location = new System.Drawing.Point(466, 468);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(95, 53);
            this.label122.TabIndex = 104;
            this.label122.Text = "Subject\r\nTeacher";
            this.label122.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label123
            // 
            this.label123.BackColor = System.Drawing.Color.AliceBlue;
            this.label123.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label123.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.Location = new System.Drawing.Point(420, 468);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(37, 53);
            this.label123.TabIndex = 103;
            this.label123.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label124
            // 
            this.label124.BackColor = System.Drawing.Color.AliceBlue;
            this.label124.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label124.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.Location = new System.Drawing.Point(318, 468);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(93, 53);
            this.label124.TabIndex = 102;
            this.label124.Text = "Subject\r\nTeacher";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label125
            // 
            this.label125.BackColor = System.Drawing.Color.AliceBlue;
            this.label125.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label125.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label125.Location = new System.Drawing.Point(214, 468);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(95, 53);
            this.label125.TabIndex = 101;
            this.label125.Text = "Subject\r\nTeacher";
            this.label125.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label126
            // 
            this.label126.BackColor = System.Drawing.Color.AliceBlue;
            this.label126.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label126.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label126.Location = new System.Drawing.Point(110, 468);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(95, 53);
            this.label126.TabIndex = 100;
            this.label126.Text = "Subject\r\nTeacher";
            this.label126.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label127
            // 
            this.label127.BackColor = System.Drawing.Color.AliceBlue;
            this.label127.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label127.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label127.Location = new System.Drawing.Point(6, 468);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(95, 53);
            this.label127.TabIndex = 99;
            this.label127.Text = "Subject\r\nTeacher";
            this.label127.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label128
            // 
            this.label128.BackColor = System.Drawing.Color.AliceBlue;
            this.label128.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label128.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label128.Location = new System.Drawing.Point(777, 411);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(92, 53);
            this.label128.TabIndex = 98;
            this.label128.Text = "Subject\r\nTeacher";
            this.label128.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label129
            // 
            this.label129.BackColor = System.Drawing.Color.AliceBlue;
            this.label129.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label129.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label129.Location = new System.Drawing.Point(673, 411);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(95, 53);
            this.label129.TabIndex = 97;
            this.label129.Text = "Subject\r\nTeacher";
            this.label129.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label130
            // 
            this.label130.BackColor = System.Drawing.Color.AliceBlue;
            this.label130.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label130.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label130.Location = new System.Drawing.Point(570, 411);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(94, 53);
            this.label130.TabIndex = 96;
            this.label130.Text = "Subject\r\nTeacher";
            this.label130.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label131
            // 
            this.label131.BackColor = System.Drawing.Color.AliceBlue;
            this.label131.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label131.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label131.Location = new System.Drawing.Point(466, 411);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(95, 53);
            this.label131.TabIndex = 95;
            this.label131.Text = "Subject\r\nTeacher";
            this.label131.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label132
            // 
            this.label132.BackColor = System.Drawing.Color.AliceBlue;
            this.label132.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label132.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label132.Location = new System.Drawing.Point(420, 411);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(37, 53);
            this.label132.TabIndex = 94;
            this.label132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label133
            // 
            this.label133.BackColor = System.Drawing.Color.AliceBlue;
            this.label133.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label133.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label133.Location = new System.Drawing.Point(318, 411);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(93, 53);
            this.label133.TabIndex = 93;
            this.label133.Text = "Subject\r\nTeacher";
            this.label133.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label134
            // 
            this.label134.BackColor = System.Drawing.Color.AliceBlue;
            this.label134.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label134.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label134.Location = new System.Drawing.Point(214, 411);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(95, 53);
            this.label134.TabIndex = 92;
            this.label134.Text = "Subject\r\nTeacher";
            this.label134.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label135
            // 
            this.label135.BackColor = System.Drawing.Color.AliceBlue;
            this.label135.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label135.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label135.Location = new System.Drawing.Point(110, 411);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(95, 53);
            this.label135.TabIndex = 91;
            this.label135.Text = "Subject\r\nTeacher";
            this.label135.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label136
            // 
            this.label136.BackColor = System.Drawing.Color.AliceBlue;
            this.label136.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label136.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label136.Location = new System.Drawing.Point(6, 411);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(95, 53);
            this.label136.TabIndex = 90;
            this.label136.Text = "Subject\r\nTeacher";
            this.label136.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label137
            // 
            this.label137.BackColor = System.Drawing.Color.AliceBlue;
            this.label137.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label137.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label137.Location = new System.Drawing.Point(777, 352);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(92, 53);
            this.label137.TabIndex = 89;
            this.label137.Text = "Subject\r\nTeacher";
            this.label137.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label138
            // 
            this.label138.BackColor = System.Drawing.Color.AliceBlue;
            this.label138.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label138.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label138.Location = new System.Drawing.Point(673, 352);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(95, 53);
            this.label138.TabIndex = 88;
            this.label138.Text = "Subject\r\nTeacher";
            this.label138.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label139
            // 
            this.label139.BackColor = System.Drawing.Color.AliceBlue;
            this.label139.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label139.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label139.Location = new System.Drawing.Point(570, 352);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(94, 53);
            this.label139.TabIndex = 87;
            this.label139.Text = "Subject\r\nTeacher";
            this.label139.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label140
            // 
            this.label140.BackColor = System.Drawing.Color.AliceBlue;
            this.label140.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label140.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label140.Location = new System.Drawing.Point(466, 352);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(95, 53);
            this.label140.TabIndex = 86;
            this.label140.Text = "Subject\r\nTeacher";
            this.label140.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label141
            // 
            this.label141.BackColor = System.Drawing.Color.AliceBlue;
            this.label141.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label141.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label141.Location = new System.Drawing.Point(420, 352);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(37, 53);
            this.label141.TabIndex = 85;
            this.label141.Text = "K";
            this.label141.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label142
            // 
            this.label142.BackColor = System.Drawing.Color.AliceBlue;
            this.label142.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label142.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label142.Location = new System.Drawing.Point(318, 352);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(93, 53);
            this.label142.TabIndex = 84;
            this.label142.Text = "Subject\r\nTeacher";
            this.label142.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label143
            // 
            this.label143.BackColor = System.Drawing.Color.AliceBlue;
            this.label143.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label143.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label143.Location = new System.Drawing.Point(214, 352);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(95, 53);
            this.label143.TabIndex = 83;
            this.label143.Text = "Subject\r\nTeacher";
            this.label143.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label144
            // 
            this.label144.BackColor = System.Drawing.Color.AliceBlue;
            this.label144.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label144.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label144.Location = new System.Drawing.Point(110, 352);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(95, 53);
            this.label144.TabIndex = 82;
            this.label144.Text = "Subject\r\nTeacher";
            this.label144.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label145
            // 
            this.label145.BackColor = System.Drawing.Color.AliceBlue;
            this.label145.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label145.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label145.Location = new System.Drawing.Point(6, 352);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(95, 53);
            this.label145.TabIndex = 81;
            this.label145.Text = "Subject\r\nTeacher";
            this.label145.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label146
            // 
            this.label146.BackColor = System.Drawing.Color.AliceBlue;
            this.label146.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label146.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label146.Location = new System.Drawing.Point(777, 296);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(92, 53);
            this.label146.TabIndex = 80;
            this.label146.Text = "Subject\r\nTeacher";
            this.label146.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label147
            // 
            this.label147.BackColor = System.Drawing.Color.AliceBlue;
            this.label147.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label147.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label147.Location = new System.Drawing.Point(673, 296);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(95, 53);
            this.label147.TabIndex = 79;
            this.label147.Text = "Subject\r\nTeacher";
            this.label147.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label148
            // 
            this.label148.BackColor = System.Drawing.Color.AliceBlue;
            this.label148.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label148.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label148.Location = new System.Drawing.Point(570, 296);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(94, 53);
            this.label148.TabIndex = 78;
            this.label148.Text = "Subject\r\nTeacher";
            this.label148.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label149
            // 
            this.label149.BackColor = System.Drawing.Color.AliceBlue;
            this.label149.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label149.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label149.Location = new System.Drawing.Point(466, 296);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(95, 53);
            this.label149.TabIndex = 77;
            this.label149.Text = "Subject\r\nTeacher";
            this.label149.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label150
            // 
            this.label150.BackColor = System.Drawing.Color.AliceBlue;
            this.label150.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label150.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label150.Location = new System.Drawing.Point(420, 296);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(37, 53);
            this.label150.TabIndex = 76;
            this.label150.Text = "A";
            this.label150.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label151
            // 
            this.label151.BackColor = System.Drawing.Color.AliceBlue;
            this.label151.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label151.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label151.Location = new System.Drawing.Point(318, 296);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(93, 53);
            this.label151.TabIndex = 75;
            this.label151.Text = "Subject\r\nTeacher";
            this.label151.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label152
            // 
            this.label152.BackColor = System.Drawing.Color.AliceBlue;
            this.label152.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label152.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label152.Location = new System.Drawing.Point(214, 296);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(95, 53);
            this.label152.TabIndex = 74;
            this.label152.Text = "Subject\r\nTeacher";
            this.label152.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label153
            // 
            this.label153.BackColor = System.Drawing.Color.AliceBlue;
            this.label153.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label153.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label153.Location = new System.Drawing.Point(110, 296);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(95, 53);
            this.label153.TabIndex = 73;
            this.label153.Text = "Subject\r\nTeacher";
            this.label153.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label154
            // 
            this.label154.BackColor = System.Drawing.Color.AliceBlue;
            this.label154.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label154.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label154.Location = new System.Drawing.Point(6, 296);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(95, 53);
            this.label154.TabIndex = 72;
            this.label154.Text = "Subject\r\nTeacher";
            this.label154.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label155
            // 
            this.label155.BackColor = System.Drawing.Color.AliceBlue;
            this.label155.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label155.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label155.Location = new System.Drawing.Point(777, 237);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(92, 53);
            this.label155.TabIndex = 71;
            this.label155.Text = "Subject\r\nTeacher";
            this.label155.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label156
            // 
            this.label156.BackColor = System.Drawing.Color.AliceBlue;
            this.label156.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label156.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label156.Location = new System.Drawing.Point(673, 237);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(95, 53);
            this.label156.TabIndex = 70;
            this.label156.Text = "Subject\r\nTeacher";
            this.label156.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label157
            // 
            this.label157.BackColor = System.Drawing.Color.AliceBlue;
            this.label157.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label157.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label157.Location = new System.Drawing.Point(570, 237);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(94, 53);
            this.label157.TabIndex = 69;
            this.label157.Text = "Subject\r\nTeacher";
            this.label157.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label158
            // 
            this.label158.BackColor = System.Drawing.Color.AliceBlue;
            this.label158.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label158.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label158.Location = new System.Drawing.Point(466, 237);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(95, 53);
            this.label158.TabIndex = 68;
            this.label158.Text = "Subject\r\nTeacher";
            this.label158.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label159
            // 
            this.label159.BackColor = System.Drawing.Color.AliceBlue;
            this.label159.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label159.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label159.Location = new System.Drawing.Point(420, 237);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(37, 53);
            this.label159.TabIndex = 67;
            this.label159.Text = "E";
            this.label159.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label160
            // 
            this.label160.BackColor = System.Drawing.Color.AliceBlue;
            this.label160.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label160.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label160.Location = new System.Drawing.Point(318, 237);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(93, 53);
            this.label160.TabIndex = 66;
            this.label160.Text = "Subject\r\nTeacher";
            this.label160.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label161
            // 
            this.label161.BackColor = System.Drawing.Color.AliceBlue;
            this.label161.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label161.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label161.Location = new System.Drawing.Point(214, 237);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(95, 53);
            this.label161.TabIndex = 65;
            this.label161.Text = "Subject\r\nTeacher";
            this.label161.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label162
            // 
            this.label162.BackColor = System.Drawing.Color.AliceBlue;
            this.label162.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label162.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label162.Location = new System.Drawing.Point(110, 237);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(95, 53);
            this.label162.TabIndex = 64;
            this.label162.Text = "Subject\r\nTeacher";
            this.label162.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label163
            // 
            this.label163.BackColor = System.Drawing.Color.AliceBlue;
            this.label163.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label163.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label163.Location = new System.Drawing.Point(6, 237);
            this.label163.Name = "label163";
            this.label163.Size = new System.Drawing.Size(95, 53);
            this.label163.TabIndex = 63;
            this.label163.Text = "Subject\r\nTeacher";
            this.label163.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label164
            // 
            this.label164.BackColor = System.Drawing.Color.AliceBlue;
            this.label164.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label164.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label164.Location = new System.Drawing.Point(777, 178);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(92, 53);
            this.label164.TabIndex = 62;
            this.label164.Text = "Subject\r\nTeacher";
            this.label164.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label165
            // 
            this.label165.BackColor = System.Drawing.Color.AliceBlue;
            this.label165.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label165.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label165.Location = new System.Drawing.Point(673, 178);
            this.label165.Name = "label165";
            this.label165.Size = new System.Drawing.Size(95, 53);
            this.label165.TabIndex = 61;
            this.label165.Text = "Subject\r\nTeacher";
            this.label165.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label166
            // 
            this.label166.BackColor = System.Drawing.Color.AliceBlue;
            this.label166.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label166.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label166.Location = new System.Drawing.Point(570, 178);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(94, 53);
            this.label166.TabIndex = 60;
            this.label166.Text = "Subject\r\nTeacher";
            this.label166.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label167
            // 
            this.label167.BackColor = System.Drawing.Color.AliceBlue;
            this.label167.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label167.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label167.Location = new System.Drawing.Point(466, 178);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(95, 53);
            this.label167.TabIndex = 59;
            this.label167.Text = "Subject\r\nTeacher";
            this.label167.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label168
            // 
            this.label168.BackColor = System.Drawing.Color.AliceBlue;
            this.label168.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label168.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label168.Location = new System.Drawing.Point(420, 178);
            this.label168.Name = "label168";
            this.label168.Size = new System.Drawing.Size(37, 53);
            this.label168.TabIndex = 58;
            this.label168.Text = "R";
            this.label168.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label169
            // 
            this.label169.BackColor = System.Drawing.Color.AliceBlue;
            this.label169.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label169.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label169.Location = new System.Drawing.Point(318, 178);
            this.label169.Name = "label169";
            this.label169.Size = new System.Drawing.Size(93, 53);
            this.label169.TabIndex = 57;
            this.label169.Text = "Subject\r\nTeacher";
            this.label169.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label170
            // 
            this.label170.BackColor = System.Drawing.Color.AliceBlue;
            this.label170.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label170.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label170.Location = new System.Drawing.Point(214, 178);
            this.label170.Name = "label170";
            this.label170.Size = new System.Drawing.Size(95, 53);
            this.label170.TabIndex = 56;
            this.label170.Text = "Subject\r\nTeacher";
            this.label170.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label171
            // 
            this.label171.BackColor = System.Drawing.Color.AliceBlue;
            this.label171.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label171.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label171.Location = new System.Drawing.Point(110, 178);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(95, 53);
            this.label171.TabIndex = 55;
            this.label171.Text = "Subject\r\nTeacher";
            this.label171.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label172
            // 
            this.label172.BackColor = System.Drawing.Color.AliceBlue;
            this.label172.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label172.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label172.Location = new System.Drawing.Point(6, 178);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(95, 53);
            this.label172.TabIndex = 54;
            this.label172.Text = "Subject\r\nTeacher";
            this.label172.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label173
            // 
            this.label173.BackColor = System.Drawing.Color.AliceBlue;
            this.label173.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label173.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label173.Location = new System.Drawing.Point(777, 121);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(92, 53);
            this.label173.TabIndex = 53;
            this.label173.Text = "Subject\r\nTeacher";
            this.label173.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label174
            // 
            this.label174.BackColor = System.Drawing.Color.AliceBlue;
            this.label174.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label174.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label174.Location = new System.Drawing.Point(673, 121);
            this.label174.Name = "label174";
            this.label174.Size = new System.Drawing.Size(95, 53);
            this.label174.TabIndex = 52;
            this.label174.Text = "Subject\r\nTeacher";
            this.label174.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label175
            // 
            this.label175.BackColor = System.Drawing.Color.AliceBlue;
            this.label175.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label175.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label175.Location = new System.Drawing.Point(570, 121);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(94, 53);
            this.label175.TabIndex = 51;
            this.label175.Text = "Subject\r\nTeacher";
            this.label175.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label176
            // 
            this.label176.BackColor = System.Drawing.Color.AliceBlue;
            this.label176.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label176.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label176.Location = new System.Drawing.Point(466, 121);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(95, 53);
            this.label176.TabIndex = 50;
            this.label176.Text = "Subject\r\nTeacher";
            this.label176.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label177
            // 
            this.label177.BackColor = System.Drawing.Color.AliceBlue;
            this.label177.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label177.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label177.Location = new System.Drawing.Point(420, 121);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(37, 53);
            this.label177.TabIndex = 49;
            this.label177.Text = "B";
            this.label177.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label178
            // 
            this.label178.BackColor = System.Drawing.Color.AliceBlue;
            this.label178.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label178.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label178.Location = new System.Drawing.Point(318, 121);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(93, 53);
            this.label178.TabIndex = 48;
            this.label178.Text = "Subject\r\nTeacher";
            this.label178.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label179
            // 
            this.label179.BackColor = System.Drawing.Color.AliceBlue;
            this.label179.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label179.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label179.Location = new System.Drawing.Point(214, 121);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(95, 53);
            this.label179.TabIndex = 47;
            this.label179.Text = "Subject\r\nTeacher";
            this.label179.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label180
            // 
            this.label180.BackColor = System.Drawing.Color.AliceBlue;
            this.label180.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label180.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label180.Location = new System.Drawing.Point(110, 121);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(95, 53);
            this.label180.TabIndex = 46;
            this.label180.Text = "Subject\r\nTeacher";
            this.label180.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label181
            // 
            this.label181.BackColor = System.Drawing.Color.AliceBlue;
            this.label181.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label181.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label181.Location = new System.Drawing.Point(6, 121);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(95, 53);
            this.label181.TabIndex = 45;
            this.label181.Text = "Subject\r\nTeacher";
            this.label181.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label182
            // 
            this.label182.BackColor = System.Drawing.Color.AliceBlue;
            this.label182.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label182.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label182.Location = new System.Drawing.Point(777, 61);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(92, 53);
            this.label182.TabIndex = 44;
            this.label182.Text = "Subject\r\nTeacher";
            this.label182.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label183
            // 
            this.label183.BackColor = System.Drawing.Color.AliceBlue;
            this.label183.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label183.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label183.Location = new System.Drawing.Point(673, 61);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(95, 53);
            this.label183.TabIndex = 43;
            this.label183.Text = "Subject\r\nTeacher";
            this.label183.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label184
            // 
            this.label184.BackColor = System.Drawing.Color.AliceBlue;
            this.label184.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label184.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label184.Location = new System.Drawing.Point(570, 61);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(94, 53);
            this.label184.TabIndex = 42;
            this.label184.Text = "Subject\r\nTeacher";
            this.label184.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label185
            // 
            this.label185.BackColor = System.Drawing.Color.AliceBlue;
            this.label185.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label185.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label185.Location = new System.Drawing.Point(466, 61);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(95, 53);
            this.label185.TabIndex = 41;
            this.label185.Text = "Subject\r\nTeacher";
            this.label185.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label186
            // 
            this.label186.BackColor = System.Drawing.Color.AliceBlue;
            this.label186.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label186.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label186.Location = new System.Drawing.Point(420, 61);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(37, 53);
            this.label186.TabIndex = 40;
            this.label186.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label187
            // 
            this.label187.BackColor = System.Drawing.Color.AliceBlue;
            this.label187.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label187.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label187.Location = new System.Drawing.Point(318, 61);
            this.label187.Name = "label187";
            this.label187.Size = new System.Drawing.Size(93, 53);
            this.label187.TabIndex = 39;
            this.label187.Text = "Subject\r\nTeacher";
            this.label187.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label188
            // 
            this.label188.BackColor = System.Drawing.Color.AliceBlue;
            this.label188.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label188.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label188.Location = new System.Drawing.Point(214, 61);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(95, 53);
            this.label188.TabIndex = 38;
            this.label188.Text = "Subject\r\nTeacher";
            this.label188.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label189
            // 
            this.label189.BackColor = System.Drawing.Color.AliceBlue;
            this.label189.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label189.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label189.Location = new System.Drawing.Point(110, 61);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(95, 53);
            this.label189.TabIndex = 37;
            this.label189.Text = "Subject\r\nTeacher";
            this.label189.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label190
            // 
            this.label190.BackColor = System.Drawing.Color.AliceBlue;
            this.label190.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label190.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label190.Location = new System.Drawing.Point(6, 61);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(95, 53);
            this.label190.TabIndex = 36;
            this.label190.Text = "Subject\r\nTeacher";
            this.label190.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label191
            // 
            this.label191.BackColor = System.Drawing.Color.AliceBlue;
            this.label191.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label191.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label191.Location = new System.Drawing.Point(777, 3);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(92, 53);
            this.label191.TabIndex = 35;
            this.label191.Text = "Subject\r\nTeacher";
            this.label191.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label192
            // 
            this.label192.BackColor = System.Drawing.Color.AliceBlue;
            this.label192.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label192.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label192.Location = new System.Drawing.Point(673, 3);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(95, 53);
            this.label192.TabIndex = 34;
            this.label192.Text = "Subject\r\nTeacher";
            this.label192.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label193
            // 
            this.label193.BackColor = System.Drawing.Color.AliceBlue;
            this.label193.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label193.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label193.Location = new System.Drawing.Point(570, 3);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(94, 53);
            this.label193.TabIndex = 33;
            this.label193.Text = "Subject\r\nTeacher";
            this.label193.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label194
            // 
            this.label194.BackColor = System.Drawing.Color.AliceBlue;
            this.label194.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label194.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label194.Location = new System.Drawing.Point(420, 3);
            this.label194.Name = "label194";
            this.label194.Size = new System.Drawing.Size(37, 53);
            this.label194.TabIndex = 32;
            this.label194.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label195
            // 
            this.label195.BackColor = System.Drawing.Color.AliceBlue;
            this.label195.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label195.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label195.Location = new System.Drawing.Point(318, 3);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(93, 53);
            this.label195.TabIndex = 30;
            this.label195.Text = "Subject\r\nTeacher";
            this.label195.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label196
            // 
            this.label196.BackColor = System.Drawing.Color.AliceBlue;
            this.label196.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label196.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label196.Location = new System.Drawing.Point(6, 3);
            this.label196.Name = "label196";
            this.label196.Size = new System.Drawing.Size(95, 53);
            this.label196.TabIndex = 29;
            this.label196.Text = "Subject\r\nTeacher";
            this.label196.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label197
            // 
            this.label197.BackColor = System.Drawing.Color.AliceBlue;
            this.label197.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label197.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label197.Location = new System.Drawing.Point(466, 3);
            this.label197.Name = "label197";
            this.label197.Size = new System.Drawing.Size(95, 53);
            this.label197.TabIndex = 31;
            this.label197.Text = "Subject\r\nTeacher";
            this.label197.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label198
            // 
            this.label198.BackColor = System.Drawing.Color.AliceBlue;
            this.label198.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label198.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label198.Location = new System.Drawing.Point(4, 584);
            this.label198.Name = "label198";
            this.label198.Size = new System.Drawing.Size(145, 55);
            this.label198.TabIndex = 27;
            this.label198.Text = "Class 10";
            this.label198.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label199
            // 
            this.label199.BackColor = System.Drawing.Color.AliceBlue;
            this.label199.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label199.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label199.Location = new System.Drawing.Point(4, 526);
            this.label199.Name = "label199";
            this.label199.Size = new System.Drawing.Size(145, 55);
            this.label199.TabIndex = 26;
            this.label199.Text = "Class 9";
            this.label199.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label200
            // 
            this.label200.BackColor = System.Drawing.Color.AliceBlue;
            this.label200.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label200.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label200.Location = new System.Drawing.Point(4, 468);
            this.label200.Name = "label200";
            this.label200.Size = new System.Drawing.Size(145, 55);
            this.label200.TabIndex = 25;
            this.label200.Text = "Class 8";
            this.label200.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label201
            // 
            this.label201.BackColor = System.Drawing.Color.AliceBlue;
            this.label201.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label201.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label201.Location = new System.Drawing.Point(4, 410);
            this.label201.Name = "label201";
            this.label201.Size = new System.Drawing.Size(145, 55);
            this.label201.TabIndex = 24;
            this.label201.Text = "Class 7";
            this.label201.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label202
            // 
            this.label202.BackColor = System.Drawing.Color.AliceBlue;
            this.label202.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label202.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label202.Location = new System.Drawing.Point(4, 352);
            this.label202.Name = "label202";
            this.label202.Size = new System.Drawing.Size(145, 55);
            this.label202.TabIndex = 23;
            this.label202.Text = "Class 6";
            this.label202.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label203
            // 
            this.label203.BackColor = System.Drawing.Color.AliceBlue;
            this.label203.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label203.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label203.Location = new System.Drawing.Point(4, 294);
            this.label203.Name = "label203";
            this.label203.Size = new System.Drawing.Size(145, 55);
            this.label203.TabIndex = 22;
            this.label203.Text = "Class 5";
            this.label203.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label204
            // 
            this.label204.BackColor = System.Drawing.Color.AliceBlue;
            this.label204.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label204.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label204.Location = new System.Drawing.Point(4, 236);
            this.label204.Name = "label204";
            this.label204.Size = new System.Drawing.Size(145, 55);
            this.label204.TabIndex = 21;
            this.label204.Text = "Class 4";
            this.label204.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label205
            // 
            this.label205.BackColor = System.Drawing.Color.AliceBlue;
            this.label205.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label205.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label205.Location = new System.Drawing.Point(4, 178);
            this.label205.Name = "label205";
            this.label205.Size = new System.Drawing.Size(145, 55);
            this.label205.TabIndex = 20;
            this.label205.Text = "Class 3";
            this.label205.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label206
            // 
            this.label206.BackColor = System.Drawing.Color.AliceBlue;
            this.label206.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label206.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label206.Location = new System.Drawing.Point(4, 120);
            this.label206.Name = "label206";
            this.label206.Size = new System.Drawing.Size(145, 55);
            this.label206.TabIndex = 19;
            this.label206.Text = "Class 2";
            this.label206.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label207
            // 
            this.label207.BackColor = System.Drawing.Color.AliceBlue;
            this.label207.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label207.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label207.Location = new System.Drawing.Point(4, 62);
            this.label207.Name = "label207";
            this.label207.Size = new System.Drawing.Size(145, 55);
            this.label207.TabIndex = 18;
            this.label207.Text = "Class 1";
            this.label207.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label208
            // 
            this.label208.BackColor = System.Drawing.Color.AliceBlue;
            this.label208.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label208.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label208.Location = new System.Drawing.Point(568, 4);
            this.label208.Name = "label208";
            this.label208.Size = new System.Drawing.Size(40, 55);
            this.label208.TabIndex = 17;
            this.label208.Text = "30\r\nMINT";
            this.label208.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label209
            // 
            this.label209.BackColor = System.Drawing.Color.AliceBlue;
            this.label209.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label209.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label209.Location = new System.Drawing.Point(924, 32);
            this.label209.Name = "label209";
            this.label209.Size = new System.Drawing.Size(100, 26);
            this.label209.TabIndex = 16;
            this.label209.Text = "12:30 to 1:05";
            this.label209.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label210
            // 
            this.label210.BackColor = System.Drawing.Color.AliceBlue;
            this.label210.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label210.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label210.Location = new System.Drawing.Point(924, 4);
            this.label210.Name = "label210";
            this.label210.Size = new System.Drawing.Size(100, 26);
            this.label210.TabIndex = 15;
            this.label210.Text = "Period 8";
            this.label210.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label211
            // 
            this.label211.BackColor = System.Drawing.Color.AliceBlue;
            this.label211.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label211.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label211.Location = new System.Drawing.Point(820, 32);
            this.label211.Name = "label211";
            this.label211.Size = new System.Drawing.Size(100, 26);
            this.label211.TabIndex = 14;
            this.label211.Text = "11:55 to 12:30";
            this.label211.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label212
            // 
            this.label212.BackColor = System.Drawing.Color.AliceBlue;
            this.label212.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label212.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label212.Location = new System.Drawing.Point(820, 4);
            this.label212.Name = "label212";
            this.label212.Size = new System.Drawing.Size(100, 26);
            this.label212.TabIndex = 13;
            this.label212.Text = "Period 7";
            this.label212.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label213
            // 
            this.label213.BackColor = System.Drawing.Color.AliceBlue;
            this.label213.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label213.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label213.Location = new System.Drawing.Point(716, 32);
            this.label213.Name = "label213";
            this.label213.Size = new System.Drawing.Size(100, 26);
            this.label213.TabIndex = 12;
            this.label213.Text = "11:20 to 11:55";
            this.label213.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label214
            // 
            this.label214.BackColor = System.Drawing.Color.AliceBlue;
            this.label214.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label214.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label214.Location = new System.Drawing.Point(716, 4);
            this.label214.Name = "label214";
            this.label214.Size = new System.Drawing.Size(100, 26);
            this.label214.TabIndex = 11;
            this.label214.Text = "Period 6";
            this.label214.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label215
            // 
            this.label215.BackColor = System.Drawing.Color.AliceBlue;
            this.label215.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label215.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label215.Location = new System.Drawing.Point(612, 32);
            this.label215.Name = "label215";
            this.label215.Size = new System.Drawing.Size(100, 26);
            this.label215.TabIndex = 10;
            this.label215.Text = "10:45 to 11:20";
            this.label215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label216
            // 
            this.label216.BackColor = System.Drawing.Color.AliceBlue;
            this.label216.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label216.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label216.Location = new System.Drawing.Point(612, 4);
            this.label216.Name = "label216";
            this.label216.Size = new System.Drawing.Size(100, 26);
            this.label216.TabIndex = 9;
            this.label216.Text = "Period 5";
            this.label216.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label217
            // 
            this.label217.BackColor = System.Drawing.Color.AliceBlue;
            this.label217.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label217.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label217.Location = new System.Drawing.Point(465, 32);
            this.label217.Name = "label217";
            this.label217.Size = new System.Drawing.Size(100, 26);
            this.label217.TabIndex = 8;
            this.label217.Text = "9:45 to 10:15";
            this.label217.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label218
            // 
            this.label218.BackColor = System.Drawing.Color.AliceBlue;
            this.label218.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label218.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label218.Location = new System.Drawing.Point(465, 4);
            this.label218.Name = "label218";
            this.label218.Size = new System.Drawing.Size(100, 26);
            this.label218.TabIndex = 7;
            this.label218.Text = "Period 4";
            this.label218.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label219
            // 
            this.label219.BackColor = System.Drawing.Color.AliceBlue;
            this.label219.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label219.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label219.Location = new System.Drawing.Point(361, 32);
            this.label219.Name = "label219";
            this.label219.Size = new System.Drawing.Size(100, 26);
            this.label219.TabIndex = 6;
            this.label219.Text = "9:10 to 9:45";
            this.label219.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label220
            // 
            this.label220.BackColor = System.Drawing.Color.AliceBlue;
            this.label220.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label220.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label220.Location = new System.Drawing.Point(361, 4);
            this.label220.Name = "label220";
            this.label220.Size = new System.Drawing.Size(100, 26);
            this.label220.TabIndex = 5;
            this.label220.Text = "Period 3";
            this.label220.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label221
            // 
            this.label221.BackColor = System.Drawing.Color.AliceBlue;
            this.label221.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label221.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label221.Location = new System.Drawing.Point(257, 32);
            this.label221.Name = "label221";
            this.label221.Size = new System.Drawing.Size(100, 26);
            this.label221.TabIndex = 4;
            this.label221.Text = "8:35 to 9:10";
            this.label221.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label222
            // 
            this.label222.BackColor = System.Drawing.Color.AliceBlue;
            this.label222.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label222.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label222.Location = new System.Drawing.Point(257, 4);
            this.label222.Name = "label222";
            this.label222.Size = new System.Drawing.Size(100, 26);
            this.label222.TabIndex = 3;
            this.label222.Text = "Period 2";
            this.label222.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label223
            // 
            this.label223.BackColor = System.Drawing.Color.AliceBlue;
            this.label223.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label223.Font = new System.Drawing.Font("Lucida Fax", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label223.Location = new System.Drawing.Point(153, 32);
            this.label223.Name = "label223";
            this.label223.Size = new System.Drawing.Size(100, 26);
            this.label223.TabIndex = 2;
            this.label223.Text = "8:00 to 8:35";
            this.label223.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label224
            // 
            this.label224.BackColor = System.Drawing.Color.AliceBlue;
            this.label224.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label224.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label224.Location = new System.Drawing.Point(153, 4);
            this.label224.Name = "label224";
            this.label224.Size = new System.Drawing.Size(100, 26);
            this.label224.TabIndex = 1;
            this.label224.Text = "Period 1";
            this.label224.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label225
            // 
            this.label225.BackColor = System.Drawing.Color.AliceBlue;
            this.label225.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label225.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label225.Location = new System.Drawing.Point(4, 4);
            this.label225.Name = "label225";
            this.label225.Size = new System.Drawing.Size(145, 55);
            this.label225.TabIndex = 0;
            this.label225.Text = "Class / Period";
            this.label225.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // schedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::schoolSystem.Properties.Resources.colored_pencils_3141508_960_720;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1121, 712);
            this.Controls.Add(this.period_schedule);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "schedule";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "schedule";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.period_schedule.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel period_schedule;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Label label163;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.Label label187;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.Label label194;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label196;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.Label label198;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.Label label200;
        private System.Windows.Forms.Label label201;
        private System.Windows.Forms.Label label202;
        private System.Windows.Forms.Label label203;
        private System.Windows.Forms.Label label204;
        private System.Windows.Forms.Label label205;
        private System.Windows.Forms.Label label206;
        private System.Windows.Forms.Label label207;
        private System.Windows.Forms.Label label208;
        private System.Windows.Forms.Label label209;
        private System.Windows.Forms.Label label210;
        private System.Windows.Forms.Label label211;
        private System.Windows.Forms.Label label212;
        private System.Windows.Forms.Label label213;
        private System.Windows.Forms.Label label214;
        private System.Windows.Forms.Label label215;
        private System.Windows.Forms.Label label216;
        private System.Windows.Forms.Label label217;
        private System.Windows.Forms.Label label218;
        private System.Windows.Forms.Label label219;
        private System.Windows.Forms.Label label220;
        private System.Windows.Forms.Label label221;
        private System.Windows.Forms.Label label222;
        private System.Windows.Forms.Label label223;
        private System.Windows.Forms.Label label224;
        private System.Windows.Forms.Label label225;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label226;
        private System.Windows.Forms.Label label227;
        private System.Windows.Forms.Label label228;
        private System.Windows.Forms.Label label229;
        private System.Windows.Forms.Label label230;
        private System.Windows.Forms.Label label231;
        private System.Windows.Forms.Label label232;
        private System.Windows.Forms.Label label233;
        private System.Windows.Forms.Label label234;
        private System.Windows.Forms.Label label235;
        private System.Windows.Forms.Label label236;
        private System.Windows.Forms.Label label237;
        private System.Windows.Forms.Label label238;
        private System.Windows.Forms.Label label239;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label240;
        private System.Windows.Forms.Label label241;
        private System.Windows.Forms.Label label242;
        private System.Windows.Forms.Label label243;
        private System.Windows.Forms.Label label244;
        private System.Windows.Forms.Label label245;
        private System.Windows.Forms.Label label246;
        private System.Windows.Forms.Label label247;
        private System.Windows.Forms.Label label248;
        private System.Windows.Forms.Label label249;
        private System.Windows.Forms.Label label250;
        private System.Windows.Forms.Label label251;
        private System.Windows.Forms.Label label252;
        private System.Windows.Forms.Label label253;
        private System.Windows.Forms.Label label254;
        private System.Windows.Forms.Label label255;
        private System.Windows.Forms.Label label256;
        private System.Windows.Forms.Label label257;
        private System.Windows.Forms.Label label258;
        private System.Windows.Forms.Label label259;
        private System.Windows.Forms.Label label260;
        private System.Windows.Forms.Label label261;
        private System.Windows.Forms.Label label262;
        private System.Windows.Forms.Label label263;
        private System.Windows.Forms.Label label264;
        private System.Windows.Forms.Label label265;
        private System.Windows.Forms.Label label266;
        private System.Windows.Forms.Label label267;
        private System.Windows.Forms.Label label268;
        private System.Windows.Forms.Label label269;
        private System.Windows.Forms.Label label270;
        private System.Windows.Forms.Label label271;
        private System.Windows.Forms.Label label272;
        private System.Windows.Forms.Label label273;
        private System.Windows.Forms.Label label274;
        private System.Windows.Forms.Label label275;
        private System.Windows.Forms.Label label276;
        private System.Windows.Forms.Label label277;
        private System.Windows.Forms.Label label278;
        private System.Windows.Forms.Label label279;
        private System.Windows.Forms.Label label280;
        private System.Windows.Forms.Label label281;
        private System.Windows.Forms.Label label282;
        private System.Windows.Forms.Label label283;
        private System.Windows.Forms.Label label284;
        private System.Windows.Forms.Label label285;
        private System.Windows.Forms.Label label286;
        private System.Windows.Forms.Label label287;
        private System.Windows.Forms.Label label288;
        private System.Windows.Forms.Label label289;
        private System.Windows.Forms.Label label290;
        private System.Windows.Forms.Label label291;
        private System.Windows.Forms.Label label292;
        private System.Windows.Forms.Label label293;
        private System.Windows.Forms.Label label294;
        private System.Windows.Forms.Label label295;
        private System.Windows.Forms.Label label296;
        private System.Windows.Forms.Label label297;
        private System.Windows.Forms.Label label298;
        private System.Windows.Forms.Label label299;
        private System.Windows.Forms.Label label300;
        private System.Windows.Forms.Label label301;
        private System.Windows.Forms.Label label302;
        private System.Windows.Forms.Label label303;
        private System.Windows.Forms.Label label304;
        private System.Windows.Forms.Label label305;
        private System.Windows.Forms.Label label306;
        private System.Windows.Forms.Label label307;
        private System.Windows.Forms.Label label308;
        private System.Windows.Forms.Label label309;
        private System.Windows.Forms.Label label310;
        private System.Windows.Forms.Label label311;
        private System.Windows.Forms.Label label312;
        private System.Windows.Forms.Label label313;
        private System.Windows.Forms.Label label314;
        private System.Windows.Forms.Label label315;
        private System.Windows.Forms.Label label316;
        private System.Windows.Forms.Label label317;
        private System.Windows.Forms.Label label318;
        private System.Windows.Forms.Label label319;
        private System.Windows.Forms.Label label320;
        private System.Windows.Forms.Label label321;
        private System.Windows.Forms.Label label322;
        private System.Windows.Forms.Label label323;
        private System.Windows.Forms.Label label324;
        private System.Windows.Forms.Label label325;
        private System.Windows.Forms.Label label326;
        private System.Windows.Forms.Label label327;
        private System.Windows.Forms.Label label328;
        private System.Windows.Forms.Label label329;
        private System.Windows.Forms.Label label330;
        private System.Windows.Forms.Label label331;
        private System.Windows.Forms.Label label332;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label333;
        private System.Windows.Forms.Label label334;
        private System.Windows.Forms.Label label335;
        private System.Windows.Forms.Label label336;
        private System.Windows.Forms.Label label337;
        private System.Windows.Forms.Label label338;
        private System.Windows.Forms.Label label339;
        private System.Windows.Forms.Label label340;
        private System.Windows.Forms.Label label341;
        private System.Windows.Forms.Label label342;
        private System.Windows.Forms.Label label343;
        private System.Windows.Forms.Label label344;
        private System.Windows.Forms.Label label345;
        private System.Windows.Forms.Label label346;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label347;
        private System.Windows.Forms.Label label348;
        private System.Windows.Forms.Label label349;
        private System.Windows.Forms.Label label350;
        private System.Windows.Forms.Label label351;
        private System.Windows.Forms.Label label352;
        private System.Windows.Forms.Label label353;
        private System.Windows.Forms.Label label354;
        private System.Windows.Forms.Label label355;
        private System.Windows.Forms.Label label356;
        private System.Windows.Forms.Label label357;
        private System.Windows.Forms.Label label358;
        private System.Windows.Forms.Label label359;
        private System.Windows.Forms.Label label360;
        private System.Windows.Forms.Label label361;
        private System.Windows.Forms.Label label362;
        private System.Windows.Forms.Label label363;
        private System.Windows.Forms.Label label364;
        private System.Windows.Forms.Label label365;
        private System.Windows.Forms.Label label366;
        private System.Windows.Forms.Label label367;
        private System.Windows.Forms.Label label368;
        private System.Windows.Forms.Label label369;
        private System.Windows.Forms.Label label370;
        private System.Windows.Forms.Label label371;
        private System.Windows.Forms.Label label372;
        private System.Windows.Forms.Label label373;
        private System.Windows.Forms.Label label374;
        private System.Windows.Forms.Label label375;
        private System.Windows.Forms.Label label376;
        private System.Windows.Forms.Label label377;
        private System.Windows.Forms.Label label378;
        private System.Windows.Forms.Label label379;
        private System.Windows.Forms.Label label380;
        private System.Windows.Forms.Label label381;
        private System.Windows.Forms.Label label382;
        private System.Windows.Forms.Label label383;
        private System.Windows.Forms.Label label384;
        private System.Windows.Forms.Label label385;
        private System.Windows.Forms.Label label386;
        private System.Windows.Forms.Label label387;
        private System.Windows.Forms.Label label388;
        private System.Windows.Forms.Label label389;
        private System.Windows.Forms.Label label390;
        private System.Windows.Forms.Label label391;
        private System.Windows.Forms.Label label392;
        private System.Windows.Forms.Label label393;
        private System.Windows.Forms.Label label394;
        private System.Windows.Forms.Label label395;
        private System.Windows.Forms.Label label396;
        private System.Windows.Forms.Label label397;
        private System.Windows.Forms.Label label398;
        private System.Windows.Forms.Label label399;
        private System.Windows.Forms.Label label400;
        private System.Windows.Forms.Label label401;
        private System.Windows.Forms.Label label402;
        private System.Windows.Forms.Label label403;
        private System.Windows.Forms.Label label404;
        private System.Windows.Forms.Label label405;
        private System.Windows.Forms.Label label406;
        private System.Windows.Forms.Label label407;
        private System.Windows.Forms.Label label408;
        private System.Windows.Forms.Label label409;
        private System.Windows.Forms.Label label410;
        private System.Windows.Forms.Label label411;
        private System.Windows.Forms.Label label412;
        private System.Windows.Forms.Label label413;
        private System.Windows.Forms.Label label414;
        private System.Windows.Forms.Label label415;
        private System.Windows.Forms.Label label416;
        private System.Windows.Forms.Label label417;
        private System.Windows.Forms.Label label418;
        private System.Windows.Forms.Label label419;
        private System.Windows.Forms.Label label420;
        private System.Windows.Forms.Label label421;
        private System.Windows.Forms.Label label422;
        private System.Windows.Forms.Label label423;
        private System.Windows.Forms.Label label424;
        private System.Windows.Forms.Label label425;
        private System.Windows.Forms.Label label426;
        private System.Windows.Forms.Label label427;
        private System.Windows.Forms.Label label428;
        private System.Windows.Forms.Label label429;
        private System.Windows.Forms.Label label430;
        private System.Windows.Forms.Label label431;
        private System.Windows.Forms.Label label432;
        private System.Windows.Forms.Label label433;
        private System.Windows.Forms.Label label434;
        private System.Windows.Forms.Label label435;
        private System.Windows.Forms.Label label436;
        private System.Windows.Forms.Label label437;
        private System.Windows.Forms.Label label438;
        private System.Windows.Forms.Label label439;
    }
}