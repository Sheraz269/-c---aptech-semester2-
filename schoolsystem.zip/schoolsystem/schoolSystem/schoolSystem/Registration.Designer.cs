﻿namespace schoolSystem
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.panel_student_reg = new System.Windows.Forms.Panel();
            this.sadmision = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.sshift = new System.Windows.Forms.ComboBox();
            this.sreset = new System.Windows.Forms.Button();
            this.sbranch = new System.Windows.Forms.ComboBox();
            this.sfatheroc = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.ssubmit = new System.Windows.Forms.Button();
            this.spicupload = new System.Windows.Forms.Button();
            this.spicture = new System.Windows.Forms.Label();
            this.sdate = new System.Windows.Forms.DateTimePicker();
            this.scountry = new System.Windows.Forms.TextBox();
            this.sfee = new System.Windows.Forms.TextBox();
            this.sreligion = new System.Windows.Forms.TextBox();
            this.smobileno = new System.Windows.Forms.TextBox();
            this.semail = new System.Windows.Forms.TextBox();
            this.scity = new System.Windows.Forms.TextBox();
            this.sfemale = new System.Windows.Forms.RadioButton();
            this.smale = new System.Windows.Forms.RadioButton();
            this.shomeadress = new System.Windows.Forms.TextBox();
            this.sfname = new System.Windows.Forms.TextBox();
            this.sname = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.teacher_btn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.panel_student_reg.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Italic);
            this.button2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button2.Location = new System.Drawing.Point(610, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(220, 46);
            this.button2.TabIndex = 27;
            this.button2.Text = "Goto Student\'s Form";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel_student_reg
            // 
            this.panel_student_reg.BackColor = System.Drawing.Color.Lavender;
            this.panel_student_reg.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_student_reg.Controls.Add(this.sadmision);
            this.panel_student_reg.Controls.Add(this.label1);
            this.panel_student_reg.Controls.Add(this.sshift);
            this.panel_student_reg.Controls.Add(this.sreset);
            this.panel_student_reg.Controls.Add(this.sbranch);
            this.panel_student_reg.Controls.Add(this.sfatheroc);
            this.panel_student_reg.Controls.Add(this.label32);
            this.panel_student_reg.Controls.Add(this.label31);
            this.panel_student_reg.Controls.Add(this.label30);
            this.panel_student_reg.Controls.Add(this.ssubmit);
            this.panel_student_reg.Controls.Add(this.spicupload);
            this.panel_student_reg.Controls.Add(this.spicture);
            this.panel_student_reg.Controls.Add(this.sdate);
            this.panel_student_reg.Controls.Add(this.scountry);
            this.panel_student_reg.Controls.Add(this.sfee);
            this.panel_student_reg.Controls.Add(this.sreligion);
            this.panel_student_reg.Controls.Add(this.smobileno);
            this.panel_student_reg.Controls.Add(this.semail);
            this.panel_student_reg.Controls.Add(this.scity);
            this.panel_student_reg.Controls.Add(this.sfemale);
            this.panel_student_reg.Controls.Add(this.smale);
            this.panel_student_reg.Controls.Add(this.shomeadress);
            this.panel_student_reg.Controls.Add(this.sfname);
            this.panel_student_reg.Controls.Add(this.sname);
            this.panel_student_reg.Controls.Add(this.label14);
            this.panel_student_reg.Controls.Add(this.label15);
            this.panel_student_reg.Controls.Add(this.label16);
            this.panel_student_reg.Controls.Add(this.label17);
            this.panel_student_reg.Controls.Add(this.label18);
            this.panel_student_reg.Controls.Add(this.label19);
            this.panel_student_reg.Controls.Add(this.label20);
            this.panel_student_reg.Controls.Add(this.label21);
            this.panel_student_reg.Controls.Add(this.label22);
            this.panel_student_reg.Controls.Add(this.label23);
            this.panel_student_reg.Controls.Add(this.label24);
            this.panel_student_reg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel_student_reg.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel_student_reg.Location = new System.Drawing.Point(6, 113);
            this.panel_student_reg.Name = "panel_student_reg";
            this.panel_student_reg.Size = new System.Drawing.Size(834, 441);
            this.panel_student_reg.TabIndex = 28;
            // 
            // sadmision
            // 
            this.sadmision.Location = new System.Drawing.Point(332, 280);
            this.sadmision.Multiline = true;
            this.sadmision.Name = "sadmision";
            this.sadmision.Size = new System.Drawing.Size(276, 24);
            this.sadmision.TabIndex = 34;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(332, 255);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 23);
            this.label1.TabIndex = 33;
            this.label1.Text = "Addmission Fee :";
            // 
            // sshift
            // 
            this.sshift.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sshift.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sshift.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sshift.FormattingEnabled = true;
            this.sshift.Items.AddRange(new object[] {
            "Morning",
            "Evening"});
            this.sshift.Location = new System.Drawing.Point(475, 401);
            this.sshift.Name = "sshift";
            this.sshift.Size = new System.Drawing.Size(133, 24);
            this.sshift.TabIndex = 32;
            // 
            // sreset
            // 
            this.sreset.BackColor = System.Drawing.Color.DimGray;
            this.sreset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sreset.Font = new System.Drawing.Font("Modern No. 20", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sreset.ForeColor = System.Drawing.Color.White;
            this.sreset.Location = new System.Drawing.Point(650, 300);
            this.sreset.Name = "sreset";
            this.sreset.Size = new System.Drawing.Size(154, 49);
            this.sreset.TabIndex = 31;
            this.sreset.Text = "RESET";
            this.sreset.UseVisualStyleBackColor = false;
            this.sreset.Click += new System.EventHandler(this.sreset_Click);
            // 
            // sbranch
            // 
            this.sbranch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sbranch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sbranch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sbranch.FormattingEnabled = true;
            this.sbranch.Items.AddRange(new object[] {
            "Main",
            "2nd branch",
            "3rd branch",
            "4th branch",
            "5th branch"});
            this.sbranch.Location = new System.Drawing.Point(332, 401);
            this.sbranch.Name = "sbranch";
            this.sbranch.Size = new System.Drawing.Size(133, 24);
            this.sbranch.TabIndex = 30;
            this.sbranch.Text = "Main";
            // 
            // sfatheroc
            // 
            this.sfatheroc.Location = new System.Drawing.Point(30, 401);
            this.sfatheroc.Multiline = true;
            this.sfatheroc.Name = "sfatheroc";
            this.sfatheroc.Size = new System.Drawing.Size(276, 24);
            this.sfatheroc.TabIndex = 29;
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(332, 378);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(133, 23);
            this.label32.TabIndex = 28;
            this.label32.Text = "School Branch :";
            // 
            // label31
            // 
            this.label31.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(475, 378);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(133, 23);
            this.label31.TabIndex = 27;
            this.label31.Text = "Shift :";
            // 
            // label30
            // 
            this.label30.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(30, 378);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(159, 23);
            this.label30.TabIndex = 26;
            this.label30.Text = "Father Occupation :";
            // 
            // ssubmit
            // 
            this.ssubmit.BackColor = System.Drawing.Color.DimGray;
            this.ssubmit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ssubmit.Font = new System.Drawing.Font("Modern No. 20", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ssubmit.ForeColor = System.Drawing.Color.White;
            this.ssubmit.Location = new System.Drawing.Point(650, 355);
            this.ssubmit.Name = "ssubmit";
            this.ssubmit.Size = new System.Drawing.Size(154, 49);
            this.ssubmit.TabIndex = 25;
            this.ssubmit.Text = "SUBMIT";
            this.ssubmit.UseVisualStyleBackColor = false;
            this.ssubmit.Click += new System.EventHandler(this.ssubmit_Click);
            // 
            // spicupload
            // 
            this.spicupload.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.spicupload.Cursor = System.Windows.Forms.Cursors.Hand;
            this.spicupload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.spicupload.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spicupload.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.spicupload.Location = new System.Drawing.Point(650, 122);
            this.spicupload.Name = "spicupload";
            this.spicupload.Size = new System.Drawing.Size(135, 36);
            this.spicupload.TabIndex = 24;
            this.spicupload.Text = "Upload Photo";
            this.spicupload.UseVisualStyleBackColor = false;
            // 
            // spicture
            // 
            this.spicture.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.spicture.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.spicture.Location = new System.Drawing.Point(629, 40);
            this.spicture.Name = "spicture";
            this.spicture.Size = new System.Drawing.Size(175, 205);
            this.spicture.TabIndex = 23;
            // 
            // sdate
            // 
            this.sdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sdate.Location = new System.Drawing.Point(332, 219);
            this.sdate.Name = "sdate";
            this.sdate.Size = new System.Drawing.Size(276, 22);
            this.sdate.TabIndex = 22;
            // 
            // scountry
            // 
            this.scountry.Location = new System.Drawing.Point(30, 340);
            this.scountry.Multiline = true;
            this.scountry.Name = "scountry";
            this.scountry.Size = new System.Drawing.Size(276, 24);
            this.scountry.TabIndex = 21;
            // 
            // sfee
            // 
            this.sfee.Location = new System.Drawing.Point(332, 340);
            this.sfee.Multiline = true;
            this.sfee.Name = "sfee";
            this.sfee.Size = new System.Drawing.Size(276, 24);
            this.sfee.TabIndex = 20;
            // 
            // sreligion
            // 
            this.sreligion.Location = new System.Drawing.Point(332, 160);
            this.sreligion.Multiline = true;
            this.sreligion.Name = "sreligion";
            this.sreligion.Size = new System.Drawing.Size(276, 24);
            this.sreligion.TabIndex = 19;
            // 
            // smobileno
            // 
            this.smobileno.Location = new System.Drawing.Point(332, 100);
            this.smobileno.Multiline = true;
            this.smobileno.Name = "smobileno";
            this.smobileno.Size = new System.Drawing.Size(276, 24);
            this.smobileno.TabIndex = 18;
            // 
            // semail
            // 
            this.semail.Location = new System.Drawing.Point(332, 40);
            this.semail.Multiline = true;
            this.semail.Name = "semail";
            this.semail.Size = new System.Drawing.Size(276, 24);
            this.semail.TabIndex = 17;
            // 
            // scity
            // 
            this.scity.Location = new System.Drawing.Point(30, 280);
            this.scity.Multiline = true;
            this.scity.Name = "scity";
            this.scity.Size = new System.Drawing.Size(276, 24);
            this.scity.TabIndex = 16;
            // 
            // sfemale
            // 
            this.sfemale.AutoSize = true;
            this.sfemale.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sfemale.Location = new System.Drawing.Point(150, 220);
            this.sfemale.Name = "sfemale";
            this.sfemale.Size = new System.Drawing.Size(70, 21);
            this.sfemale.TabIndex = 15;
            this.sfemale.TabStop = true;
            this.sfemale.Text = "Female";
            this.sfemale.UseVisualStyleBackColor = true;
            this.sfemale.CheckedChanged += new System.EventHandler(this.sfemale_CheckedChanged);
            // 
            // smale
            // 
            this.smale.AutoSize = true;
            this.smale.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.smale.Location = new System.Drawing.Point(66, 220);
            this.smale.Name = "smale";
            this.smale.Size = new System.Drawing.Size(57, 21);
            this.smale.TabIndex = 14;
            this.smale.TabStop = true;
            this.smale.Text = "Male";
            this.smale.UseVisualStyleBackColor = true;
            this.smale.CheckedChanged += new System.EventHandler(this.smale_CheckedChanged);
            // 
            // shomeadress
            // 
            this.shomeadress.Location = new System.Drawing.Point(30, 160);
            this.shomeadress.Multiline = true;
            this.shomeadress.Name = "shomeadress";
            this.shomeadress.Size = new System.Drawing.Size(276, 24);
            this.shomeadress.TabIndex = 13;
            // 
            // sfname
            // 
            this.sfname.Location = new System.Drawing.Point(30, 100);
            this.sfname.Multiline = true;
            this.sfname.Name = "sfname";
            this.sfname.Size = new System.Drawing.Size(276, 24);
            this.sfname.TabIndex = 12;
            // 
            // sname
            // 
            this.sname.Location = new System.Drawing.Point(30, 40);
            this.sname.Multiline = true;
            this.sname.Name = "sname";
            this.sname.Size = new System.Drawing.Size(276, 24);
            this.sname.TabIndex = 11;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(332, 315);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 23);
            this.label14.TabIndex = 10;
            this.label14.Text = "Fees :";
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(332, 135);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(84, 23);
            this.label15.TabIndex = 9;
            this.label15.Text = "Religion :";
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(332, 195);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(66, 23);
            this.label16.TabIndex = 8;
            this.label16.Text = "D.O.B :";
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(30, 315);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(81, 23);
            this.label17.TabIndex = 7;
            this.label17.Text = "Country :";
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(332, 75);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(109, 23);
            this.label18.TabIndex = 6;
            this.label18.Text = "Mobile No. :";
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(30, 255);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(59, 23);
            this.label19.TabIndex = 5;
            this.label19.Text = "City :";
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(30, 195);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(81, 23);
            this.label20.TabIndex = 4;
            this.label20.Text = "Gender :";
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(332, 15);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(66, 23);
            this.label21.TabIndex = 3;
            this.label21.Text = "Email :";
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(30, 135);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(127, 23);
            this.label22.TabIndex = 2;
            this.label22.Text = "Home Address :";
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(30, 75);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(118, 23);
            this.label23.TabIndex = 1;
            this.label23.Text = "Father Name :";
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(30, 15);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(59, 23);
            this.label24.TabIndex = 0;
            this.label24.Text = "Name :";
            // 
            // teacher_btn
            // 
            this.teacher_btn.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.teacher_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.teacher_btn.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacher_btn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.teacher_btn.Location = new System.Drawing.Point(610, 10);
            this.teacher_btn.Name = "teacher_btn";
            this.teacher_btn.Size = new System.Drawing.Size(220, 46);
            this.teacher_btn.TabIndex = 30;
            this.teacher_btn.Text = "Goto Employee\'s Form";
            this.teacher_btn.UseVisualStyleBackColor = false;
            this.teacher_btn.Click += new System.EventHandler(this.button9_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.teacher_btn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(846, 69);
            this.panel1.TabIndex = 31;
            // 
            // label26
            // 
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label26.Font = new System.Drawing.Font("Lucida Fax", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label26.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label26.Location = new System.Drawing.Point(30, 12);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(432, 46);
            this.label26.TabIndex = 32;
            this.label26.Text = "EMPLOYEE REGISTRATION FORM";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label26.Visible = false;
            // 
            // label25
            // 
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label25.Font = new System.Drawing.Font("Lucida Fax", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label25.Location = new System.Drawing.Point(30, 12);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(417, 46);
            this.label25.TabIndex = 32;
            this.label25.Text = "STUDENT REGISTRATION FORM";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.SeaGreen;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Font = new System.Drawing.Font("Lucida Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.Info;
            this.button5.Location = new System.Drawing.Point(740, 77);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 30);
            this.button5.TabIndex = 31;
            this.button5.Text = "Go Back";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::schoolSystem.Properties.Resources.colored_pencils_3141508_960_720;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(846, 559);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_student_reg);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Registration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registration";
            this.Load += new System.EventHandler(this.Registration_Load);
            this.panel_student_reg.ResumeLayout(false);
            this.panel_student_reg.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel_student_reg;
        private System.Windows.Forms.Button ssubmit;
        private System.Windows.Forms.Button spicupload;
        private System.Windows.Forms.Label spicture;
        private System.Windows.Forms.DateTimePicker sdate;
        private System.Windows.Forms.TextBox scountry;
        private System.Windows.Forms.TextBox sfee;
        private System.Windows.Forms.TextBox smobileno;
        private System.Windows.Forms.TextBox semail;
        private System.Windows.Forms.TextBox scity;
        private System.Windows.Forms.RadioButton sfemale;
        private System.Windows.Forms.RadioButton smale;
        private System.Windows.Forms.TextBox shomeadress;
        private System.Windows.Forms.TextBox sfname;
        private System.Windows.Forms.TextBox sname;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button teacher_btn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox sshift;
        private System.Windows.Forms.Button sreset;
        private System.Windows.Forms.ComboBox sbranch;
        private System.Windows.Forms.TextBox sfatheroc;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox sadmision;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox sreligion;
    }
}