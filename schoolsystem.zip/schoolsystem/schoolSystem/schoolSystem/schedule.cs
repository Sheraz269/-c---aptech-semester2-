﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace schoolSystem
{
    public partial class schedule : Form
    {
        public schedule()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            //////////////////////////
        }

        private void button5_Click(object sender, EventArgs e)
        {
            EDIT edit = new EDIT();
            edit.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            period_schedule.Visible = true;
            panel1.Visible = true;        
            panel2.Visible = true;
            panel3.Visible = true;        
            button2.BackColor = Color.DarkCyan;
            button1.BackColor = Color.DarkSlateGray;
            button3.BackColor = Color.DarkSlateGray;
            button4.BackColor = Color.DarkSlateGray;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            period_schedule.Visible = true;
            panel1.Visible = true;
            panel2.Visible = true;
            panel3.Visible = false;
            button3.BackColor = Color.DarkCyan;
            button1.BackColor = Color.DarkSlateGray;
            button2.BackColor = Color.DarkSlateGray;
            button4.BackColor = Color.DarkSlateGray;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            period_schedule.Visible = true;
            panel1.Visible = true;
            panel2.Visible = false;
            button4.BackColor = Color.DarkCyan;
            button1.BackColor = Color.DarkSlateGray;
            button2.BackColor = Color.DarkSlateGray;
            button3.BackColor = Color.DarkSlateGray;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            period_schedule.Visible = true;
            panel1.Visible = false;
            button1.BackColor = Color.DarkCyan;
            button2.BackColor = Color.DarkSlateGray;
            button3.BackColor = Color.DarkSlateGray;
            button4.BackColor = Color.DarkSlateGray;
        }
    }
}
