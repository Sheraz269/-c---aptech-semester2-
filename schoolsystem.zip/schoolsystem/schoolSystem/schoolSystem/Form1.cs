﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace schoolSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-FKROUFO;Initial Catalog=sklsystem;User ID=sa;Password=123");
            SqlDataAdapter ada = new SqlDataAdapter("select count (*) from admin_login where userID='"+ textBox1.Text +"' and pass='"+ textBox2.Text +"'", conn );

            DataTable dt = new DataTable();

            ada.Fill(dt);
            if (dt.Rows[0][0].ToString()=="1") {
                           
                    loading obj = new loading();
                    obj.Show();
                    this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid: Please Try Again");
            }       

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
