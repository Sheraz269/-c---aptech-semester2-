create database sklsystem;

use sklsystem;

create table admin_login(userID varchar(50) not null unique , pass varchar(50) not null unique);

select * from admin_login;

insert into admin_login values ('student', '123'); 


create table student_Registration(
student_id int primary key identity(1,1) , student_Name varchar(100) not null, FatherName varchar(100) not null, 
Home_addres varchar(100) not null ,gender varchar(10) not null , city varchar(20) not null,
 country varchar(50),father_occ varchar(50), email varchar(50), mobileNo int not null,
religion varchar(50) not null, dateOfbirth datetime not null , branch varchar(50) not null, shiftt varchar(50) not null,
); ---- gender fee DOB image

select * from student_Registration;
