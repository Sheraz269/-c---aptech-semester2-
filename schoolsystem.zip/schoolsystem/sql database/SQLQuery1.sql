create database smsschool

use smsschool

create table smstable(id int primary key not null , name varchar(max), fName varchar(max),
 home_address nvarchar(max), gender varchar(max), city varchar(max),
 country varchar(max), email varchar(50) unique, mobile int  not null, 
 religion varchar(max), fee int, dob varchar(max) );

 select *  from smstable
 
 drop table smstable
 alter table smstable add  photos image

 create table teacherRegistration(
 id int primary key, fullname varchar(max), dep varchar(max), homeaddress varchar(max),
 gender varchar(max),email varchar(50) unique , education varchar(max), acountNO int , 
 contact int  not null, religion varchar(max) not null ,
  basicSalary int not null check(basicSalary >= 10000), joiningDate date, photo image );

 select * from teacherRegistration
