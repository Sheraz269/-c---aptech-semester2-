﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abstract_Class
{
    class workers : salarydep
    {

        public override void display()
        {
            Console.WriteLine("Name :" + name + "\n" + "fixtime : "+ fixTime + "\n" + "perhour : "+ perHour);
            Console.WriteLine("Total salary of Mr " + name + " is " + salary);
        }

    }
}
