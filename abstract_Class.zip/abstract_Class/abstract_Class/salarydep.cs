﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abstract_Class
{
    abstract class salarydep
    {

        public int perHour = 100, salary = 0, fixTime = 8, totalHour = 0;
        public String name;

        public abstract void display();
        public void salaryCount(int bonus, int overTime) {

            salary = perHour * fixTime;
            overTime = overTime + fixTime;
            if (overTime > fixTime)
            {

                totalHour = overTime - fixTime;
                salary = salary + (perHour * totalHour);
            }
            bonus = salary + bonus;
            Console.WriteLine("Bonus :" + bonus + "\n" + "Over Time :" + overTime  );
        
        }


    }
}
