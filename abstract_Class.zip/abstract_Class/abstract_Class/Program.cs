﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abstract_Class
{
    class Program
    {
        static void Main(string[] args)
        {


            workers obj = new workers();

            obj.name = "ALi";
            obj.salaryCount(20 , 5);
            obj.display();

            Console.ReadLine();


        }
    }
}
