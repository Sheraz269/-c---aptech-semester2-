create database homework;



use homework


create table radioPakistan(
id varchar(20), pas varchar(20)


);

select * from radioPakistan

insert into radioPakistan values('one', '123'); 