﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void login_Click(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection("Data Source=LAB-3;Initial Catalog=homework; User ID=sa;Password=123");
            SqlDataAdapter ada = new SqlDataAdapter("select count (*) from radioPakistan where  id='" + userN.Text + "' and pas='" +pass.Text+"'", conn);

            DataTable dt = new DataTable();
            ada.Fill(dt);

            if (dt.Rows[0][0].ToString() == "1")
            {

                this.Hide();
                home h = new home();
                h.Show();




            }
            else {
                MessageBox.Show("Wrong user and password");
            }

        }
    }
}
